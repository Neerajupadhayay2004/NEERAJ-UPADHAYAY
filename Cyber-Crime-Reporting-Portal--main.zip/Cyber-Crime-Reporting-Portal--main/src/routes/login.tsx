import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, Lock, Mail, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in · CyberShield" }] }),
  component: LoginPage,
});

function LoginPage() {
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.info(
        "Authentication will be wired to Lovable Cloud in the next step.",
      );
    }, 600);
  };

  return (
    <div className="mx-auto grid min-h-[calc(100vh-12rem)] max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-2 lg:items-center lg:px-8">
      <div className="hidden lg:block">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-success" /> Government-grade
          security
        </div>
        <h1 className="mt-5 text-4xl font-bold leading-tight">
          Secure access to your cyber portal account
        </h1>
        <p className="mt-3 text-muted-foreground">
          Sign in to manage complaints, upload evidence and receive case updates
          from verified investigators.
        </p>
        <ul className="mt-6 space-y-3 text-sm text-muted-foreground">
          {[
            "End-to-end encrypted sessions",
            "Two-factor authentication",
            "Audit-logged activity",
          ].map((x) => (
            <li key={x} className="flex items-center gap-2">
              <Lock className="h-4 w-4 text-primary" /> {x}
            </li>
          ))}
        </ul>
      </div>

      <div className="card-elevated mx-auto w-full max-w-md p-7 sm:p-9">
        <h2 className="text-2xl font-bold">Welcome back</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Sign in to continue to CyberShield.
        </p>

        <form onSubmit={onSubmit} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                required
                placeholder="you@example.com"
                className="pl-9"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Password</Label>
              <Link
                to="/login"
                className="text-xs text-primary hover:underline"
              >
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="password"
                type={show ? "text" : "password"}
                required
                placeholder="••••••••"
                className="pl-9 pr-10"
              />
              <button
                type="button"
                onClick={() => setShow((s) => !s)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:bg-secondary"
                aria-label="Toggle password"
              >
                {show ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Signing in…" : "Sign in"}
          </Button>
          <p className="text-center text-xs text-muted-foreground">
            New to CyberShield?{" "}
            <Link to="/login" className="text-primary hover:underline">
              Create an account
            </Link>
          </p>
        </form>

        <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="h-px flex-1 bg-border" /> Citizen access only{" "}
          <span className="h-px flex-1 bg-border" />
        </div>
        <p className="text-center text-xs text-muted-foreground">
          Investigator? Use the dedicated officer portal provided by your
          agency.
        </p>
      </div>
    </div>
  );
}
