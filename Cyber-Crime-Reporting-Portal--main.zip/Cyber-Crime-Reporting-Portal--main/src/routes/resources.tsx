import { createFileRoute } from "@tanstack/react-router";
import {
  BookOpen,
  Shield,
  AlertTriangle,
  Lock,
  Smartphone,
  CreditCard,
  Mail,
  ExternalLink,
} from "lucide-react";

export const Route = createFileRoute("/resources")({
  head: () => ({ meta: [{ title: "Cyber Safety Resources · CyberShield" }] }),
  component: ResourcesPage,
});

const guides = [
  {
    icon: CreditCard,
    title: "Protect your bank & UPI",
    points: [
      "Never share OTPs",
      "Verify payee names before paying",
      "Use UPI PIN only for sending money, not receiving",
    ],
  },
  {
    icon: Smartphone,
    title: "Secure your phone",
    points: [
      "Keep OS updated",
      "Install apps only from official stores",
      "Disable unknown sources",
    ],
  },
  {
    icon: Mail,
    title: "Spot phishing",
    points: [
      "Check sender domain carefully",
      "Hover links before clicking",
      "Banks never ask for passwords",
    ],
  },
  {
    icon: Lock,
    title: "Strong authentication",
    points: [
      "Enable 2FA everywhere",
      "Use a password manager",
      "Use unique passwords per site",
    ],
  },
];

const dosDonts = {
  do: [
    "Report fraud to 1930 within 1 hour",
    "Preserve screenshots & transaction IDs",
    "Lock cards immediately on your bank app",
    "File a complaint on this portal",
  ],
  dont: [
    "Share OTPs, PINs or CVVs with anyone",
    "Click suspicious links in SMS/WhatsApp",
    "Install screen-share apps on requests",
    "Trust unverified investment groups",
  ],
};

function ResourcesPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-3xl text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
          <BookOpen className="h-3.5 w-3.5" /> Awareness Library
        </div>
        <h1 className="mt-4 text-3xl font-bold sm:text-4xl">
          Stay one step ahead of cyber criminals
        </h1>
        <p className="mt-3 text-muted-foreground">
          Verified guidance to help you and your family stay safe online.
        </p>
      </div>

      <div className="mt-12 grid gap-5 sm:grid-cols-2">
        {guides.map((g) => (
          <div key={g.title} className="card-elevated card-elevated-hover p-6">
            <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <g.icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 text-lg font-semibold">{g.title}</h3>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              {g.points.map((p) => (
                <li key={p} className="flex gap-2">
                  <Shield className="mt-0.5 h-3.5 w-3.5 shrink-0 text-success" />{" "}
                  {p}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 grid gap-5 lg:grid-cols-2">
        <div className="card-elevated p-6">
          <h3 className="text-lg font-semibold text-success">Do</h3>
          <ul className="mt-3 space-y-2 text-sm">
            {dosDonts.do.map((x) => (
              <li key={x} className="flex gap-2">
                <span className="text-success">✓</span> {x}
              </li>
            ))}
          </ul>
        </div>
        <div className="card-elevated p-6">
          <h3 className="text-lg font-semibold text-destructive">Don't</h3>
          <ul className="mt-3 space-y-2 text-sm">
            {dosDonts.dont.map((x) => (
              <li key={x} className="flex gap-2">
                <span className="text-destructive">✗</span> {x}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-12 rounded-2xl border border-border bg-card p-6">
        <div className="flex items-start gap-3">
          <AlertTriangle className="mt-0.5 h-5 w-5 text-warning" />
          <div>
            <h3 className="font-semibold">Beware of impersonators</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Official communication will always come from verified channels.
              CyberShield will never ask for money, OTPs or remote access to
              your device.
            </p>
            <a
              href="#"
              className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
            >
              Read verification guidelines{" "}
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
