import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import {
  ShieldCheck,
  Upload,
  X,
  FileText,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  Copy,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute("/report")({
  head: () => ({
    meta: [
      { title: "Report a Cyber Incident · CyberShield" },
      {
        name: "description",
        content: "File a cyber crime complaint securely in under 5 minutes.",
      },
    ],
  }),
  component: ReportPage,
});

const CATEGORIES = [
  "Online Fraud",
  "UPI Fraud",
  "Credit Card Fraud",
  "Identity Theft",
  "Cyber Bullying",
  "Email Scam",
  "Investment Scam",
  "Job Scam",
  "Social Media Hacking",
  "Ransomware",
  "Phishing",
  "Fake Shopping Website",
  "Cryptocurrency Scam",
  "Child Exploitation",
  "Financial Fraud",
  "Other",
] as const;

const schema = z.object({
  category: z.string().min(1, "Select a category"),
  title: z.string().trim().min(6, "Title is too short").max(120),
  description: z
    .string()
    .trim()
    .min(20, "Please describe the incident in more detail")
    .max(5000),
  incidentDate: z.string().min(1, "Required"),
  incidentTime: z.string().optional(),
  location: z.string().trim().max(200).optional(),
  amountLost: z.string().optional(),
  suspectPhone: z.string().trim().max(20).optional(),
  suspectEmail: z
    .union([z.string().trim().email("Invalid email").max(120), z.literal("")])
    .optional(),
  suspectWebsite: z.string().trim().max(200).optional(),
  transactionId: z.string().trim().max(120).optional(),
  upiId: z.string().trim().max(120).optional(),
  fullName: z.string().trim().min(2, "Required").max(120),
  contactEmail: z.string().trim().email("Invalid email").max(120),
  contactPhone: z.string().trim().min(7, "Invalid phone").max(20),
  consent: z.literal(true, { message: "Consent is required" }),
});

type FormValues = z.input<typeof schema>;

function generateCaseId() {
  const y = new Date().getFullYear();
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `CS-${y}-${rand}`;
}

function ReportPage() {
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState<File[]>([]);
  const [caseId, setCaseId] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    mode: "onTouched",
    defaultValues: { category: "", consent: undefined as unknown as true },
  });

  const stepFields: Record<number, (keyof FormValues)[]> = useMemo(
    () => ({
      1: ["category", "title", "description", "incidentDate"],
      2: [],
      3: ["fullName", "contactEmail", "contactPhone", "consent"],
    }),
    [],
  );

  const next = async () => {
    const ok = await form.trigger(stepFields[step]);
    if (!ok) return;
    setStep((s) => Math.min(3, s + 1));
  };
  const prev = () => setStep((s) => Math.max(1, s - 1));

  const onDrop = (incoming: FileList | null) => {
    if (!incoming) return;
    const arr = Array.from(incoming);
    const valid = arr.filter((f) => f.size <= 20 * 1024 * 1024);
    if (valid.length !== arr.length) {
      toast.warning("Some files exceeded the 20 MB limit and were skipped.");
    }
    setFiles((prev) => [...prev, ...valid].slice(0, 10));
  };

  const submit = form.handleSubmit(() => {
    const id = generateCaseId();
    setCaseId(id);
    toast.success("Complaint submitted successfully");
  });

  if (caseId) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-elevated p-8 text-center"
        >
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/15 text-success">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <h1 className="mt-5 text-2xl font-bold sm:text-3xl">
            Complaint registered
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Your case has been securely recorded. Use the case ID below to track
            progress.
          </p>
          <div className="mt-6 flex items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-secondary/40 px-4 py-3">
            <span className="font-mono text-lg font-semibold tracking-wider">
              {caseId}
            </span>
            <button
              onClick={() => {
                navigator.clipboard.writeText(caseId);
                toast.success("Copied");
              }}
              className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary"
              aria-label="Copy case ID"
            >
              <Copy className="h-4 w-4" />
            </button>
          </div>
          <div className="mt-7 flex flex-wrap justify-center gap-2">
            <Button asChild>
              <Link to="/track">Track this case</Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/dashboard">Go to dashboard</Link>
            </Button>
          </div>
          <p className="mt-6 text-xs text-muted-foreground">
            An acknowledgement has been sent to your registered email. Keep your
            case ID confidential.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
      <div className="mb-8">
        <Link
          to="/"
          className="text-sm text-muted-foreground hover:text-foreground"
        >
          ← Back to home
        </Link>
        <h1 className="mt-3 text-3xl font-bold sm:text-4xl">
          File a complaint
        </h1>
        <p className="mt-2 text-muted-foreground">
          All information is encrypted and shared only with verified officers.
        </p>
      </div>

      {/* Stepper */}
      <div className="mb-8 flex items-center gap-2 sm:gap-4">
        {[
          { n: 1, label: "Incident" },
          { n: 2, label: "Evidence" },
          { n: 3, label: "Contact" },
        ].map((s, i) => (
          <div key={s.n} className="flex flex-1 items-center gap-2 sm:gap-4">
            <div
              className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-semibold ${
                step >= s.n
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground"
              }`}
            >
              {s.n}
            </div>
            <div className="hidden text-sm font-medium sm:block">{s.label}</div>
            {i < 2 && (
              <div
                className={`h-px flex-1 ${step > s.n ? "bg-primary" : "bg-border"}`}
              />
            )}
          </div>
        ))}
      </div>

      <form onSubmit={submit} className="card-elevated p-6 sm:p-8">
        {step === 1 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold">Incident details</h2>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field
                label="Category"
                error={form.formState.errors.category?.message}
              >
                <Select
                  value={form.watch("category")}
                  onValueChange={(v) =>
                    form.setValue("category", v, { shouldValidate: true })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field
                label="Incident date"
                error={form.formState.errors.incidentDate?.message}
              >
                <Input
                  type="date"
                  {...form.register("incidentDate")}
                  max={new Date().toISOString().split("T")[0]}
                />
              </Field>
              <div className="sm:col-span-2">
                <Field
                  label="Title"
                  error={form.formState.errors.title?.message}
                >
                  <Input
                    placeholder="Brief summary of the incident"
                    {...form.register("title")}
                  />
                </Field>
              </div>
              <div className="sm:col-span-2">
                <Field
                  label="Description"
                  error={form.formState.errors.description?.message}
                >
                  <Textarea
                    rows={5}
                    placeholder="Describe what happened, in your own words"
                    {...form.register("description")}
                  />
                </Field>
              </div>
              <Field label="Incident time (optional)">
                <Input type="time" {...form.register("incidentTime")} />
              </Field>
              <Field label="Location (optional)">
                <Input
                  placeholder="City, State"
                  {...form.register("location")}
                />
              </Field>
              <Field label="Amount lost (₹, optional)">
                <Input
                  type="number"
                  min={0}
                  placeholder="0"
                  {...form.register("amountLost")}
                />
              </Field>
              <Field label="Suspect phone (optional)">
                <Input placeholder="+91…" {...form.register("suspectPhone")} />
              </Field>
              <Field
                label="Suspect email (optional)"
                error={form.formState.errors.suspectEmail?.message}
              >
                <Input
                  type="email"
                  placeholder="name@example.com"
                  {...form.register("suspectEmail")}
                />
              </Field>
              <Field label="Suspect website (optional)">
                <Input
                  placeholder="https://…"
                  {...form.register("suspectWebsite")}
                />
              </Field>
              <Field label="Transaction ID (optional)">
                <Input {...form.register("transactionId")} />
              </Field>
              <Field label="UPI ID (optional)">
                <Input placeholder="name@bank" {...form.register("upiId")} />
              </Field>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold">Upload evidence</h2>
            <p className="text-sm text-muted-foreground">
              Add screenshots, chat exports, emails or receipts. Max 10 files,
              20 MB each.
            </p>
            <label
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                onDrop(e.dataTransfer.files);
              }}
              className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-secondary/30 p-10 text-center transition hover:border-primary/50 hover:bg-secondary/50"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Upload className="h-6 w-6" />
              </div>
              <div className="text-sm font-medium">
                Drag & drop files here or click to browse
              </div>
              <div className="text-xs text-muted-foreground">
                PNG, JPG, PDF, MP4, MP3, ZIP — up to 20 MB each
              </div>
              <input
                type="file"
                multiple
                className="hidden"
                onChange={(e) => onDrop(e.target.files)}
              />
            </label>

            {files.length > 0 && (
              <ul className="divide-y divide-border rounded-xl border border-border">
                {files.map((f, i) => (
                  <li key={i} className="flex items-center gap-3 px-4 py-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-md bg-secondary text-muted-foreground">
                      <FileText className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">
                        {f.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {(f.size / 1024).toFixed(0)} KB
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setFiles((prev) => prev.filter((_, idx) => idx !== i))
                      }
                      className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                      aria-label="Remove file"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}

            <div className="flex items-start gap-3 rounded-lg border border-warning/30 bg-warning/10 p-3 text-xs text-warning-foreground">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
              <p>
                Never upload OTPs, passwords, or full card numbers. Mask
                sensitive data in screenshots.
              </p>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold">Your contact details</h2>
            <div className="grid gap-5 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Field
                  label="Full name"
                  error={form.formState.errors.fullName?.message}
                >
                  <Input
                    placeholder="As per government ID"
                    {...form.register("fullName")}
                  />
                </Field>
              </div>
              <Field
                label="Email"
                error={form.formState.errors.contactEmail?.message}
              >
                <Input
                  type="email"
                  placeholder="you@example.com"
                  {...form.register("contactEmail")}
                />
              </Field>
              <Field
                label="Phone"
                error={form.formState.errors.contactPhone?.message}
              >
                <Input placeholder="+91…" {...form.register("contactPhone")} />
              </Field>
            </div>
            <label className="flex items-start gap-3 rounded-lg border border-border bg-secondary/40 p-4">
              <input
                type="checkbox"
                className="mt-0.5 h-4 w-4 rounded border-border text-primary focus:ring-ring"
                {...form.register("consent")}
              />
              <span className="text-sm text-muted-foreground">
                I declare the information provided is true to the best of my
                knowledge and consent to its use for investigation purposes.
              </span>
            </label>
            {form.formState.errors.consent && (
              <p className="text-xs text-destructive">
                {form.formState.errors.consent.message}
              </p>
            )}
            <div className="flex items-center gap-2 rounded-lg border border-border bg-card p-4 text-xs text-muted-foreground">
              <ShieldCheck className="h-4 w-4 shrink-0 text-success" />
              Submissions are encrypted and tamper-evident. False reporting is a
              punishable offence.
            </div>
          </div>
        )}

        <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
          <Button
            type="button"
            variant="ghost"
            onClick={prev}
            disabled={step === 1}
          >
            <ArrowLeft className="mr-1 h-4 w-4" /> Back
          </Button>
          {step < 3 ? (
            <Button type="button" onClick={next}>
              Continue <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          ) : (
            <Button type="submit">Submit complaint</Button>
          )}
        </div>
      </form>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
