import { createFileRoute } from "@tanstack/react-router";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact · CyberShield" }] }),
  component: ContactPage,
});

function ContactPage() {
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    (e.currentTarget as HTMLFormElement).reset();
    toast.success("Message sent. We'll respond within 1 business day.");
  };
  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold sm:text-4xl">Get in touch</h1>
        <p className="mt-2 text-muted-foreground">
          For emergencies, please call 1930 first. For non-urgent queries, write
          to us.
        </p>
      </div>

      <div className="mt-12 grid gap-8 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-1">
          {[
            { icon: Phone, t: "Helpline", d: "1930 (24×7 toll-free)" },
            { icon: Mail, t: "Email", d: "support@cybershield.gov" },
            {
              icon: MapPin,
              t: "Headquarters",
              d: "Cyber Crime Coordination Centre, New Delhi",
            },
            {
              icon: Clock,
              t: "Office hours",
              d: "Mon–Sat · 9:00 AM – 6:00 PM",
            },
          ].map((c) => (
            <div key={c.t} className="card-elevated flex items-start gap-3 p-5">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <c.icon className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">
                  {c.t}
                </div>
                <div className="text-sm font-medium">{c.d}</div>
              </div>
            </div>
          ))}
        </div>

        <form
          onSubmit={submit}
          className="card-elevated p-6 sm:p-8 lg:col-span-2"
        >
          <h2 className="text-lg font-semibold">Send us a message</h2>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="name">Full name</Label>
              <Input id="name" required maxLength={120} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required maxLength={120} />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="subject">Subject</Label>
              <Input id="subject" required maxLength={200} />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="msg">Message</Label>
              <Textarea id="msg" rows={5} required maxLength={2000} />
            </div>
          </div>
          <div className="mt-6 flex items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">
              We respond within 1 business day.
            </p>
            <Button type="submit">Send message</Button>
          </div>
        </form>
      </div>
    </div>
  );
}
