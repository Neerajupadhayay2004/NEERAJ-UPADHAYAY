import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  Search,
  FileSearch,
  Clock,
  CheckCircle2,
  AlertCircle,
  UserCheck,
  FileText,
  ShieldAlert,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/track")({
  head: () => ({ meta: [{ title: "Track Your Case · CyberShield" }] }),
  component: TrackPage,
});

type Status =
  | "Pending"
  | "Assigned"
  | "Investigating"
  | "Need More Evidence"
  | "Resolved"
  | "Closed"
  | "Rejected";

const SAMPLE: Record<
  string,
  {
    id: string;
    title: string;
    category: string;
    status: Status;
    createdAt: string;
    officer?: string;
    timeline: { date: string; label: string; note?: string }[];
  }
> = {
  "CS-2026-DEMO01": {
    id: "CS-2026-DEMO01",
    title: "UPI fraud — fake delivery refund",
    category: "UPI Fraud",
    status: "Investigating",
    createdAt: "2026-06-22",
    officer: "Insp. R. Sharma",
    timeline: [
      { date: "2026-06-22", label: "Complaint registered" },
      {
        date: "2026-06-23",
        label: "Assigned to investigator",
        note: "Routed to Cyber Cell, Sector 5",
      },
      {
        date: "2026-06-25",
        label: "Bank coordination initiated",
        note: "Freeze request sent to beneficiary bank",
      },
      { date: "2026-06-28", label: "Evidence verified" },
    ],
  },
};

const statusMeta: Record<
  Status,
  { color: string; bg: string; icon: typeof Clock }
> = {
  Pending: { color: "text-warning", bg: "bg-warning/15", icon: Clock },
  Assigned: { color: "text-info", bg: "bg-info/15", icon: UserCheck },
  Investigating: {
    color: "text-primary",
    bg: "bg-primary/10",
    icon: FileSearch,
  },
  "Need More Evidence": {
    color: "text-warning",
    bg: "bg-warning/15",
    icon: AlertCircle,
  },
  Resolved: { color: "text-success", bg: "bg-success/15", icon: CheckCircle2 },
  Closed: {
    color: "text-muted-foreground",
    bg: "bg-secondary",
    icon: FileText,
  },
  Rejected: {
    color: "text-destructive",
    bg: "bg-destructive/15",
    icon: ShieldAlert,
  },
};

function TrackPage() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState<
    (typeof SAMPLE)[string] | null | "notfound"
  >(null);

  const search = (e: React.FormEvent) => {
    e.preventDefault();
    const key = query.trim().toUpperCase();
    if (!key) return;
    setResult(SAMPLE[key] ?? "notfound");
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold sm:text-4xl">Track your case</h1>
        <p className="mt-2 text-muted-foreground">
          Enter your case ID to view real-time investigation status.
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          Try the demo ID:{" "}
          <code className="rounded bg-secondary px-1.5 py-0.5 font-mono text-xs">
            CS-2026-DEMO01
          </code>
        </p>
      </div>

      <form onSubmit={search} className="mx-auto mt-6 flex max-w-xl gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="CS-2026-XXXXXX"
            className="pl-9 uppercase"
          />
        </div>
        <Button type="submit">Search</Button>
      </form>

      {result === "notfound" && (
        <div className="mx-auto mt-8 max-w-xl rounded-xl border border-dashed border-border bg-card p-8 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-warning/15 text-warning">
            <AlertCircle className="h-6 w-6" />
          </div>
          <h3 className="mt-4 font-semibold">No case found</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Check the case ID or{" "}
            <Link to="/report" className="text-primary hover:underline">
              file a new complaint
            </Link>
            .
          </p>
        </div>
      )}

      {result && result !== "notfound" && (
        <motion.div
          key={result.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-10 space-y-6"
        >
          <div className="card-elevated p-6 sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">
                  Case ID
                </div>
                <div className="font-mono text-lg font-semibold">
                  {result.id}
                </div>
                <h2 className="mt-2 text-xl font-bold">{result.title}</h2>
                <div className="mt-1 text-sm text-muted-foreground">
                  {result.category} · filed {result.createdAt}
                </div>
              </div>
              <StatusBadge status={result.status} />
            </div>
            {result.officer && (
              <div className="mt-5 flex items-center gap-3 rounded-lg border border-border bg-secondary/40 p-3">
                <UserCheck className="h-5 w-5 text-primary" />
                <div>
                  <div className="text-xs text-muted-foreground">
                    Assigned officer
                  </div>
                  <div className="text-sm font-medium">{result.officer}</div>
                </div>
              </div>
            )}
          </div>

          <div className="card-elevated p-6 sm:p-8">
            <h3 className="text-base font-semibold">Investigation timeline</h3>
            <ol className="mt-5 space-y-5">
              {result.timeline.map((t, i) => (
                <li key={i} className="relative pl-7">
                  <span className="absolute left-0 top-1.5 h-3 w-3 rounded-full bg-primary ring-4 ring-primary/15" />
                  {i < result.timeline.length - 1 && (
                    <span className="absolute left-[5px] top-5 h-full w-px bg-border" />
                  )}
                  <div className="text-xs text-muted-foreground">{t.date}</div>
                  <div className="font-medium">{t.label}</div>
                  {t.note && (
                    <div className="mt-0.5 text-sm text-muted-foreground">
                      {t.note}
                    </div>
                  )}
                </li>
              ))}
            </ol>
          </div>
        </motion.div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: Status }) {
  const m = statusMeta[status];
  const Icon = m.icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold ${m.bg} ${m.color}`}
    >
      <Icon className="h-3.5 w-3.5" /> {status}
    </span>
  );
}
