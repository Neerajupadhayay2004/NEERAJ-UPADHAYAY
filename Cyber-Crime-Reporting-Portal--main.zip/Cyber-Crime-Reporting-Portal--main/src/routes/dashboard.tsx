import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  FilePlus2,
  Activity,
  Bell,
  ShieldCheck,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  FileSearch,
} from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Citizen Dashboard · CyberShield" }] }),
  component: DashboardPage,
});

const stats = [
  {
    label: "Total Complaints",
    value: "4",
    delta: "+1 this month",
    up: true,
    icon: FileSearch,
  },
  {
    label: "Under Investigation",
    value: "2",
    delta: "Avg 6 days",
    up: true,
    icon: Activity,
  },
  {
    label: "Resolved",
    value: "1",
    delta: "₹14,200 recovered",
    up: true,
    icon: ShieldCheck,
  },
  {
    label: "Need Action",
    value: "1",
    delta: "More evidence requested",
    up: false,
    icon: Bell,
  },
];

const cases = [
  {
    id: "CS-2026-DEMO01",
    title: "UPI fraud — fake delivery refund",
    category: "UPI Fraud",
    status: "Investigating",
    date: "2026-06-22",
  },
  {
    id: "CS-2026-K3F92A",
    title: "Instagram account hacked",
    category: "Social Media Hacking",
    status: "Need More Evidence",
    date: "2026-06-10",
  },
  {
    id: "CS-2026-B71PQR",
    title: "Fake job offer — advance fee",
    category: "Job Scam",
    status: "Resolved",
    date: "2026-05-28",
  },
  {
    id: "CS-2026-Z2X8YK",
    title: "Phishing email impersonating bank",
    category: "Phishing",
    status: "Assigned",
    date: "2026-05-12",
  },
];

const statusClass: Record<string, string> = {
  Investigating: "bg-primary/10 text-primary",
  "Need More Evidence": "bg-warning/15 text-warning",
  Resolved: "bg-success/15 text-success",
  Assigned: "bg-info/15 text-info",
};

const notifications = [
  { t: "Officer added a note on CS-2026-DEMO01", d: "2 hours ago" },
  { t: "Evidence requested on CS-2026-K3F92A", d: "Yesterday" },
  { t: "Case CS-2026-B71PQR marked resolved", d: "2 days ago" },
];

function DashboardPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-12 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            Welcome back
          </div>
          <h1 className="mt-1 text-3xl font-bold sm:text-4xl">
            Citizen dashboard
          </h1>
          <p className="mt-2 text-muted-foreground">
            Manage your complaints and stay updated on investigations.
          </p>
        </div>
        <Button asChild>
          <Link to="/report">
            <FilePlus2 className="mr-1.5 h-4 w-4" /> New complaint
          </Link>
        </Button>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="card-elevated p-5"
          >
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <s.icon className="h-5 w-5" />
              </div>
              <span
                className={`inline-flex items-center text-xs font-medium ${s.up ? "text-success" : "text-warning"}`}
              >
                {s.up ? (
                  <ArrowUpRight className="h-3.5 w-3.5" />
                ) : (
                  <ArrowDownRight className="h-3.5 w-3.5" />
                )}
              </span>
            </div>
            <div className="mt-4 text-2xl font-bold">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              {s.delta}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="card-elevated overflow-hidden lg:col-span-2">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h3 className="text-base font-semibold">My complaints</h3>
            <Link
              to="/track"
              className="text-xs font-medium text-primary hover:underline"
            >
              View all
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/40 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 text-left font-medium">Case ID</th>
                  <th className="px-5 py-3 text-left font-medium">Title</th>
                  <th className="px-5 py-3 text-left font-medium">Status</th>
                  <th className="px-5 py-3 text-left font-medium">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {cases.map((c) => (
                  <tr key={c.id} className="hover:bg-secondary/30">
                    <td className="px-5 py-3 font-mono text-xs">{c.id}</td>
                    <td className="px-5 py-3">
                      <div className="font-medium">{c.title}</div>
                      <div className="text-xs text-muted-foreground">
                        {c.category}
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className={`inline-block rounded-full px-2.5 py-1 text-xs font-semibold ${statusClass[c.status] ?? "bg-secondary"}`}
                      >
                        {c.status}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-muted-foreground">
                      {c.date}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card-elevated p-5">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold">Recent activity</h3>
              <Bell className="h-4 w-4 text-muted-foreground" />
            </div>
            <ul className="mt-4 space-y-3">
              {notifications.map((n, i) => (
                <li key={i} className="flex gap-3 text-sm">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  <div>
                    <div>{n.t}</div>
                    <div className="text-xs text-muted-foreground">{n.d}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="card-elevated overflow-hidden">
            <div className="gov-gradient p-5 text-primary-foreground">
              <TrendingUp className="h-6 w-6" />
              <h3 className="mt-3 text-lg font-semibold">Recovery rate</h3>
              <p className="mt-1 text-sm opacity-90">
                Acting within 1 hour improves recovery odds by 70%.
              </p>
            </div>
            <div className="p-5">
              <Button asChild variant="outline" className="w-full">
                <Link to="/resources">View safety resources</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
