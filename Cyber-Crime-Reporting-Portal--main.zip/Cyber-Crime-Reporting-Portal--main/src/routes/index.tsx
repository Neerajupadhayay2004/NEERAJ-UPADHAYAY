import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  ShieldCheck,
  FileWarning,
  Search,
  Lock,
  Activity,
  Users,
  Phone,
  CreditCard,
  Smartphone,
  Mail,
  Globe,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import heroImg from "@/assets/hero-cyber.jpg";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CyberShield · Report Cyber Crimes Securely" },
      {
        name: "description",
        content:
          "Report online fraud, scams, hacking and other cyber crimes. Track investigations and access verified safety resources.",
      },
    ],
  }),
  component: HomePage,
});

const stats = [
  { label: "Cases Reported", value: "2.4M+" },
  { label: "Resolved Cases", value: "1.1M+" },
  { label: "Active Officers", value: "12,500" },
  { label: "States Covered", value: "28" },
];

const categories = [
  {
    icon: CreditCard,
    title: "Financial Fraud",
    desc: "UPI, card, banking & wallet fraud",
  },
  {
    icon: Smartphone,
    title: "Social Media Hacking",
    desc: "Account takeover & impersonation",
  },
  {
    icon: Mail,
    title: "Phishing & Email Scam",
    desc: "Suspicious links and messages",
  },
  {
    icon: Globe,
    title: "Fake Shopping Sites",
    desc: "Counterfeit ecommerce portals",
  },
  {
    icon: AlertTriangle,
    title: "Investment & Job Scam",
    desc: "Crypto, MLM, fake job offers",
  },
  { icon: Users, title: "Cyber Bullying", desc: "Harassment, stalking, abuse" },
];

const steps = [
  {
    n: "01",
    t: "Register your complaint",
    d: "Provide incident details and any suspect information you have.",
  },
  {
    n: "02",
    t: "Upload evidence securely",
    d: "Screenshots, chats, receipts — encrypted at rest.",
  },
  {
    n: "03",
    t: "Track investigation",
    d: "Get real-time updates as your case progresses.",
  },
  {
    n: "04",
    t: "Resolution & support",
    d: "Officers coordinate with banks, platforms & authorities.",
  },
];

function HomePage() {
  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-secondary/60 via-background to-background" />
        <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center lg:gap-8 lg:px-8 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground shadow-soft">
              <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
              National Cyber Crime Helpline — 1930 · 24×7
            </div>
            <h1 className="mt-5 text-4xl font-bold leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              Report cyber crime.
              <br />
              <span className="text-primary">Protect what matters.</span>
            </h1>
            <p className="mt-5 max-w-xl text-base text-muted-foreground sm:text-lg">
              A secure, citizen-first portal to report online fraud, hacking,
              scams and abuse — and track your case from complaint to
              resolution.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/report">
                  Report an Incident <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/track">Track Existing Case</Link>
              </Button>
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-muted-foreground">
              <div className="inline-flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5 text-success" /> End-to-end
                encrypted
              </div>
              <div className="inline-flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-success" /> Verified
                officers
              </div>
              <div className="inline-flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-success" /> ISO-27001
                aligned
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative"
          >
            <div className="relative overflow-hidden rounded-3xl border border-border shadow-elevated">
              <img
                src={heroImg}
                alt="Cybersecurity shield"
                className="aspect-[4/3] w-full object-cover"
                width={1600}
                height={1100}
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/40 via-transparent to-transparent" />
            </div>
            <div className="absolute -bottom-6 -left-6 hidden rounded-2xl border border-border bg-card p-4 shadow-elevated sm:block">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/15 text-success">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">
                    Avg response time
                  </div>
                  <div className="text-sm font-semibold text-foreground">
                    Under 24 hours
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* STATS */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-4 py-10 sm:px-6 md:grid-cols-4 lg:px-8">
          {stats.map((s) => (
            <div key={s.label} className="text-center md:text-left">
              <div className="font-display text-3xl font-bold text-primary md:text-4xl">
                {s.value}
              </div>
              <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="text-xs font-semibold uppercase tracking-wider text-accent">
            What can you report?
          </div>
          <h2 className="mt-2 text-3xl font-bold sm:text-4xl">
            Common cyber crime categories
          </h2>
          <p className="mt-3 text-muted-foreground">
            From financial fraud to harassment — our portal supports complaints
            across every major category.
          </p>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c) => (
            <motion.div
              key={c.title}
              whileHover={{ y: -3 }}
              className="card-elevated card-elevated-hover p-6"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <c.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-base font-semibold">{c.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{c.desc}</p>
              <Link
                to="/report"
                className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
              >
                Report this <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="border-y border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <div className="text-xs font-semibold uppercase tracking-wider text-accent">
              How it works
            </div>
            <h2 className="mt-2 text-3xl font-bold sm:text-4xl">
              Four simple steps
            </h2>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {steps.map((s) => (
              <div key={s.n} className="card-elevated p-6">
                <div className="font-display text-3xl font-bold text-primary/30">
                  {s.n}
                </div>
                <h3 className="mt-2 text-base font-semibold">{s.t}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES STRIP */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-3">
          {[
            {
              icon: FileWarning,
              title: "Evidence vault",
              desc: "Encrypted, tamper-evident storage with chain-of-custody logs.",
            },
            {
              icon: Activity,
              title: "Live case tracking",
              desc: "Status timeline, officer notes and resolution updates.",
            },
            {
              icon: Search,
              title: "Smart search",
              desc: "Look up cases by ID, phone, email, UPI or transaction.",
            },
          ].map((f) => (
            <div key={f.title} className="card-elevated p-7">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl gov-gradient text-primary-foreground">
                <f.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* HELPLINE CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl gov-gradient p-8 text-primary-foreground sm:p-12">
          <div className="grid items-center gap-6 lg:grid-cols-[1fr_auto]">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-medium backdrop-blur">
                <Phone className="h-3.5 w-3.5" /> Emergency Helpline
              </div>
              <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
                Lost money to a scam? Act fast.
              </h2>
              <p className="mt-2 max-w-2xl text-sm opacity-90 sm:text-base">
                For financial frauds, call <strong>1930</strong> within the
                first hour to maximize recovery chances. Our officers will guide
                you through the next steps.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg" variant="secondary">
                <Link to="/report">File Complaint</Link>
              </Button>
              <a
                href="tel:1930"
                className="inline-flex items-center justify-center rounded-md border border-white/30 bg-white/10 px-5 py-3 text-sm font-semibold backdrop-blur transition hover:bg-white/20"
              >
                Call 1930
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
