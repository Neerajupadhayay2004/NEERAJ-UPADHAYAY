import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { R as CircleCheck, _ as FileText, l as ShieldAlert, r as UserCheck, u as Search, v as FileSearch, w as Clock, z as CircleAlert } from "../_libs/lucide-react.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/track-CRS6nlpE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SAMPLE = { "CS-2026-DEMO01": {
	id: "CS-2026-DEMO01",
	title: "UPI fraud — fake delivery refund",
	category: "UPI Fraud",
	status: "Investigating",
	createdAt: "2026-06-22",
	officer: "Insp. R. Sharma",
	timeline: [
		{
			date: "2026-06-22",
			label: "Complaint registered"
		},
		{
			date: "2026-06-23",
			label: "Assigned to investigator",
			note: "Routed to Cyber Cell, Sector 5"
		},
		{
			date: "2026-06-25",
			label: "Bank coordination initiated",
			note: "Freeze request sent to beneficiary bank"
		},
		{
			date: "2026-06-28",
			label: "Evidence verified"
		}
	]
} };
var statusMeta = {
	Pending: {
		color: "text-warning",
		bg: "bg-warning/15",
		icon: Clock
	},
	Assigned: {
		color: "text-info",
		bg: "bg-info/15",
		icon: UserCheck
	},
	Investigating: {
		color: "text-primary",
		bg: "bg-primary/10",
		icon: FileSearch
	},
	"Need More Evidence": {
		color: "text-warning",
		bg: "bg-warning/15",
		icon: CircleAlert
	},
	Resolved: {
		color: "text-success",
		bg: "bg-success/15",
		icon: CircleCheck
	},
	Closed: {
		color: "text-muted-foreground",
		bg: "bg-secondary",
		icon: FileText
	},
	Rejected: {
		color: "text-destructive",
		bg: "bg-destructive/15",
		icon: ShieldAlert
	}
};
function TrackPage() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)(null);
	const search = (e) => {
		e.preventDefault();
		const key = query.trim().toUpperCase();
		if (!key) return;
		setResult(SAMPLE[key] ?? "notfound");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl font-bold sm:text-4xl",
						children: "Track your case"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted-foreground",
						children: "Enter your case ID to view real-time investigation status."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [
							"Try the demo ID:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "rounded bg-secondary px-1.5 py-0.5 font-mono text-xs",
								children: "CS-2026-DEMO01"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: search,
				className: "mx-auto mt-6 flex max-w-xl gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "CS-2026-XXXXXX",
						className: "pl-9 uppercase"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Search"
				})]
			}),
			result === "notfound" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-8 max-w-xl rounded-xl border border-dashed border-border bg-card p-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-warning/15 text-warning",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-6 w-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 font-semibold",
						children: "No case found"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							"Check the case ID or",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/report",
								className: "text-primary hover:underline",
								children: "file a new complaint"
							}),
							"."
						]
					})
				]
			}),
			result && result !== "notfound" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "mt-10 space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elevated p-6 sm:p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Case ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-lg font-semibold",
								children: result.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-xl font-bold",
								children: result.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [
									result.category,
									" · filed ",
									result.createdAt
								]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: result.status })]
					}), result.officer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center gap-3 rounded-lg border border-border bg-secondary/40 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "h-5 w-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "Assigned officer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium",
							children: result.officer
						})] })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elevated p-6 sm:p-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold",
						children: "Investigation timeline"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-5 space-y-5",
						children: result.timeline.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "relative pl-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1.5 h-3 w-3 rounded-full bg-primary ring-4 ring-primary/15" }),
								i < result.timeline.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-[5px] top-5 h-full w-px bg-border" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: t.date
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: t.label
								}),
								t.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-0.5 text-sm text-muted-foreground",
									children: t.note
								})
							]
						}, i))
					})]
				})]
			}, result.id)
		]
	});
}
function StatusBadge({ status }) {
	const m = statusMeta[status];
	const Icon = m.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold ${m.bg} ${m.color}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-3.5 w-3.5" }),
			" ",
			status
		]
	});
}
//#endregion
export { TrackPage as component };
