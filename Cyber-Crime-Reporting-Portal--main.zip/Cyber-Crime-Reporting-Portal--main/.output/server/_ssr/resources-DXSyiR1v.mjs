import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { F as TriangleAlert, O as BookOpen, S as CreditCard, h as Lock, m as Mail, o as Smartphone, s as Shield, x as ExternalLink } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resources-DXSyiR1v.js
var import_jsx_runtime = require_jsx_runtime();
var guides = [
	{
		icon: CreditCard,
		title: "Protect your bank & UPI",
		points: [
			"Never share OTPs",
			"Verify payee names before paying",
			"Use UPI PIN only for sending money, not receiving"
		]
	},
	{
		icon: Smartphone,
		title: "Secure your phone",
		points: [
			"Keep OS updated",
			"Install apps only from official stores",
			"Disable unknown sources"
		]
	},
	{
		icon: Mail,
		title: "Spot phishing",
		points: [
			"Check sender domain carefully",
			"Hover links before clicking",
			"Banks never ask for passwords"
		]
	},
	{
		icon: Lock,
		title: "Strong authentication",
		points: [
			"Enable 2FA everywhere",
			"Use a password manager",
			"Use unique passwords per site"
		]
	}
];
var dosDonts = {
	do: [
		"Report fraud to 1930 within 1 hour",
		"Preserve screenshots & transaction IDs",
		"Lock cards immediately on your bank app",
		"File a complaint on this portal"
	],
	dont: [
		"Share OTPs, PINs or CVVs with anyone",
		"Click suspicious links in SMS/WhatsApp",
		"Install screen-share apps on requests",
		"Trust unverified investment groups"
	]
};
function ResourcesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-3xl text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-3.5 w-3.5" }), " Awareness Library"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 text-3xl font-bold sm:text-4xl",
						children: "Stay one step ahead of cyber criminals"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted-foreground",
						children: "Verified guidance to help you and your family stay safe online."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-5 sm:grid-cols-2",
				children: guides.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elevated card-elevated-hover p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(g.icon, { className: "h-5 w-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-lg font-semibold",
							children: g.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2 text-sm text-muted-foreground",
							children: g.points.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-success" }),
									" ",
									p
								]
							}, p))
						})
					]
				}, g.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-5 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elevated p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-semibold text-success",
						children: "Do"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: dosDonts.do.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-success",
									children: "✓"
								}),
								" ",
								x
							]
						}, x))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elevated p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-semibold text-destructive",
						children: "Don't"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: dosDonts.dont.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "✗"
								}),
								" ",
								x
							]
						}, x))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 rounded-2xl border border-border bg-card p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-5 w-5 text-warning" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Beware of impersonators"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Official communication will always come from verified channels. CyberShield will never ask for money, OTPs or remote access to your device."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#",
							className: "mt-3 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline",
							children: [
								"Read verification guidelines",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3.5 w-3.5" })
							]
						})
					] })]
				})
			})
		]
	});
}
//#endregion
export { ResourcesPage as component };
