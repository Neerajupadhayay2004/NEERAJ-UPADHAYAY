//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C9qly1dK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/__root.tsx",
		children: [
			"/",
			"/contact",
			"/dashboard",
			"/login",
			"/report",
			"/resources",
			"/track"
		],
		preloads: ["/assets/index-DGPZjyij.js", "/assets/createLucideIcon-C-QYgx1g.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DGPZjyij.js"
		} }]
	},
	"/": {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B27R6PCo.js",
			"/assets/circle-check-B-3APb8j.js",
			"/assets/triangle-alert-CIiN9Kxk.js",
			"/assets/activity-BSxWAYAZ.js",
			"/assets/arrow-right-ofB6XohU.js",
			"/assets/smartphone-Dr2nTSjo.js",
			"/assets/lock-B5Yzeva8.js",
			"/assets/mail-BAuxIQkL.js",
			"/assets/phone-Dy_gwJzX.js",
			"/assets/search-FAJJ4-qd.js",
			"/assets/shield-check-1oz3Vwu-.js",
			"/assets/proxy-DrlPXxrg.js"
		]
	},
	"/contact": {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CkaJNz_a.js",
			"/assets/clock-LFCcagPA.js",
			"/assets/mail-BAuxIQkL.js",
			"/assets/phone-Dy_gwJzX.js",
			"/assets/input-Bd7mL9_E.js",
			"/assets/textarea-TZ-3C7FP.js",
			"/assets/label-BhsTOAyd.js"
		]
	},
	"/dashboard": {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-D2ks2eNV.js",
			"/assets/activity-BSxWAYAZ.js",
			"/assets/file-search-BVoULEFX.js",
			"/assets/shield-check-1oz3Vwu-.js",
			"/assets/proxy-DrlPXxrg.js"
		]
	},
	"/login": {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CpeDQo_c.js",
			"/assets/lock-B5Yzeva8.js",
			"/assets/mail-BAuxIQkL.js",
			"/assets/shield-check-1oz3Vwu-.js",
			"/assets/input-Bd7mL9_E.js",
			"/assets/label-BhsTOAyd.js"
		]
	},
	"/report": {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/report.tsx",
		children: void 0,
		preloads: [
			"/assets/report-DF-k1Kdv.js",
			"/assets/circle-check-B-3APb8j.js",
			"/assets/triangle-alert-CIiN9Kxk.js",
			"/assets/arrow-right-ofB6XohU.js",
			"/assets/file-text-j0O0C9BD.js",
			"/assets/shield-check-1oz3Vwu-.js",
			"/assets/input-Bd7mL9_E.js",
			"/assets/textarea-TZ-3C7FP.js",
			"/assets/label-BhsTOAyd.js",
			"/assets/proxy-DrlPXxrg.js"
		]
	},
	"/resources": {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/resources.tsx",
		children: void 0,
		preloads: [
			"/assets/resources-Bo1Ie0Mc.js",
			"/assets/triangle-alert-CIiN9Kxk.js",
			"/assets/smartphone-Dr2nTSjo.js",
			"/assets/lock-B5Yzeva8.js",
			"/assets/mail-BAuxIQkL.js"
		]
	},
	"/track": {
		filePath: "/home/neeraj/Downloads/Cyber-Crime-Reporting-Portal--main/src/routes/track.tsx",
		children: void 0,
		preloads: [
			"/assets/track-D5ZtvAs0.js",
			"/assets/circle-check-B-3APb8j.js",
			"/assets/clock-LFCcagPA.js",
			"/assets/file-search-BVoULEFX.js",
			"/assets/file-text-j0O0C9BD.js",
			"/assets/search-FAJJ4-qd.js",
			"/assets/input-Bd7mL9_E.js",
			"/assets/proxy-DrlPXxrg.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
