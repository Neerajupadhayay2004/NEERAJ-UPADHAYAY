# SentinelEye - Social Media Metadata Analyzer

<img width="1920" height="1080" alt="Screenshot_2026-06-17_12-31-45" src="https://github.com/user-attachments/assets/6f1152bc-d1ac-473c-8ced-05dfde988dcc" />
<img width="1920" height="1080" alt="Screenshot_2026-06-17_12-32-05" src="https://github.com/user-attachments/assets/fe848e9c-5b29-4880-b6df-e77eeb40acbd" />

## Overview

SentinelEye is an advanced OSINT (Open Source Intelligence), Digital Forensics, and Cyber Threat Intelligence platform designed to analyze publicly available metadata from images, URLs, and online content.

The platform helps cybersecurity researchers, digital investigators, threat intelligence analysts, SOC teams, and OSINT professionals identify potential threats, detect suspicious activities, analyze digital footprints, and generate intelligence reports.

---

## Key Features

### Image Metadata Analyzer

* EXIF Metadata Extraction
* GPS Coordinate Detection
* Camera & Device Information
* Timestamp Analysis
* Image Integrity Checks
* Metadata Anomaly Detection
* Privacy Risk Assessment
* Digital Evidence Collection

### URL Intelligence Analyzer

* Domain Analysis
* DNS Intelligence
* SSL Certificate Inspection
* WHOIS Information Analysis
* Redirect Chain Detection
* Suspicious Domain Detection
* Phishing Risk Assessment
* Domain Reputation Analysis

### Public Content Analyzer

* Keyword Intelligence
* Threat Classification
* Sentiment Analysis
* Entity Extraction
* Risk Indicator Detection
* Reputation Assessment
* Social Media Content Analysis
* Threat Intelligence Insights

### Investigation Management

* Case Tracking
* Evidence Management
* Investigation Timeline
* Notes & Observations
* Audit Logging
* Report Generation

### AI-Powered Intelligence Engine

* Threat Detection
* Scam Identification
* Content Classification
* Risk Scoring
* Pattern Recognition
* Reputation Analysis
* Confidence Scoring
* Automated Intelligence Summaries

---

## Technology Stack

### Frontend

* React.js
* TypeScript
* Tailwind CSS
* Recharts
* Framer Motion

### Backend

* Python
* FastAPI
* PostgreSQL
* Redis
* Celery

### AI & Machine Learning

* OpenAI
* LangChain
* Scikit-Learn
* Transformers
* Pandas
* NumPy

### Security Intelligence

* VirusTotal API
* AbuseIPDB
* SecurityTrails
* Shodan
* AlienVault OTX

---

## System Architecture

User Interface
↓
API Gateway
↓
Analysis Engine
├── Image Metadata Module
├── URL Intelligence Module
├── Content Intelligence Module
├── AI Analysis Engine
└── Risk Scoring Engine
↓
Database Layer
↓
Reporting Engine

---

## Core Modules

### 1. Image Metadata Checker

Analyzes uploaded images and extracts:

* EXIF Information
* GPS Data
* Device Information
* Timestamps
* Privacy Risks
* Metadata Manipulation Indicators

### 2. URL Analyzer

Investigates URLs and domains:

* Domain Registration Data
* DNS Records
* SSL Information
* Redirect Chains
* Threat Indicators
* Risk Classification

### 3. Public Content Analyzer

Processes public content and provides:

* Entity Recognition
* Keyword Extraction
* Threat Categorization
* Sentiment Analysis
* Reputation Insights

---

## Risk Classification Model

| Risk Level | Score  |
| ---------- | ------ |
| Low        | 0-30   |
| Medium     | 31-60  |
| High       | 61-80  |
| Critical   | 81-100 |

---

## Dashboard Features

* Intelligence Overview
* Threat Heatmaps
* Risk Distribution Charts
* Investigation Statistics
* Evidence Tracking
* AI Insights
* Activity Timeline
* Export Reports

---

## Security Features

* JWT Authentication
* Role-Based Access Control
* Audit Logging
* Secure File Uploads
* Rate Limiting
* Data Encryption
* Session Management

---

## Future Enhancements

* AI Copilot for Investigators
* Real-Time Threat Feeds
* Malware Intelligence Integration
* IOC Management
* Social Network Graph Analysis
* Deepfake Detection
* Advanced Entity Correlation
* Threat Hunting Workflows

---

## Ethical Usage

This platform is designed exclusively for:

* Cybersecurity Research
* Threat Intelligence
* Digital Forensics
* OSINT Investigations
* Academic Research
* Security Awareness

The platform must only analyze publicly available information and should never be used for unauthorized access, credential harvesting, hacking activities, or privacy violations.

---

## License

MIT License

---

## Author

Neeraj Upadhayay

Cybersecurity | OSINT | Threat Intelligence | Digital Forensics
