import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  try {
    const { url } = await req.json();
    if (!url) return new Response(JSON.stringify({ error: "URL is required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const norm = url.startsWith("http") ? url : `https://${url}`;
    let parsedUrl: URL;
    try { parsedUrl = new URL(norm); } catch { return new Response(JSON.stringify({ error: "Invalid URL" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }

    const domain = parsedUrl.hostname;

    // DNS resolution via Google DNS
    let dnsResults: Record<string, string[]> = {};
    try {
      const dnsResp = await fetch(`https://dns.google/resolve?name=${domain}&type=A`);
      const dnsData = await dnsResp.json();
      if (dnsData.Answer) {
        dnsData.Answer.forEach((a: any) => {
          const type = a.type === 1 ? "A" : a.type === 28 ? "AAAA" : a.type === 5 ? "CNAME" : a.type === 15 ? "MX" : a.type === 16 ? "TXT" : a.type === 2 ? "NS" : `TYPE${a.type}`;
          if (!dnsResults[type]) dnsResults[type] = [];
          dnsResults[type].push(a.data);
        });
      }
    } catch { dnsResults = { note: "DNS resolution unavailable" }; }

    // Additional DNS record types
    try {
      for (const rtype of ["MX", "TXT", "NS"]) {
        const resp = await fetch(`https://dns.google/resolve?name=${domain}&type=${rtype}`);
        const data = await resp.json();
        if (data.Answer) {
          data.Answer.forEach((a: any) => {
            const type = a.type === 15 ? "MX" : a.type === 16 ? "TXT" : a.type === 2 ? "NS" : `TYPE${a.type}`;
            if (!dnsResults[type]) dnsResults[type] = [];
            dnsResults[type].push(a.data);
          });
        }
      }
    } catch { /* best effort */ }

    // SSL check
    let sslData: Record<string, unknown> = {};
    try {
      const sslResp = await fetch(`https://api.ssllabs.com/api/v3/analyze?host=${domain}&publish=off&startNew=on`, { signal: AbortSignal.timeout(5000) });
      if (sslResp.ok) {
        const sslJson = await sslResp.json();
        sslData = { status: sslJson.status, grade: sslJson.endpoints?.[0]?.grade || "pending", hasSSL: true, note: "SSL Labs analysis initiated. Results may take a few minutes." };
      }
    } catch {
      sslData = { hasSSL: parsedUrl.protocol === "https:", valid: parsedUrl.protocol === "https:", note: "SSL check service unavailable — protocol-based check only" };
    }

    // URL structure analysis
    const pathSegs = parsedUrl.pathname.split("/").filter(Boolean);
    const urlStructure: Record<string, unknown> = {
      protocol: parsedUrl.protocol, hostname: parsedUrl.hostname, path: parsedUrl.pathname,
      pathDepth: pathSegs.length, hasHTTPS: parsedUrl.protocol === "https:",
      hasPort: parsedUrl.port !== "", hasQueryParams: parsedUrl.search !== "",
      paramCount: [...parsedUrl.searchParams.keys()].length, hasFragment: parsedUrl.hash !== "",
      subdomainCount: parsedUrl.hostname.split(".").length - 2,
      isIPAddress: /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(parsedUrl.hostname),
      tld: parsedUrl.hostname.split(".").pop(), domainLength: parsedUrl.hostname.length,
    };

    // Suspicious TLD check
    const suspiciousTLDs = [".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top", ".club", ".work", ".bid", ".loan", ".click", ".link", ".info", ".pw", ".cc"];
    const hasSuspiciousTLD = suspiciousTLDs.some(tld => domain.endsWith(tld));

    // Phishing indicators
    const phishingIndicators: Array<{ type: string; description: string; severity: string; confidence: number }> = [];
    const scamIndicators: Array<{ type: string; description: string; severity: string; confidence: number }> = [];

    // Brand impersonation detection
    const brands = ["paypal", "amazon", "apple", "microsoft", "google", "facebook", "netflix", "instagram", "twitter", "linkedin", "whatsapp", "tiktok", "spotify", "adobe", "dropbox", "chase", "wells", "bank", "coinbase", "binance"];
    const lowerHost = domain.toLowerCase();
    brands.forEach(b => {
      if (lowerHost.includes(b) && !lowerHost.includes(`${b}.com`) && !lowerHost.includes(`${b}.net`)) {
        phishingIndicators.push({ type: "brand_impersonation", description: `Possible "${b}" brand impersonation`, severity: "critical", confidence: 72 });
      }
    });

    if (urlStructure.isIPAddress) phishingIndicators.push({ type: "ip_host", description: "URL uses raw IP address", severity: "high", confidence: 90 });
    if (hasSuspiciousTLD) phishingIndicators.push({ type: "suspicious_tld", description: `Suspicious TLD: .${urlStructure.tld}`, severity: "high", confidence: 82 });
    if (!urlStructure.hasHTTPS) scamIndicators.push({ type: "no_https", description: "No SSL/TLS encryption", severity: "high", confidence: 98 });

    // Risk scoring
    let riskScore = 0;
    if (!urlStructure.hasHTTPS) riskScore += 15;
    if (urlStructure.isIPAddress) riskScore += 20;
    if (hasSuspiciousTLD) riskScore += 15;
    phishingIndicators.forEach(i => { riskScore += i.severity === "critical" ? 15 : i.severity === "high" ? 10 : 5; });
    scamIndicators.forEach(i => { riskScore += i.severity === "high" ? 10 : 5; });
    riskScore = Math.min(riskScore, 100);

    const riskLevel = riskScore >= 75 ? "critical" : riskScore >= 55 ? "high" : riskScore >= 35 ? "medium" : riskScore >= 15 ? "low" : "safe";

    const result = {
      url: norm, domain,
      whois_data: { domain, note: "Full WHOIS requires dedicated API", queryTime: new Date().toISOString() },
      ssl_data: sslData, dns_data: dnsResults, redirect_chain: [],
      domain_reputation: { domain, hasDNSRecords: Object.keys(dnsResults).length > 0, hasSuspiciousTLD, indicatorCount: phishingIndicators.length + scamIndicators.length },
      ip_intelligence: {}, hosting_data: { domain, isIPAddress: urlStructure.isIPAddress, note: "Full hosting data requires IP lookup API" },
      url_structure: urlStructure,
      risk_score: riskScore, risk_level: riskLevel,
      scam_indicators: scamIndicators, phishing_indicators: phishingIndicators,
      analysis_summary: { indicatorCount: phishingIndicators.length + scamIndicators.length, isHTTPS: urlStructure.hasHTTPS, isIP: urlStructure.isIPAddress, hasSuspiciousTLD, dnsRecordCount: Object.values(dnsResults).flat().length },
    };

    return new Response(JSON.stringify(result), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
