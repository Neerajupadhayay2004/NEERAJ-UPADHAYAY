-- Investigations table
CREATE TABLE investigations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paused', 'completed', 'archived')),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tags TEXT[] DEFAULT '{}',
  notes TEXT DEFAULT ''
);

-- Image analyses table
CREATE TABLE image_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  investigation_id UUID REFERENCES investigations(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_size BIGINT,
  file_type TEXT,
  mime_type TEXT,
  width INTEGER,
  height INTEGER,
  exif_data JSONB DEFAULT '{}',
  gps_data JSONB DEFAULT '{}',
  camera_data JSONB DEFAULT '{}',
  device_data JSONB DEFAULT '{}',
  timestamps JSONB DEFAULT '{}',
  metadata_anomalies JSONB DEFAULT '[]',
  risk_score INTEGER DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
  risk_level TEXT DEFAULT 'low' CHECK (risk_level IN ('safe', 'low', 'medium', 'high', 'critical')),
  analysis_summary JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

-- URL analyses table
CREATE TABLE url_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  investigation_id UUID REFERENCES investigations(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  domain TEXT,
  whois_data JSONB DEFAULT '{}',
  ssl_data JSONB DEFAULT '{}',
  dns_data JSONB DEFAULT '{}',
  redirect_chain JSONB DEFAULT '[]',
  domain_reputation JSONB DEFAULT '{}',
  ip_intelligence JSONB DEFAULT '{}',
  hosting_data JSONB DEFAULT '{}',
  url_structure JSONB DEFAULT '{}',
  risk_score INTEGER DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
  risk_level TEXT DEFAULT 'low' CHECK (risk_level IN ('safe', 'low', 'medium', 'high', 'critical')),
  scam_indicators JSONB DEFAULT '[]',
  phishing_indicators JSONB DEFAULT '[]',
  analysis_summary JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Content analyses table
CREATE TABLE content_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  investigation_id UUID REFERENCES investigations(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL CHECK (source_type IN ('social_post', 'comment', 'profile', 'website', 'description', 'other')),
  source_url TEXT,
  content TEXT NOT NULL,
  keywords JSONB DEFAULT '[]',
  entities JSONB DEFAULT '[]',
  sentiment JSONB DEFAULT '{}',
  trends JSONB DEFAULT '[]',
  risk_indicators JSONB DEFAULT '[]',
  reputation_data JSONB DEFAULT '{}',
  threat_indicators JSONB DEFAULT '[]',
  risk_score INTEGER DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
  risk_level TEXT DEFAULT 'low' CHECK (risk_level IN ('safe', 'low', 'medium', 'high', 'critical')),
  analysis_summary JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Evidence records table
CREATE TABLE evidence_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  investigation_id UUID NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL CHECK (source_type IN ('image', 'url', 'content')),
  source_id UUID NOT NULL,
  evidence_type TEXT NOT NULL,
  description TEXT,
  data JSONB DEFAULT '{}',
  confidence INTEGER DEFAULT 50 CHECK (confidence >= 0 AND confidence <= 100),
  is_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Audit logs table
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id UUID,
  details JSONB DEFAULT '{}',
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE investigations ENABLE ROW LEVEL SECURITY;
ALTER TABLE image_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE url_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE evidence_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Investigations policies
CREATE POLICY "select_own_investigations" ON investigations FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_investigations" ON investigations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_investigations" ON investigations FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_investigations" ON investigations FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Image analyses policies
CREATE POLICY "select_own_image_analyses" ON image_analyses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_image_analyses" ON image_analyses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_image_analyses" ON image_analyses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_image_analyses" ON image_analyses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- URL analyses policies
CREATE POLICY "select_own_url_analyses" ON url_analyses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_url_analyses" ON url_analyses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_url_analyses" ON url_analyses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_url_analyses" ON url_analyses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Content analyses policies
CREATE POLICY "select_own_content_analyses" ON content_analyses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_content_analyses" ON content_analyses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_content_analyses" ON content_analyses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_content_analyses" ON content_analyses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Evidence records policies
CREATE POLICY "select_own_evidence_records" ON evidence_records FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_evidence_records" ON evidence_records FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_evidence_records" ON evidence_records FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_evidence_records" ON evidence_records FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Audit logs policies (users can see their own logs)
CREATE POLICY "select_own_audit_logs" ON audit_logs FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_audit_logs" ON audit_logs FOR INSERT
  TO authenticated WITH CHECK (true);

-- Indexes for performance
CREATE INDEX idx_investigations_user_id ON investigations(user_id);
CREATE INDEX idx_investigations_status ON investigations(status);
CREATE INDEX idx_image_analyses_investigation_id ON image_analyses(investigation_id);
CREATE INDEX idx_url_analyses_investigation_id ON url_analyses(investigation_id);
CREATE INDEX idx_content_analyses_investigation_id ON content_analyses(investigation_id);
CREATE INDEX idx_evidence_records_investigation_id ON evidence_records(investigation_id);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);
