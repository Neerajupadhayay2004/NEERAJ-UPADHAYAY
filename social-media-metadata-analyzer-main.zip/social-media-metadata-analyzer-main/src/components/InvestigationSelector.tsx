import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useTheme } from '../hooks/useTheme';
import type { Investigation } from '../types';

interface InvestigationSelectorProps {
  investigations: Investigation[];
  activeInvestigation: Investigation | null;
  onSelect: (inv: Investigation | null) => void;
  onRefresh: () => void;
}

export default function InvestigationSelector({ investigations, activeInvestigation, onSelect, onRefresh }: InvestigationSelectorProps) {
  const { isDark } = useTheme();
  const [showNew, setShowNew] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Investigation['priority']>('medium');
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!title.trim()) return;
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    const { data } = await supabase.from('investigations').insert({ title, description, priority, user_id: user.id }).select().single();
    if (data) { onSelect(data); setShowNew(false); setTitle(''); setDescription(''); setPriority('medium'); onRefresh(); }
    setLoading(false);
  };

  return (
    <div className="card p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="label mb-0">Investigation Context</span>
        <button onClick={() => setShowNew(!showNew)} className="text-xs text-brand-500 hover:text-brand-400 font-semibold transition-colors">+ New</button>
      </div>
      {showNew && (
        <div className={`p-4 rounded-xl border space-y-3 animate-slide-up ${isDark ? 'bg-white/[0.03] border-white/[0.06]' : 'bg-surface-50 border-surface-200'}`}>
          <input type="text" value={title} onChange={e => setTitle(e.target.value)} className="input-base text-sm" placeholder="Investigation title..." />
          <textarea value={description} onChange={e => setDescription(e.target.value)} className="input-base text-sm resize-none" rows={2} placeholder="Description (optional)..." />
          <select value={priority} onChange={e => setPriority(e.target.value as Investigation['priority'])} className="input-base text-sm">
            <option value="low">Low Priority</option><option value="medium">Medium Priority</option><option value="high">High Priority</option><option value="critical">Critical Priority</option>
          </select>
          <div className="flex gap-2">
            <button onClick={handleCreate} disabled={loading || !title.trim()} className="btn-primary text-xs flex-1 disabled:opacity-50">{loading ? 'Creating...' : 'Create'}</button>
            <button onClick={() => setShowNew(false)} className="btn-secondary text-xs">Cancel</button>
          </div>
        </div>
      )}
      <select value={activeInvestigation?.id ?? ''} onChange={e => { const inv = investigations.find(i => i.id === e.target.value); onSelect(inv ?? null); }} className="input-base text-sm">
        <option value="">No active investigation</option>
        {investigations.map(inv => <option key={inv.id} value={inv.id}>{inv.title} ({inv.status})</option>)}
      </select>
    </div>
  );
}
