import type { RiskLevel } from '../types';
import { Shield, ShieldAlert, ShieldCheck, ShieldOff, ShieldQuestion } from 'lucide-react';
import { useTheme } from '../hooks/useTheme';

const riskConfig: Record<RiskLevel, { color: string; icon: any; label: string }> = {
  safe: { color: 'risk-safe', icon: ShieldCheck, label: 'Safe' },
  low: { color: 'risk-low', icon: Shield, label: 'Low' },
  medium: { color: 'risk-medium', icon: ShieldQuestion, label: 'Medium' },
  high: { color: 'risk-high', icon: ShieldAlert, label: 'High' },
  critical: { color: 'risk-critical', icon: ShieldOff, label: 'Critical' },
};

const strokeColors: Record<RiskLevel, Record<string, string>> = {
  safe: { dark: '#64748b', light: '#94a3b8' },
  low: { dark: '#22c55e', light: '#16a34a' },
  medium: { dark: '#eab308', light: '#ca8a04' },
  high: { dark: '#f97316', light: '#ea580c' },
  critical: { dark: '#f43f5e', light: '#e11d48' },
};

export default function RiskBadge({ level, score, size = 'sm' }: { level: RiskLevel; score?: number; size?: 'sm' | 'md' | 'lg' }) {
  const config = riskConfig[level];
  const Icon = config.icon;
  const sizeClasses = { sm: 'text-xs px-2 py-0.5', md: 'text-sm px-3 py-1', lg: 'text-sm px-4 py-1.5' };
  return (
    <span className={`badge ${config.color} ${sizeClasses[size]}`}>
      <Icon className={size === 'lg' ? 'w-4 h-4' : 'w-3 h-3'} />
      <span>{config.label}</span>
      {score !== undefined && <span className="ml-1 opacity-60 font-mono">{score}</span>}
    </span>
  );
}

export function RiskGauge({ score, level }: { score: number; level: RiskLevel }) {
  const { isDark } = useTheme();
  const config = riskConfig[level];
  const circumference = 2 * Math.PI * 40;
  const progress = (score / 100) * circumference;
  const color = strokeColors[level][isDark ? 'dark' : 'light'];

  return (
    <div className="relative w-28 h-28">
      <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="40" fill="none" strokeWidth="6" className={isDark ? 'stroke-white/[0.06]' : 'stroke-surface-200'} />
        <circle cx="50" cy="50" r="40" fill="none" stroke={color} strokeWidth="6"
          strokeDasharray={circumference} strokeDashoffset={circumference - progress}
          strokeLinecap="round" className="transition-all duration-1000"
          style={{ filter: isDark ? `drop-shadow(0 0 6px ${color}40)` : 'none' }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'}`}>{score}</span>
        <span className="text-[10px] font-mono uppercase" style={{ color }}>{config.label}</span>
      </div>
    </div>
  );
}

export function ConfidenceBar({ value, label }: { value: number; label?: string }) {
  const { isDark } = useTheme();
  const color = value >= 80 ? 'bg-success-500' : value >= 50 ? 'bg-warning-500' : 'bg-danger-500';
  return (
    <div>
      {label && <div className={`flex justify-between text-xs mb-1 ${isDark ? 'text-surface-400' : 'text-surface-500'}`}><span>{label}</span><span className="font-mono">{value}%</span></div>}
      <div className={`h-2 rounded-full overflow-hidden ${isDark ? 'bg-white/[0.06]' : 'bg-surface-100'}`}>
        <div className={`h-full ${color} rounded-full transition-all duration-500`} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}
