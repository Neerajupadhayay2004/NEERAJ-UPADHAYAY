import { useState } from 'react';
import { Shield, Mail, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useTheme } from '../hooks/useTheme';

interface AuthFormProps {
  onSignIn: (email: string, password: string) => Promise<void>;
  onSignUp: (email: string, password: string) => Promise<void>;
}

export default function AuthForm({ onSignIn, onSignUp }: AuthFormProps) {
  const { isDark } = useTheme();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try { if (isSignUp) await onSignUp(email, password); else await onSignIn(email, password); }
    catch (err: any) { setError(err.message || 'Authentication failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className={`min-h-screen flex items-center justify-center transition-colors duration-300 ${isDark ? 'bg-[#0a0f1a]' : 'bg-surface-100'}`}>
      <div className={`absolute inset-0 ${isDark ? 'opacity-[0.03]' : 'opacity-[0.04]'}`} style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)', backgroundSize: '32px 32px' }} />
      <div className="relative w-full max-w-md mx-4 animate-fade-in">
        <div className="text-center mb-8">
          <div className={`w-16 h-16 mx-auto rounded-2xl flex items-center justify-center shadow-xl transition-all duration-300 ${isDark ? 'bg-brand-600 shadow-brand-600/30' : 'bg-brand-600 shadow-brand-600/20'}`}>
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className={`text-2xl font-bold tracking-tight mt-4 ${isDark ? 'text-white' : 'text-surface-900'}`}>SentinelEye</h1>
          <p className={`text-sm mt-1 ${isDark ? 'text-surface-400' : 'text-surface-500'}`}>OSINT Metadata Analyzer Platform</p>
        </div>

        <div className="card p-8">
          <h2 className={`text-lg font-semibold mb-1 ${isDark ? 'text-white' : 'text-surface-900'}`}>{isSignUp ? 'Create Account' : 'Welcome back'}</h2>
          <p className={`text-sm mb-6 ${isDark ? 'text-surface-400' : 'text-surface-500'}`}>{isSignUp ? 'Set up your investigator account' : 'Sign in to your investigation dashboard'}</p>

          {error && (
            <div className={`mb-4 p-3 rounded-xl flex items-center gap-2 text-sm border ${isDark ? 'bg-danger-500/10 border-danger-500/30 text-danger-400' : 'bg-danger-50 border-danger-200 text-danger-700'}`}>
              <AlertCircle className="w-4 h-4 flex-shrink-0" /><span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <div className="relative">
                <Mail className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDark ? 'text-surface-500' : 'text-surface-400'}`} />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="input-base pl-10" placeholder="analyst@example.com" required />
              </div>
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDark ? 'text-surface-500' : 'text-surface-400'}`} />
                <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} className="input-base pl-10 pr-10" placeholder="Minimum 6 characters" required minLength={6} />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className={`absolute right-3 top-1/2 -translate-y-1/2 ${isDark ? 'text-surface-500 hover:text-surface-300' : 'text-surface-400 hover:text-surface-600'}`}>
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed">{loading ? 'Processing...' : isSignUp ? 'Create Account' : 'Sign In'}</button>
          </form>

          <div className="mt-6 text-center">
            <button onClick={() => { setIsSignUp(!isSignUp); setError(''); }} className={`text-sm transition-colors ${isDark ? 'text-surface-400 hover:text-brand-400' : 'text-surface-500 hover:text-brand-600'}`}>
              {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </button>
          </div>
        </div>

        <div className={`mt-6 text-center text-xs ${isDark ? 'text-surface-600' : 'text-surface-400'}`}>For authorized OSINT research & digital forensics only</div>
      </div>
    </div>
  );
}
