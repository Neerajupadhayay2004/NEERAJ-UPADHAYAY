import { useState } from 'react';
import {
  Shield, Scan, Globe, FileText, FolderOpen, FileSearch,
  BarChart3, LogOut, ChevronRight, Sun, Moon, Menu, X
} from 'lucide-react';
import { useTheme } from '../hooks/useTheme';
import type { Page, Investigation } from '../types';

interface SidebarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  activeInvestigation: Investigation | null;
  onSignOut: () => void;
}

const navItems: { page: Page; icon: any; label: string; desc: string }[] = [
  { page: 'dashboard', icon: BarChart3, label: 'Dashboard', desc: 'Overview' },
  { page: 'image-analyzer', icon: Scan, label: 'Image Analyzer', desc: 'EXIF & Metadata' },
  { page: 'url-analyzer', icon: Globe, label: 'URL Analyzer', desc: 'Domain Intel' },
  { page: 'content-analyzer', icon: FileText, label: 'Content Analyzer', desc: 'NLP & Sentiment' },
  { page: 'investigations', icon: FolderOpen, label: 'Investigations', desc: 'Case Manager' },
  { page: 'evidence', icon: FileSearch, label: 'Evidence', desc: 'Findings' },
  { page: 'reports', icon: BarChart3, label: 'Reports', desc: 'Analytics' },
];

export default function Sidebar({ currentPage, setCurrentPage, activeInvestigation, onSignOut }: SidebarProps) {
  const { toggleTheme, isDark } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);

  const NavContent = () => (
    <>
      {/* Logo */}
      <div className="px-5 py-5 border-b dark:border-white/[0.06] light:border-surface-200">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg transition-all duration-300 ${isDark ? 'bg-brand-600 shadow-brand-600/30' : 'bg-brand-600 shadow-brand-600/20'}`}>
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className={`text-[15px] font-bold tracking-tight ${isDark ? 'text-white' : 'text-surface-900'}`}>SentinelEye</h1>
            <p className="text-[10px] text-brand-500 font-mono tracking-wider uppercase">OSINT Platform</p>
          </div>
        </div>
      </div>

      {/* Active Investigation */}
      {activeInvestigation && (
        <div className={`mx-3 mt-3 p-3 rounded-xl border transition-colors ${isDark ? 'bg-brand-500/10 border-brand-500/20' : 'bg-brand-50 border-brand-200'}`}>
          <p className="text-[10px] font-mono text-brand-500 uppercase tracking-wider mb-0.5">Active Case</p>
          <p className={`text-sm font-medium truncate ${isDark ? 'text-brand-300' : 'text-brand-800'}`}>{activeInvestigation.title}</p>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(({ page, icon: Icon, label, desc }) => (
          <button
            key={page}
            onClick={() => { setCurrentPage(page); setMobileOpen(false); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-200 group ${
              currentPage === page
                ? isDark ? 'bg-brand-500/15 text-brand-400 border border-brand-500/20' : 'bg-brand-50 text-brand-700 border border-brand-200'
                : isDark ? 'text-surface-400 hover:bg-white/[0.04] hover:text-surface-200 border border-transparent' : 'text-surface-600 hover:bg-surface-50 hover:text-surface-900 border border-transparent'
            }`}
          >
            <Icon className={`w-[18px] h-[18px] ${currentPage === page ? (isDark ? 'text-brand-400' : 'text-brand-600') : (isDark ? 'text-surface-500 group-hover:text-surface-300' : 'text-surface-400 group-hover:text-surface-600')}`} />
            <div className="flex-1 text-left">
              <div className="font-medium leading-tight">{label}</div>
              <div className={`text-[11px] leading-tight ${isDark ? 'text-surface-500' : 'text-surface-400'}`}>{desc}</div>
            </div>
            {currentPage === page && <ChevronRight className={`w-3.5 h-3.5 ${isDark ? 'text-brand-500' : 'text-brand-400'}`} />}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className={`p-3 border-t ${isDark ? 'border-white/[0.06]' : 'border-surface-200'} space-y-1`}>
        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-200 ${
            isDark ? 'text-surface-400 hover:bg-white/[0.06] hover:text-yellow-400' : 'text-surface-500 hover:bg-surface-50 hover:text-brand-600'
          }`}
        >
          {isDark ? <Sun className="w-[18px] h-[18px]" /> : <Moon className="w-[18px] h-[18px]" />}
          <span>{isDark ? 'Light Mode' : 'Dark Mode'}</span>
        </button>
        {/* Sign Out */}
        <button
          onClick={onSignOut}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${
            isDark ? 'text-surface-500 hover:bg-danger-500/10 hover:text-danger-400' : 'text-surface-500 hover:bg-danger-50 hover:text-danger-600'
          }`}
        >
          <LogOut className="w-[18px] h-[18px]" />
          <span>Sign Out</span>
        </button>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile hamburger */}
      <button
        onClick={() => setMobileOpen(true)}
        className={`lg:hidden fixed top-4 left-4 z-[60] p-2 rounded-xl backdrop-blur-md transition-colors ${
          isDark ? 'bg-[#111827]/80 text-white border border-white/10' : 'bg-white/80 text-surface-900 border border-surface-200'
        }`}
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-[70] bg-black/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)}>
          <div className={`w-[280px] h-full flex flex-col ${isDark ? 'bg-[#0a0f1a] border-r border-white/[0.06]' : 'bg-white border-r border-surface-200'}`} onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-4">
              <span className={`text-sm font-semibold ${isDark ? 'text-white' : 'text-surface-900'}`}>Menu</span>
              <button onClick={() => setMobileOpen(false)} className={isDark ? 'text-surface-400 hover:text-white' : 'text-surface-400 hover:text-surface-900'}><X className="w-5 h-5" /></button>
            </div>
            <NavContent />
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <aside className={`hidden lg:flex fixed left-0 top-0 bottom-0 w-[260px] flex-col z-50 transition-colors duration-300 ${
        isDark ? 'bg-[#0a0f1a]/95 backdrop-blur-xl border-r border-white/[0.06]' : 'bg-white border-r border-surface-200'
      }`}>
        <NavContent />
      </aside>
    </>
  );
}
