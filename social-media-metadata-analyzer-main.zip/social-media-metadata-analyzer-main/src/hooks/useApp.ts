import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Page, Investigation, DashboardStats } from '../types';

export function useApp() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [investigations, setInvestigations] = useState<Investigation[]>([]);
  const [activeInvestigation, setActiveInvestigation] = useState<Investigation | null>(null);
  const [stats, setStats] = useState<DashboardStats>({
    totalInvestigations: 0,
    activeInvestigations: 0,
    imageAnalyses: 0,
    urlAnalyses: 0,
    contentAnalyses: 0,
    evidenceCount: 0,
    criticalFindings: 0,
    averageRiskScore: 0,
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchInvestigations = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('investigations')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false });
    if (data) setInvestigations(data);
  }, [user]);

  const fetchStats = useCallback(async () => {
    if (!user) return;
    const [inv, img, url, content, evidence] = await Promise.all([
      supabase.from('investigations').select('id, status, priority').eq('user_id', user.id),
      supabase.from('image_analyses').select('risk_score, risk_level').eq('user_id', user.id),
      supabase.from('url_analyses').select('risk_score, risk_level').eq('user_id', user.id),
      supabase.from('content_analyses').select('risk_score, risk_level').eq('user_id', user.id),
      supabase.from('evidence_records').select('id').eq('user_id', user.id),
    ]);

    const allRisks = [
      ...(img.data?.map(d => d.risk_score) ?? []),
      ...(url.data?.map(d => d.risk_score) ?? []),
      ...(content.data?.map(d => d.risk_score) ?? []),
    ];
    const criticalCount = [
      ...(img.data?.filter(d => d.risk_level === 'critical' || d.risk_level === 'high') ?? []),
      ...(url.data?.filter(d => d.risk_level === 'critical' || d.risk_level === 'high') ?? []),
      ...(content.data?.filter(d => d.risk_level === 'critical' || d.risk_level === 'high') ?? []),
    ].length;

    setStats({
      totalInvestigations: inv.data?.length ?? 0,
      activeInvestigations: inv.data?.filter(i => i.status === 'active').length ?? 0,
      imageAnalyses: img.data?.length ?? 0,
      urlAnalyses: url.data?.length ?? 0,
      contentAnalyses: content.data?.length ?? 0,
      evidenceCount: evidence.data?.length ?? 0,
      criticalFindings: criticalCount,
      averageRiskScore: allRisks.length > 0 ? Math.round(allRisks.reduce((a, b) => a + b, 0) / allRisks.length) : 0,
    });
  }, [user]);

  useEffect(() => {
    fetchInvestigations();
    fetchStats();
  }, [fetchInvestigations, fetchStats]);

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) throw error;
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setActiveInvestigation(null);
  };

  return {
    currentPage, setCurrentPage,
    user, loading,
    investigations, setInvestigations, fetchInvestigations,
    activeInvestigation, setActiveInvestigation,
    stats, fetchStats,
    signUp, signIn, signOut,
  };
}
