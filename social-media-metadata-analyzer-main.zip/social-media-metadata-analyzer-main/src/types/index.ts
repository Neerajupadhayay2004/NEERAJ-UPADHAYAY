export type RiskLevel = 'safe' | 'low' | 'medium' | 'high' | 'critical';
export type InvestigationStatus = 'active' | 'paused' | 'completed' | 'archived';
export type Priority = 'low' | 'medium' | 'high' | 'critical';
export type SourceType = 'social_post' | 'comment' | 'profile' | 'website' | 'description' | 'other';

export interface Investigation {
  id: string;
  title: string;
  description: string | null;
  status: InvestigationStatus;
  priority: Priority;
  created_at: string;
  updated_at: string;
  user_id: string;
  tags: string[];
  notes: string;
}

export interface ImageAnalysis {
  id: string;
  investigation_id: string | null;
  file_name: string;
  file_size: number | null;
  file_type: string | null;
  mime_type: string | null;
  width: number | null;
  height: number | null;
  exif_data: Record<string, unknown>;
  gps_data: Record<string, unknown>;
  camera_data: Record<string, unknown>;
  device_data: Record<string, unknown>;
  timestamps: Record<string, unknown>;
  metadata_anomalies: MetadataAnomaly[];
  risk_score: number;
  risk_level: RiskLevel;
  analysis_summary: Record<string, unknown>;
  created_at: string;
  user_id: string;
}

export interface URLAnalysis {
  id: string;
  investigation_id: string | null;
  url: string;
  domain: string | null;
  whois_data: Record<string, unknown>;
  ssl_data: Record<string, unknown>;
  dns_data: Record<string, unknown>;
  redirect_chain: RedirectEntry[];
  domain_reputation: Record<string, unknown>;
  ip_intelligence: Record<string, unknown>;
  hosting_data: Record<string, unknown>;
  url_structure: Record<string, unknown>;
  risk_score: number;
  risk_level: RiskLevel;
  scam_indicators: Indicator[];
  phishing_indicators: Indicator[];
  analysis_summary: Record<string, unknown>;
  created_at: string;
  user_id: string;
}

export interface ContentAnalysis {
  id: string;
  investigation_id: string | null;
  source_type: SourceType;
  source_url: string | null;
  content: string;
  keywords: KeywordEntry[];
  entities: EntityEntry[];
  sentiment: SentimentData;
  trends: TrendEntry[];
  risk_indicators: Indicator[];
  reputation_data: Record<string, unknown>;
  threat_indicators: Indicator[];
  risk_score: number;
  risk_level: RiskLevel;
  analysis_summary: Record<string, unknown>;
  created_at: string;
  user_id: string;
}

export interface EvidenceRecord {
  id: string;
  investigation_id: string;
  source_type: 'image' | 'url' | 'content';
  source_id: string;
  evidence_type: string;
  description: string | null;
  data: Record<string, unknown>;
  confidence: number;
  is_verified: boolean;
  created_at: string;
  user_id: string;
}

export interface AuditLog {
  id: string;
  user_id: string | null;
  action: string;
  resource_type: string;
  resource_id: string | null;
  details: Record<string, unknown>;
  ip_address: string | null;
  created_at: string;
}

export interface MetadataAnomaly {
  type: string;
  field: string;
  description: string;
  severity: RiskLevel;
}

export interface RedirectEntry {
  url: string;
  status_code: number;
  timestamp: string;
}

export interface Indicator {
  type: string;
  description: string;
  severity: RiskLevel;
  confidence: number;
}

export interface KeywordEntry {
  keyword: string;
  frequency: number;
  relevance: number;
  category: string;
}

export interface EntityEntry {
  entity: string;
  type: string;
  frequency: number;
  relevance: number;
}

export interface SentimentData {
  overall: number;
  positive: number;
  negative: number;
  neutral: number;
}

export interface TrendEntry {
  topic: string;
  frequency: number;
  trend_direction: 'up' | 'down' | 'stable';
  relevance: number;
}

export type Page = 'dashboard' | 'image-analyzer' | 'url-analyzer' | 'content-analyzer' | 'investigations' | 'evidence' | 'reports';

export interface DashboardStats {
  totalInvestigations: number;
  activeInvestigations: number;
  imageAnalyses: number;
  urlAnalyses: number;
  contentAnalyses: number;
  evidenceCount: number;
  criticalFindings: number;
  averageRiskScore: number;
}
