import AuthForm from './components/AuthForm';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import ImageAnalyzer from './pages/ImageAnalyzer';
import URLAnalyzer from './pages/URLAnalyzer';
import ContentAnalyzer from './pages/ContentAnalyzer';
import Investigations from './pages/Investigations';
import Evidence from './pages/Evidence';
import Reports from './pages/Reports';
import { ThemeContext, useThemeProvider } from './hooks/useTheme';
import { useApp } from './hooks/useApp';

function AppInner() {
  const themeCtx = useThemeProvider();
  const {
    currentPage, setCurrentPage,
    user, loading,
    investigations, fetchInvestigations,
    activeInvestigation, setActiveInvestigation,
    stats, fetchStats,
    signUp, signIn, signOut,
  } = useApp();

  if (loading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${themeCtx.isDark ? 'bg-[#0a0f1a]' : 'bg-surface-100'}`}>
        <div className="text-center">
          <div className={`w-10 h-10 border-2 rounded-full animate-spin mx-auto mb-4 ${themeCtx.isDark ? 'border-brand-500/30 border-t-brand-500' : 'border-brand-200 border-t-brand-600'}`} />
          <p className={`text-sm font-mono ${themeCtx.isDark ? 'text-surface-500' : 'text-surface-400'}`}>Initializing SentinelEye...</p>
        </div>
      </div>
    );
  }

  if (!user) return <AuthForm onSignIn={signIn} onSignUp={signUp} />;

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <Dashboard stats={stats} setCurrentPage={setCurrentPage} />;
      case 'image-analyzer': return <ImageAnalyzer investigations={investigations} activeInvestigation={activeInvestigation} onSelectInvestigation={setActiveInvestigation} onRefreshInvestigations={fetchInvestigations} onRefreshStats={fetchStats} />;
      case 'url-analyzer': return <URLAnalyzer investigations={investigations} activeInvestigation={activeInvestigation} onSelectInvestigation={setActiveInvestigation} onRefreshInvestigations={fetchInvestigations} onRefreshStats={fetchStats} />;
      case 'content-analyzer': return <ContentAnalyzer investigations={investigations} activeInvestigation={activeInvestigation} onSelectInvestigation={setActiveInvestigation} onRefreshInvestigations={fetchInvestigations} onRefreshStats={fetchStats} />;
      case 'investigations': return <Investigations investigations={investigations} activeInvestigation={activeInvestigation} onSelectInvestigation={setActiveInvestigation} onRefreshInvestigations={fetchInvestigations} onRefreshStats={fetchStats} />;
      case 'evidence': return <Evidence activeInvestigation={activeInvestigation} onRefreshStats={fetchStats} />;
      case 'reports': return <Reports onRefreshStats={fetchStats} />;
      default: return <Dashboard stats={stats} setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <ThemeContext.Provider value={themeCtx}>
      <div className={`min-h-screen transition-colors duration-300 ${themeCtx.isDark ? 'bg-[#0a0f1a]' : 'bg-surface-100'}`}>
        <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} activeInvestigation={activeInvestigation} onSignOut={signOut} />
        <main className="lg:ml-[260px] min-h-screen p-4 sm:p-6 pt-16 lg:pt-6 bg-grid-pattern">
          <div className="relative max-w-6xl mx-auto">
            {renderPage()}
          </div>
        </main>
      </div>
    </ThemeContext.Provider>
  );
}

export default function App() {
  return <AppInner />;
}
