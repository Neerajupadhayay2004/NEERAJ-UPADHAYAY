import { useState, useEffect } from 'react';
import { FileSearch, Image, Globe, FileText, CheckCircle2, XCircle, AlertTriangle, Filter } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useTheme } from '../hooks/useTheme';
import type { EvidenceRecord } from '../types';

type Investigation = { id: string; title: string; description: string | null; status: string; priority: string; created_at: string; updated_at: string; user_id: string; tags: string[]; notes: string; };

interface EvidenceProps { activeInvestigation: Investigation | null; onRefreshStats: () => void; }

export default function Evidence({ activeInvestigation, onRefreshStats }: EvidenceProps) {
  const { isDark } = useTheme();
  const [evidence, setEvidence] = useState<EvidenceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterSource, setFilterSource] = useState('all');
  const [filterVerified, setFilterVerified] = useState('all');

  useEffect(() => { fetchEvidence(); }, [activeInvestigation]);

  const fetchEvidence = async () => {
    setLoading(true);
    let q = supabase.from('evidence_records').select('*').order('created_at', { ascending: false });
    if (activeInvestigation) q = q.eq('investigation_id', activeInvestigation.id);
    const { data } = await q;
    setEvidence(data || []); setLoading(false);
  };

  const toggleVerified = async (id: string, current: boolean) => { await supabase.from('evidence_records').update({ is_verified: !current }).eq('id', id); fetchEvidence(); };
  const deleteEvidence = async (id: string) => { await supabase.from('evidence_records').delete().eq('id', id); fetchEvidence(); onRefreshStats(); };

  const filtered = evidence.filter(e => {
    if (filterSource !== 'all' && e.source_type !== filterSource) return false;
    if (filterVerified === 'verified' && !e.is_verified) return false;
    if (filterVerified === 'unverified' && e.is_verified) return false;
    return true;
  });

  const srcIcons: Record<string, any> = { image: Image, url: Globe, content: FileText };
  const srcColors: Record<string, string> = {
    image: isDark ? 'bg-brand-500/10 text-brand-400' : 'bg-brand-50 text-brand-600',
    url: isDark ? 'bg-success-500/10 text-success-400' : 'bg-success-50 text-success-600',
    content: isDark ? 'bg-warning-500/10 text-warning-400' : 'bg-warning-50 text-warning-600'
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'} flex items-center gap-3`}><FileSearch className="w-6 h-6 text-brand-500" /> Evidence Board</h1>
        <p className="text-sm text-surface-500 mt-0.5">{activeInvestigation ? `Evidence for: ${activeInvestigation.title}` : 'All evidence records across investigations'}</p>
      </div>

      <div className="card p-4 flex flex-wrap items-center gap-4">
        <Filter className="w-4 h-4 text-surface-400" />
        <select value={filterSource} onChange={e => setFilterSource(e.target.value)} className="input-base text-xs w-auto"><option value="all">All Sources</option><option value="image">Image</option><option value="url">URL</option><option value="content">Content</option></select>
        <select value={filterVerified} onChange={e => setFilterVerified(e.target.value)} className="input-base text-xs w-auto"><option value="all">All Status</option><option value="verified">Verified</option><option value="unverified">Unverified</option></select>
        <span className="text-xs text-surface-400 ml-auto">{filtered.length} records</span>
      </div>

      {loading ? (
        <div className="card p-12 text-center"><div className="w-8 h-8 border-2 border-brand-200 border-t-brand-600 rounded-full animate-spin mx-auto mb-3" /><p className="text-sm text-surface-500">Loading evidence...</p></div>
      ) : filtered.length === 0 ? (
        <div className="card p-12 text-center"><FileSearch className="w-12 h-12 mx-auto text-surface-300 mb-3" /><p className={`${isDark ? 'text-surface-300' : 'text-surface-600'} font-medium`}>No evidence records found</p><p className="text-sm text-surface-400 mt-1">Evidence is created automatically from analysis results</p></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map(ev => {
            const SrcIcon = srcIcons[ev.source_type] || FileText;
            const color = srcColors[ev.source_type] || 'bg-surface-50 text-surface-600';
            return (
              <div key={ev.id} className="card-hover p-4">
                <div className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${color}`}><SrcIcon className="w-4 h-4" /></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1"><span className={`badge ${isDark ? 'bg-white/[0.03] border-white/[0.06] text-surface-400' : 'bg-surface-50 border-surface-200 text-surface-600'}`}>{ev.evidence_type}</span><span className="text-xs text-surface-400 font-mono">Confidence: {ev.confidence}%</span></div>
                    {ev.description && <p className={`text-xs ${isDark ? 'text-surface-300' : 'text-surface-700'} mb-2`}>{ev.description}</p>}
                    <div className="flex items-center gap-3 text-xs text-surface-400">
                      <span>{new Date(ev.created_at).toLocaleDateString()}</span>
                      {ev.is_verified ? <span className={`flex items-center gap-1 ${isDark ? 'text-success-400' : 'text-success-600'}`}><CheckCircle2 className="w-3 h-3" />Verified</span> : <span className={`flex items-center gap-1 ${isDark ? 'text-warning-400' : 'text-warning-600'}`}><XCircle className="w-3 h-3" />Unverified</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => toggleVerified(ev.id, ev.is_verified)} className="btn-ghost text-xs" title={ev.is_verified ? 'Unverify' : 'Verify'}>{ev.is_verified ? <XCircle className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}</button>
                    <button onClick={() => deleteEvidence(ev.id)} className={`btn-ghost text-xs ${isDark ? 'hover:!text-danger-400 hover:!bg-danger-500/10' : 'hover:!text-danger-600 hover:!bg-danger-50'}`} title="Delete"><AlertTriangle className="w-3 h-3" /></button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
