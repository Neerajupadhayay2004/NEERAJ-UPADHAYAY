import { useState } from 'react';
import {
  FolderOpen, Plus, Clock, Tag, Edit3, Trash2,
  Pause, Play, Archive, CheckCircle2
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Investigation, InvestigationStatus, Priority } from '../types';
import { useTheme } from '../hooks/useTheme';

interface InvestigationsProps {
  investigations: Investigation[];
  activeInvestigation: Investigation | null;
  onSelectInvestigation: (inv: Investigation | null) => void;
  onRefreshInvestigations: () => void;
  onRefreshStats: () => void;
}

const getStatusConfig = (isDark: boolean): Record<InvestigationStatus, { icon: any; color: string }> => ({
  active: { icon: Play, color: isDark ? 'bg-success-500/10 text-success-400 border-success-500/30' : 'bg-success-50 text-success-600 border-success-200' },
  paused: { icon: Pause, color: isDark ? 'bg-warning-500/10 text-warning-400 border-warning-500/30' : 'bg-warning-50 text-warning-600 border-warning-200' },
  completed: { icon: CheckCircle2, color: isDark ? 'bg-white/[0.03] text-surface-400 border-white/[0.06]' : 'bg-surface-50 text-surface-500 border-surface-200' },
  archived: { icon: Archive, color: isDark ? 'bg-white/[0.03] text-surface-500 border-white/[0.06]' : 'bg-surface-50 text-surface-400 border-surface-200' },
});

const getPriorityConfig = (isDark: boolean): Record<Priority, string> => ({
  low: isDark ? 'bg-white/[0.03] border-white/[0.06] text-surface-400' : 'bg-surface-50 border-surface-200 text-surface-600',
  medium: isDark ? 'bg-warning-500/10 border-warning-500/30 text-warning-400' : 'bg-warning-50 border-warning-200 text-warning-700',
  high: isDark ? 'bg-orange-500/10 border-orange-500/30 text-orange-400' : 'bg-orange-50 border-orange-200 text-orange-700',
  critical: isDark ? 'bg-danger-500/10 border-danger-500/30 text-danger-400' : 'bg-danger-50 border-danger-200 text-danger-700',
});

export default function Investigations({ investigations, activeInvestigation, onSelectInvestigation, onRefreshInvestigations, onRefreshStats }: InvestigationsProps) {
  const [showNew, setShowNew] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [tags, setTags] = useState('');
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNotes, setEditNotes] = useState('');
  const { isDark } = useTheme();

  const handleCreate = async () => {
    if (!title.trim()) return;
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    const { data } = await supabase.from('investigations').insert({ title, description, priority, tags: tags.split(',').map(t => t.trim()).filter(Boolean), user_id: user.id }).select().single();
    if (data) { onSelectInvestigation(data); setShowNew(false); setTitle(''); setDescription(''); setPriority('medium'); setTags(''); onRefreshInvestigations(); onRefreshStats(); }
    setLoading(false);
  };

  const changeStatus = async (id: string, status: InvestigationStatus) => {
    await supabase.from('investigations').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    onRefreshInvestigations(); onRefreshStats();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('investigations').delete().eq('id', id);
    if (activeInvestigation?.id === id) onSelectInvestigation(null);
    onRefreshInvestigations(); onRefreshStats();
  };

  const saveNotes = async (id: string) => {
    await supabase.from('investigations').update({ notes: editNotes, updated_at: new Date().toISOString() }).eq('id', id);
    setEditingId(null); onRefreshInvestigations();
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'} flex items-center gap-3`}><FolderOpen className="w-6 h-6 text-brand-500" /> Investigations</h1>
          <p className={`text-sm ${isDark ? 'text-surface-400' : 'text-surface-500'} mt-0.5`}>Manage and track your OSINT investigation cases</p>
        </div>
        <button onClick={() => setShowNew(true)} className="btn-primary text-sm"><Plus className="w-4 h-4 mr-2" />New Investigation</button>
      </div>

      {showNew && (
        <div className="card p-6 space-y-4 animate-slide-up">
          <h3 className={`text-sm font-semibold ${isDark ? 'text-surface-200' : 'text-surface-800'}`}>Create New Investigation</h3>
          <input type="text" value={title} onChange={e => setTitle(e.target.value)} className="input-base text-sm" placeholder="Investigation title..." />
          <textarea value={description} onChange={e => setDescription(e.target.value)} className="input-base text-sm resize-none" rows={2} placeholder="Description (optional)..." />
          <div className="grid grid-cols-2 gap-4">
            <select value={priority} onChange={e => setPriority(e.target.value as Priority)} className="input-base text-sm">
              <option value="low">Low Priority</option><option value="medium">Medium Priority</option><option value="high">High Priority</option><option value="critical">Critical Priority</option>
            </select>
            <input type="text" value={tags} onChange={e => setTags(e.target.value)} className="input-base text-sm" placeholder="Tags (comma-separated)" />
          </div>
          <div className="flex gap-2">
            <button onClick={handleCreate} disabled={loading || !title.trim()} className="btn-primary text-sm disabled:opacity-50">{loading ? 'Creating...' : 'Create Investigation'}</button>
            <button onClick={() => setShowNew(false)} className="btn-secondary text-sm">Cancel</button>
          </div>
        </div>
      )}

      {investigations.length === 0 ? (
        <div className="card p-12 text-center"><FolderOpen className={`w-12 h-12 mx-auto ${isDark ? 'text-surface-600' : 'text-surface-300'} mb-3`} /><p className={`${isDark ? 'text-surface-400' : 'text-surface-600'} font-medium`}>No investigations yet</p><p className={`text-sm ${isDark ? 'text-surface-500' : 'text-surface-400'} mt-1`}>Create your first investigation to organize your analysis work</p></div>
      ) : (
        <div className="space-y-3">
          {investigations.map(inv => {
            const statusConfig = getStatusConfig(isDark);
            const priorityConfig = getPriorityConfig(isDark);
            const sc = statusConfig[inv.status];
            const StatusIcon = sc.icon;
            const isActive = activeInvestigation?.id === inv.id;
            return (
              <div key={inv.id} className={`card-hover p-5 ${isActive ? (isDark ? 'border-brand-500/30 bg-brand-500/10' : 'border-brand-300 bg-brand-50/30') : ''}`}>
                <div className="flex items-start gap-4">
                  <button onClick={() => onSelectInvestigation(isActive ? null : inv)} className={`w-10 h-10 rounded-xl flex items-center justify-center border transition-colors ${isActive ? (isDark ? 'bg-brand-500/20 border-brand-500/40 text-brand-400' : 'bg-brand-100 border-brand-300 text-brand-600') : (isDark ? 'bg-white/[0.05] border-white/[0.06] text-surface-400 hover:text-surface-300 hover:border-white/[0.08]' : 'bg-surface-50 border-surface-200 text-surface-400 hover:text-surface-600 hover:border-surface-300')}`}>
                    <StatusIcon className="w-4 h-4" />
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className={`text-sm font-semibold ${isDark ? 'text-white' : 'text-surface-900'}`}>{inv.title}</h3>
                      <span className={`badge ${priorityConfig[inv.priority]}`}>{inv.priority}</span>
                      <span className={`badge ${sc.color}`}>{inv.status}</span>
                    </div>
                    {inv.description && <p className={`text-xs ${isDark ? 'text-surface-400' : 'text-surface-500'} line-clamp-2 mb-2`}>{inv.description}</p>}
                    <div className={`flex items-center gap-4 text-xs ${isDark ? 'text-surface-500' : 'text-surface-400'}`}>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(inv.created_at).toLocaleDateString()}</span>
                      {inv.tags.length > 0 && <span className="flex items-center gap-1"><Tag className="w-3 h-3" />{inv.tags.slice(0, 3).join(', ')}{inv.tags.length > 3 ? ` +${inv.tags.length - 3}` : ''}</span>}
                    </div>
                    {editingId === inv.id ? (
                      <div className="mt-3 space-y-2">
                        <textarea value={editNotes} onChange={e => setEditNotes(e.target.value)} className="input-base text-xs resize-none" rows={3} placeholder="Investigation notes..." />
                        <div className="flex gap-2"><button onClick={() => saveNotes(inv.id)} className="btn-primary text-xs">Save</button><button onClick={() => setEditingId(null)} className="btn-secondary text-xs">Cancel</button></div>
                      </div>
                    ) : inv.notes && <p className={`mt-2 text-xs ${isDark ? 'text-surface-400' : 'text-surface-500'} italic line-clamp-2`}>{inv.notes}</p>}
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => { setEditingId(inv.id); setEditNotes(inv.notes || ''); }} className="btn-ghost text-xs" title="Edit notes"><Edit3 className="w-3.5 h-3.5" /></button>
                    {inv.status === 'active' && <button onClick={() => changeStatus(inv.id, 'paused')} className="btn-ghost text-xs" title="Pause"><Pause className="w-3.5 h-3.5" /></button>}
                    {inv.status === 'paused' && <button onClick={() => changeStatus(inv.id, 'active')} className="btn-ghost text-xs" title="Resume"><Play className="w-3.5 h-3.5" /></button>}
                    {inv.status !== 'completed' && <button onClick={() => changeStatus(inv.id, 'completed')} className="btn-ghost text-xs" title="Complete"><CheckCircle2 className="w-3.5 h-3.5" /></button>}
                    <button onClick={() => handleDelete(inv.id)} className={`btn-ghost text-xs ${isDark ? 'hover:!text-danger-400 hover:!bg-danger-500/10' : 'hover:!text-danger-600 hover:!bg-danger-50'}`} title="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
