import { useState } from 'react';
import {
  Globe, Search, Shield, Lock, Server, MapPin,
  ExternalLink, Loader2, ChevronDown, ChevronUp, Eye, Skull, Link2
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Investigation, URLAnalysis, RiskLevel, Indicator } from '../types';
import RiskBadge, { ConfidenceBar } from '../components/RiskBadge';
import InvestigationSelector from '../components/InvestigationSelector';
import { useTheme } from '../hooks/useTheme';

interface URLAnalyzerProps {
  investigations: Investigation[];
  activeInvestigation: Investigation | null;
  onSelectInvestigation: (inv: Investigation | null) => void;
  onRefreshInvestigations: () => void;
  onRefreshStats: () => void;
}

export default function URLAnalyzer({ investigations, activeInvestigation, onSelectInvestigation, onRefreshInvestigations, onRefreshStats }: URLAnalyzerProps) {
  const { isDark } = useTheme();
  const [url, setUrl] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<URLAnalysis | null>(null);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ indicators: true, structure: true, whois: false, ssl: false, dns: false, hosting: false, reputation: false });
  const toggle = (k: string) => setExpanded(p => ({ ...p, [k]: !p[k] }));

  const analyze = async () => {
    if (!url.trim()) return;
    setAnalyzing(true); setError(''); setResult(null);
    try {
      const norm = url.startsWith('http') ? url : `https://${url}`;
      const u = new URL(norm);
      const domain = u.hostname;

      // ---- URL Structure ----
      const pathSegs = u.pathname.split('/').filter(Boolean);
      const urlStructure: Record<string, unknown> = {
        protocol: u.protocol,
        hostname: u.hostname,
        path: u.pathname,
        pathDepth: pathSegs.length,
        hasHTTPS: u.protocol === 'https:',
        hasPort: u.port !== '',
        hasQueryParams: u.search !== '',
        queryParams: u.searchParams.toString(),
        paramCount: [...u.searchParams.keys()].length,
        hasFragment: u.hash !== '',
        hasUserInfo: u.username !== '',
        subdomainCount: u.hostname.split('.').length - 2,
        isIPAddress: /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(u.hostname),
        tld: u.hostname.split('.').pop(),
        domainLength: u.hostname.length,
        pathLength: u.pathname.length,
        urlLength: norm.length,
      };

      // ---- Suspicious TLD ----
      const suspiciousTLDs = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top', '.club', '.work', '.bid', '.loan', '.click', '.link', '.info', '.pw', '.cc'];
      const hasSuspiciousTLD = suspiciousTLDs.some(t => domain.endsWith(t));

      // ---- Phishing Detection ----
      const phishingIndicators: Indicator[] = [];
      const scamIndicators: Indicator[] = [];

      // Brand impersonation
      const brands = [
        'paypal', 'amazon', 'apple', 'microsoft', 'google', 'facebook', 'netflix', 'instagram',
        'twitter', 'linkedin', 'whatsapp', 'tiktok', 'spotify', 'adobe', 'dropbox', 'slack',
        'zoom', 'stripe', 'coinbase', 'binance', 'chase', 'wells', 'bankofamerica', 'citibank',
        'hsbc', 'barclays', 'santander', 'westernunion', 'moneygram', 'ebay', 'etsy', 'shopify'
      ];
      const lowerHost = domain.toLowerCase();
      const lowerPath = u.pathname.toLowerCase();
      brands.forEach(b => {
        if (lowerHost.includes(b) && !lowerHost.includes(`${b}.com`) && !lowerHost.includes(`${b}.net`) && !lowerHost.includes(`${b}.org`)) {
          phishingIndicators.push({ type: 'brand_impersonation', description: `Possible "${b}" brand impersonation in domain name`, severity: 'critical', confidence: 72 });
        }
        if (lowerPath.includes(b) && !lowerHost.includes(`${b}.com`)) {
          phishingIndicators.push({ type: 'brand_in_path', description: `"${b}" keyword in URL path — possible lure page`, severity: 'medium', confidence: 45 });
        }
      });

      // Typosquatting detection
      const majorDomains = ['google.com', 'facebook.com', 'amazon.com', 'apple.com', 'microsoft.com', 'netflix.com', 'paypal.com'];
      majorDomains.forEach(m => {
        const base = m.split('.')[0];
        if (lowerHost.includes(base) && !lowerHost.endsWith(m)) {
          const editDist = levenshtein(lowerHost.split('.')[0], base);
          if (editDist <= 2 && editDist > 0) {
            phishingIndicators.push({ type: 'typosquatting', description: `Possible typosquatting of "${m}" — edit distance: ${editDist}`, severity: 'high', confidence: 78 });
          }
        }
      });

      // IP address as host
      if (urlStructure.isIPAddress) phishingIndicators.push({ type: 'ip_host', description: 'URL uses raw IP address instead of domain name', severity: 'high', confidence: 90 });
      if (hasSuspiciousTLD) phishingIndicators.push({ type: 'suspicious_tld', description: `Suspicious TLD detected: .${urlStructure.tld}`, severity: 'high', confidence: 82 });
      if (urlStructure.hasUserInfo) phishingIndicators.push({ type: 'user_info', description: 'URL contains user credentials — classic phishing technique', severity: 'critical', confidence: 95 });
      if ((urlStructure.domainLength as number) > 30) phishingIndicators.push({ type: 'long_domain', description: 'Unusually long domain name — may be typosquatting or obfuscation', severity: 'medium', confidence: 62 });
      if ((urlStructure.subdomainCount as number) > 3) phishingIndicators.push({ type: 'excessive_subdomains', description: 'Excessive subdomains may indicate cloaking or URL manipulation', severity: 'medium', confidence: 55 });
      if (/%[0-9A-Fa-f]{2}/.test(norm)) phishingIndicators.push({ type: 'encoded_chars', description: 'URL contains encoded characters — possible obfuscation', severity: 'medium', confidence: 52 });
      if (!urlStructure.hasHTTPS) scamIndicators.push({ type: 'no_https', description: 'No SSL/TLS encryption — data transmitted in plaintext', severity: 'high', confidence: 98 });

      // Urgency/scam keywords
      const urgencyKws = ['urgent', 'verify-now', 'suspended', 'locked', 'expire', 'action-required', 'click-here', 'free', 'winner', 'prize', 'claim', 'limited-time', 'act-now', 'secure-account', 'update-billing', 'confirm-identity'];
      urgencyKws.forEach(k => {
        if (norm.toLowerCase().includes(k)) scamIndicators.push({ type: 'urgency_keyword', description: `Urgency/scam keyword detected: "${k}"`, severity: 'medium', confidence: 58 });
      });

      // Homograph attack detection (mixed scripts)
      const hasDigitInDomain = /\d/.test(u.hostname.split('.')[0]);
      const hasAlphaInDomain = /[a-z]/i.test(u.hostname.split('.')[0]);
      if (hasDigitInDomain && hasAlphaInDomain && !urlStructure.isIPAddress) {
        phishingIndicators.push({ type: 'homograph_risk', description: 'Mixed alphanumeric characters in domain — possible homograph attack', severity: 'medium', confidence: 48 });
      }

      // ---- SSL Data ----
      const sslData: Record<string, unknown> = {
        domain,
        hasSSL: urlStructure.hasHTTPS,
        valid: urlStructure.hasHTTPS,
        protocol: u.protocol,
        issuer: urlStructure.hasHTTPS ? 'Detected (full details require server-side check)' : 'None',
        note: 'Complete SSL certificate chain analysis requires server-side verification',
      };

      // ---- WHOIS mock ----
      const whoisData: Record<string, unknown> = {
        domain,
        queryTime: new Date().toISOString(),
        note: 'Full WHOIS data requires external API integration (edge function)',
        domainAge: 'Requires WHOIS API',
        registrar: 'Requires WHOIS API',
      };

      // ---- DNS mock ----
      const dnsData: Record<string, unknown> = {
        domain,
        recordTypes: ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA'],
        note: 'DNS resolution requires server-side API call',
      };

      // ---- Hosting ----
      const hostingData: Record<string, unknown> = {
        domain,
        isIPAddress: urlStructure.isIPAddress,
        note: 'Hosting provider and geolocation require server-side IP lookup',
      };

      // ---- Reputation ----
      const reputationData: Record<string, unknown> = {
        domain,
        hasHTTPS: urlStructure.hasHTTPS,
        hasSuspiciousTLD,
        indicatorCount: phishingIndicators.length + scamIndicators.length,
        riskAssessment: 'Based on URL structure analysis',
      };

      // ---- Risk Score ----
      let riskScore = 0;
      if (!urlStructure.hasHTTPS) riskScore += 15;
      if (urlStructure.isIPAddress) riskScore += 20;
      if (hasSuspiciousTLD) riskScore += 15;
      if (urlStructure.hasUserInfo) riskScore += 25;
      if ((urlStructure.domainLength as number) > 30) riskScore += 10;
      if ((urlStructure.subdomainCount as number) > 3) riskScore += 8;
      phishingIndicators.forEach(i => { riskScore += i.severity === 'critical' ? 15 : i.severity === 'high' ? 10 : i.severity === 'medium' ? 5 : 2; });
      scamIndicators.forEach(i => { riskScore += i.severity === 'critical' ? 15 : i.severity === 'high' ? 10 : i.severity === 'medium' ? 5 : 2; });
      riskScore = Math.min(riskScore, 100);
      const riskLevel: RiskLevel = riskScore >= 75 ? 'critical' : riskScore >= 55 ? 'high' : riskScore >= 35 ? 'medium' : riskScore >= 15 ? 'low' : 'safe';

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const row = {
        investigation_id: activeInvestigation?.id ?? null, url: norm, domain,
        whois_data: whoisData, ssl_data: sslData, dns_data: dnsData, redirect_chain: [],
        domain_reputation: reputationData, ip_intelligence: {}, hosting_data: hostingData, url_structure: urlStructure,
        risk_score: riskScore, risk_level: riskLevel, scam_indicators: scamIndicators, phishing_indicators: phishingIndicators,
        analysis_summary: { indicatorCount: phishingIndicators.length + scamIndicators.length, isHTTPS: urlStructure.hasHTTPS, isIP: urlStructure.isIPAddress, hasSuspiciousTLD, phishingCount: phishingIndicators.length, scamCount: scamIndicators.length },
        user_id: user.id,
      };

      const { data, error: ie } = await supabase.from('url_analyses').insert(row).select().single();
      if (ie) throw ie;
      setResult(data); onRefreshStats();
      await supabase.from('audit_logs').insert({ user_id: user.id, action: 'analyze_url', resource_type: 'url_analysis', resource_id: data.id, details: { url: norm, risk_score: riskScore, risk_level: riskLevel } });
    } catch (err: any) { setError(err.message || 'Analysis failed'); }
    finally { setAnalyzing(false); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'} flex items-center gap-3`}><Globe className="w-6 h-6 text-brand-500" /> URL Analyzer</h1>
        <p className="text-sm text-surface-500 mt-0.5">Phishing detection, domain intelligence, SSL/DNS analysis, scam indicators, and URL risk scoring</p>
      </div>

      <InvestigationSelector investigations={investigations} activeInvestigation={activeInvestigation} onSelect={onSelectInvestigation} onRefresh={onRefreshInvestigations} />

      {/* URL Input */}
      <div className="card p-6">
        <label className="label"><Search className="w-3.5 h-3.5 inline mr-1" /> Enter URL to Investigate</label>
        <div className="flex gap-3">
          <input type="text" value={url} onChange={e => setUrl(e.target.value)} onKeyDown={e => e.key === 'Enter' && analyze()} className="input-base font-mono text-sm flex-1" placeholder="https://example.com or suspicious-domain.xyz" />
          <button onClick={analyze} disabled={analyzing || !url.trim()} className="btn-primary text-sm disabled:opacity-50 whitespace-nowrap">
            {analyzing ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Analyzing...</> : <><Globe className="w-4 h-4 mr-2" />Analyze</>}
          </button>
        </div>
        {error && <p className={`mt-2 text-sm ${isDark ? 'text-danger-400' : 'text-danger-600'} ${isDark ? 'bg-danger-500/10 border-danger-500/30' : 'bg-danger-50 border-danger-200'} border rounded-lg p-3`}>{error}</p>}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-4 animate-slide-up">
          <div className="card p-5 flex items-center gap-6">
            <RiskBadge level={result.risk_level} score={result.risk_score} size="lg" />
            <div className="flex-1 min-w-0">
              <h3 className={`text-base font-semibold ${isDark ? 'text-white' : 'text-surface-900'} font-mono truncate`}>{result.url}</h3>
              <p className="text-sm text-surface-500">Domain: {result.domain}</p>
            </div>
            <a href={result.url} target="_blank" rel="noopener noreferrer" className="btn-secondary text-xs"><ExternalLink className="w-3 h-3 mr-1" />Open</a>
          </div>

          {/* Threat Indicators */}
          {(result.phishing_indicators.length > 0 || result.scam_indicators.length > 0) && (
            <Collapsible title="Threat Indicators" icon={<Skull className="w-4 h-4 text-danger-500" />} open={expanded.indicators} onToggle={() => toggle('indicators')} count={result.phishing_indicators.length + result.scam_indicators.length} isDark={isDark}>
              {result.phishing_indicators.length > 0 && (
                <div className="mb-4">
                  <h4 className={`text-xs font-mono ${isDark ? 'text-danger-400' : 'text-danger-600'} uppercase mb-2 tracking-wider font-semibold`}>Phishing Indicators ({result.phishing_indicators.length})</h4>
                  <div className="space-y-2">{result.phishing_indicators.map((ind, i) => <IndicatorCard key={i} indicator={ind} isDark={isDark} />)}</div>
                </div>
              )}
              {result.scam_indicators.length > 0 && (
                <div>
                  <h4 className={`text-xs font-mono ${isDark ? 'text-orange-400' : 'text-orange-600'} uppercase mb-2 tracking-wider font-semibold`}>Scam Indicators ({result.scam_indicators.length})</h4>
                  <div className="space-y-2">{result.scam_indicators.map((ind, i) => <IndicatorCard key={i} indicator={ind} isDark={isDark} />)}</div>
                </div>
              )}
            </Collapsible>
          )}

          <Collapsible title="URL Structure" icon={<Link2 className="w-4 h-4 text-brand-500" />} open={expanded.structure} onToggle={() => toggle('structure')} count={Object.keys(result.url_structure).length} isDark={isDark}>
            <DataTable data={result.url_structure} isDark={isDark} />
          </Collapsible>

          <Collapsible title="SSL Certificate" icon={<Lock className="w-4 h-4 text-success-600" />} open={expanded.ssl} onToggle={() => toggle('ssl')} isDark={isDark}>
            <DataTable data={result.ssl_data} isDark={isDark} />
          </Collapsible>

          <Collapsible title="WHOIS Data" icon={<Shield className="w-4 h-4 text-brand-500" />} open={expanded.whois} onToggle={() => toggle('whois')} isDark={isDark}>
            <DataTable data={result.whois_data} isDark={isDark} />
          </Collapsible>

          <Collapsible title="DNS Records" icon={<Server className="w-4 h-4 text-surface-500" />} open={expanded.dns} onToggle={() => toggle('dns')} isDark={isDark}>
            <DataTable data={result.dns_data} isDark={isDark} />
          </Collapsible>

          <Collapsible title="Hosting Information" icon={<MapPin className="w-4 h-4 text-warning-600" />} open={expanded.hosting} onToggle={() => toggle('hosting')} isDark={isDark}>
            <DataTable data={result.hosting_data} isDark={isDark} />
          </Collapsible>

          <Collapsible title="Domain Reputation" icon={<Eye className="w-4 h-4 text-brand-500" />} open={expanded.reputation} onToggle={() => toggle('reputation')} isDark={isDark}>
            <DataTable data={result.domain_reputation} isDark={isDark} />
          </Collapsible>
        </div>
      )}
    </div>
  );
}

function Collapsible({ title, icon, open, onToggle, count, children, isDark }: { title: string; icon: React.ReactNode; open: boolean; onToggle: () => void; count?: number; children: React.ReactNode; isDark: boolean }) {
  return (
    <div className="card overflow-hidden">
      <button onClick={onToggle} className={`w-full flex items-center justify-between px-5 py-4 ${isDark ? 'hover:bg-white/[0.05]' : 'hover:bg-surface-50'} transition-colors`}>
        <span className={`flex items-center gap-2 text-sm font-semibold ${isDark ? 'text-surface-200' : 'text-surface-800'}`}>{icon}{title}{count !== undefined && <span className={`text-xs ${isDark ? 'text-surface-400' : 'text-surface-400'} font-normal ml-1`}>({count})</span>}</span>
        {open ? <ChevronUp className={`w-4 h-4 ${isDark ? 'text-surface-400' : 'text-surface-400'}`} /> : <ChevronDown className={`w-4 h-4 ${isDark ? 'text-surface-400' : 'text-surface-400'}`} />}
      </button>
      {open && <div className="px-5 pb-5">{children}</div>}
    </div>
  );
}

function IndicatorCard({ indicator, isDark }: { indicator: Indicator; isDark: boolean }) {
  const bg = indicator.severity === 'critical' ? (isDark ? 'bg-danger-500/10 border-danger-500/30' : 'bg-danger-50 border-danger-200') : indicator.severity === 'high' ? (isDark ? 'bg-orange-500/10 border-orange-500/30' : 'bg-orange-50 border-orange-200') : indicator.severity === 'medium' ? (isDark ? 'bg-warning-500/10 border-warning-500/30' : 'bg-warning-50 border-warning-200') : (isDark ? 'bg-white/[0.03] border-white/[0.06]' : 'bg-surface-50 border-surface-200');
  return (
    <div className={`p-3 rounded-lg border ${bg}`}>
      <div className="flex items-center justify-between mb-2">
        <RiskBadge level={indicator.severity} />
        <span className="text-xs text-surface-500 font-mono">Confidence: {indicator.confidence}%</span>
      </div>
      <p className={`text-xs ${isDark ? 'text-surface-300' : 'text-surface-700'} font-medium mb-2`}>{indicator.description}</p>
      <ConfidenceBar value={indicator.confidence} />
    </div>
  );
}

function DataTable({ data, isDark }: { data: Record<string, unknown>; isDark: boolean }) {
  const entries = Object.entries(data);
  if (!entries.length) return <p className="text-sm text-surface-500">No data available</p>;
  const riskKeys = ['suspicious', 'potential', 'risk', 'isIPAddress', 'longDomain', 'manySubdomains', 'hasEncodedChars', 'hasSuspiciousTLD'];
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <tbody>
          {entries.map(([k, v]) => {
            const isBool = typeof v === 'boolean';
            const isRisk = isBool && v === true && riskKeys.some(rk => k.includes(rk));
            return (
              <tr key={k} className={`border-b ${isDark ? 'border-white/[0.04]' : 'border-surface-100'} last:border-0`}>
                <td className="py-2 pr-4 text-surface-500 font-mono text-xs whitespace-nowrap">{k}</td>
                <td className={`py-2 font-mono text-xs ${isRisk ? (isDark ? 'text-danger-400 font-semibold' : 'text-danger-600 font-semibold') : isBool && v ? 'text-success-600' : isBool && !v ? 'text-surface-400' : (isDark ? 'text-surface-200' : 'text-surface-800')}`}>
                  {isBool ? (v ? 'Yes' : 'No') : String(v)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++) dp[i][j] = Math.min(dp[i-1][j] + 1, dp[i][j-1] + 1, dp[i-1][j-1] + (a[i-1] !== b[j-1] ? 1 : 0));
  return dp[m][n];
}
