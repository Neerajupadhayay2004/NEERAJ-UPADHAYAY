import { useState } from 'react';
import {
  Users, TrendingUp, MessageSquare,
  AlertTriangle, Loader2, ChevronDown, ChevronUp, Brain, Hash, Tag
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Investigation, ContentAnalysis, RiskLevel, SourceType, KeywordEntry, EntityEntry, SentimentData, Indicator, TrendEntry } from '../types';
import RiskBadge, { ConfidenceBar } from '../components/RiskBadge';
import InvestigationSelector from '../components/InvestigationSelector';
import { useTheme } from '../hooks/useTheme';

interface ContentAnalyzerProps {
  investigations: Investigation[];
  activeInvestigation: Investigation | null;
  onSelectInvestigation: (inv: Investigation | null) => void;
  onRefreshInvestigations: () => void;
  onRefreshStats: () => void;
}

// ---- NLP Analysis Engine ----

const STOP_WORDS = new Set(['the','a','an','and','or','but','in','on','at','to','for','of','with','by','from','is','was','are','were','be','been','being','have','has','had','do','does','did','will','would','could','should','may','might','shall','can','this','that','these','those','i','you','he','she','it','we','they','me','him','her','us','them','my','your','his','its','our','their','what','which','who','whom','when','where','why','how','all','each','every','both','few','more','most','other','some','such','no','not','only','own','same','so','than','too','very','just','because','as','until','while','about','between','through','during','before','after','above','below','if','then','also','up','out','off','over','under','again','further','once','here','there','am','been','get','got','let','make','much','new','now','old','see','way','well','back','even','give','go','look','take','come','say','she','know','think','good','want','use','find','tell','ask','work','seem','feel','try','leave','call','keep','begin','show','hear','play','run','move','live','believe','bring','happen','write','provide','sit','stand','lose','pay','meet','include','continue','set','learn','change','lead','understand','watch','follow','stop','create','speak','read','allow','add','spend','grow','open','walk','win','offer','remember','love','consider','appear','buy','wait','serve','die','send','expect','build','stay','fall','cut','reach','kill','remain','suggest','raise','pass','sell','require','report','decide','pull','develop']);

const THREAT_CATEGORIES: Record<string, string[]> = {
  cyber_threat: ['hack', 'hacker', 'hacking', 'attack', 'breach', 'malware', 'ransomware', 'exploit', 'vulnerability', 'backdoor', 'phishing', 'ddos', 'botnet', 'trojan', 'worm', 'virus', 'spyware', 'adware', 'keylogger', 'rootkit', 'zero-day', 'cve', 'c2', 'command-and-control', 'exfiltration', 'lateral', 'pivot', 'shell', 'reverse', 'payload', 'injection', 'overflow', 'brute', 'cracking'],
  identity_theft: ['password', 'credential', 'login', 'account', 'ssn', 'social security', 'identity', 'passport', 'driver license', 'dob', 'date of birth', 'pin', '2fa', 'mfa', 'otp', 'authentication', 'authorization', 'privilege', 'escalation'],
  financial_fraud: ['bitcoin', 'crypto', 'cryptocurrency', 'payment', 'transfer', 'bank', 'credit card', 'debit', 'fraud', 'scam', 'money', 'fund', 'launder', 'wire', 'western union', 'moneygram', 'cashapp', 'venmo', 'paypal', 'stripe', 'wallet', 'token', 'ico', 'nft', 'investment', 'ponzi', 'pyramid'],
  location_tracking: ['address', 'location', 'coordinate', 'gps', 'track', 'surveillance', 'monitor', 'geofence', 'cell tower', 'wifi positioning', 'ip geolocation', 'check-in', 'geo-tag'],
  personal_pii: ['email', 'phone', 'dob', 'birth', 'name', 'workplace', 'company', 'school', 'university', 'occupation', 'salary', 'income', 'medical', 'health', 'insurance', 'diagnosis'],
  extremism: ['bomb', 'weapon', 'explosive', 'terrorist', 'extremist', 'radical', 'militant', 'assassination', 'attack plan', 'armed', 'shoot', 'kill', 'murder', 'violent'],
  drug_illicit: ['drug', 'narcotic', 'cocaine', 'heroin', 'meth', 'fentanyl', 'opioid', 'dealer', 'cartel', 'smuggle', 'trafficking', 'darknet', 'silk road'],
  anonymity: ['tor', 'vpn', 'proxy', 'anonymous', 'dark web', 'darknet', 'i2p', 'freenet', 'whonix', 'tails', 'pgp', 'gpg', 'encryption', 'encrypted', 'privacy coin', 'monero', 'zcash', 'mixer', 'tumbler'],
};

const POSITIVE_WORDS = new Set(['good','great','excellent','amazing','wonderful','fantastic','love','happy','best','awesome','beautiful','perfect','brilliant','superb','outstanding','helpful','friendly','safe','secure','trust','reliable','quality','professional','legitimate','verified','authentic','genuine']);
const NEGATIVE_WORDS = new Set(['bad','terrible','horrible','awful','worst','hate','angry','danger','threat','attack','kill','destroy','hack','breach','fraud','scam','exploit','vulnerability','malicious','suspicious','fake','counterfeit','illegal','steal','rob','cheat','deceive','manipulate','corrupt','toxic','harmful','violent','abuse','harass']);

function extractKeywords(text: string): KeywordEntry[] {
  const words = text.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/).filter(w => w.length > 2 && !STOP_WORDS.has(w));
  const freq = new Map<string, number>();
  words.forEach(w => freq.set(w, (freq.get(w) || 0) + 1));

  return Array.from(freq.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 25)
    .map(([keyword, frequency]) => {
      let category = 'general';
      let relevance = Math.min(frequency * 8, 40);
      for (const [cat, kws] of Object.entries(THREAT_CATEGORIES)) {
        if (kws.some(kw => keyword.includes(kw) || kw.includes(keyword))) {
          category = cat;
          relevance = Math.min(relevance + 40, 100);
          break;
        }
      }
      return { keyword, frequency, relevance, category };
    });
}

function extractEntities(text: string): EntityEntry[] {
  const entities: EntityEntry[] = [];

  // Email
  (text.match(/[\w.-]+@[\w.-]+\.\w+/g) || []).forEach(e => {
    if (!entities.find(en => en.entity === e)) entities.push({ entity: e, type: 'email', frequency: 1, relevance: 75 });
  });

  // URLs
  (text.match(/https?:\/\/[\w.-]+[^\s]*/g) || []).forEach(u => {
    if (!entities.find(en => en.entity === u)) entities.push({ entity: u, type: 'url', frequency: 1, relevance: 65 });
  });

  // Phone
  (text.match(/\+?\d{1,3}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}/g) || []).forEach(p => {
    if (p.length >= 7 && !entities.find(en => en.entity === p)) entities.push({ entity: p, type: 'phone', frequency: 1, relevance: 70 });
  });

  // Hashtags
  (text.match(/#\w+/g) || []).forEach(h => {
    const existing = entities.find(en => en.entity === h);
    if (existing) existing.frequency++;
    else entities.push({ entity: h, type: 'hashtag', frequency: 1, relevance: 35 });
  });

  // @mentions
  (text.match(/@\w+/g) || []).forEach(m => {
    const existing = entities.find(en => en.entity === m);
    if (existing) existing.frequency++;
    else entities.push({ entity: m, type: 'mention', frequency: 1, relevance: 55 });
  });

  // Named entities (2+ capitalized words)
  (text.match(/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b/g) || []).forEach(c => {
    if (c.length > 3 && !entities.find(en => en.entity === c)) entities.push({ entity: c, type: 'name', frequency: 1, relevance: 50 });
  });

  // IP addresses
  (text.match(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g) || []).forEach(ip => {
    if (!entities.find(en => en.entity === ip)) entities.push({ entity: ip, type: 'ip_address', frequency: 1, relevance: 80 });
  });

  // Crypto addresses (basic BTC pattern)
  (text.match(/\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b/g) || []).forEach(c => {
    if (!entities.find(en => en.entity === c)) entities.push({ entity: c, type: 'crypto_address', frequency: 1, relevance: 85 });
  });

  return entities.sort((a, b) => b.relevance - a.relevance).slice(0, 20);
}

function analyzeSentiment(text: string): SentimentData {
  const words = text.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/);
  let pos = 0, neg = 0;
  words.forEach(w => { if (POSITIVE_WORDS.has(w)) pos++; if (NEGATIVE_WORDS.has(w)) neg++; });
  const total = Math.max(pos + neg, 1);
  const overall = Math.round(((pos - neg) / total) * 100);
  return {
    overall,
    positive: Math.round((pos / words.length) * 1000) / 10,
    negative: Math.round((neg / words.length) * 1000) / 10,
    neutral: Math.round(Math.max(0, 100 - (pos / words.length * 1000) / 10 - (neg / words.length * 1000) / 10) * 10) / 10,
  };
}

function detectThreats(text: string, keywords: KeywordEntry[]): Indicator[] {
  const indicators: Indicator[] = [];

  // Pattern-based threat detection
  const patterns: Array<{ regex: RegExp; type: string; desc: string; severity: RiskLevel; confidence: number }> = [
    { regex: /\bhack(?:ing|er)?\b/i, type: 'cyber_threat', desc: 'Hacking reference detected', severity: 'high', confidence: 62 },
    { regex: /\battack(?:er|ing)?\b/i, type: 'cyber_threat', desc: 'Attack reference detected', severity: 'high', confidence: 57 },
    { regex: /\bexploit(?:ing|ation)?\b/i, type: 'cyber_threat', desc: 'Exploit reference detected', severity: 'critical', confidence: 72 },
    { regex: /\bbreach(?:ed|ing)?\b/i, type: 'cyber_threat', desc: 'Data breach reference detected', severity: 'high', confidence: 67 },
    { regex: /\bmalware\b|\bransomware\b/i, type: 'cyber_threat', desc: 'Malware reference detected', severity: 'critical', confidence: 78 },
    { regex: /\bphish(?:ing)?\b/i, type: 'cyber_threat', desc: 'Phishing reference detected', severity: 'high', confidence: 75 },
    { regex: /\bpassword\b|\bcredential/i, type: 'identity_theft', desc: 'Credential reference detected', severity: 'medium', confidence: 52 },
    { regex: /\bbomb\b|\bweapon\b|\bexplosive/i, type: 'extremism', desc: 'Violence/weapon reference detected', severity: 'critical', confidence: 82 },
    { regex: /\bdrug\b|\bnarcotic\b|\bfentanyl/i, type: 'drug_illicit', desc: 'Drug reference detected', severity: 'high', confidence: 72 },
    { regex: /\btor\b|\bdark\s*web\b|\banonym/i, type: 'anonymity', desc: 'Anonymity/dark web reference detected', severity: 'medium', confidence: 47 },
    { regex: /\bbitcoin\b|\bcrypto\b|\blaundry\b|\bmixer\b/i, type: 'financial_fraud', desc: 'Cryptocurrency reference detected', severity: 'low', confidence: 35 },
    { regex: /\bssn\b|\bsocial security\b/i, type: 'identity_theft', desc: 'SSN reference detected — potential PII exposure', severity: 'critical', confidence: 88 },
    { regex: /\bkill\b|\bmurder\b|\bassassinat/i, type: 'extremism', desc: 'Violence reference detected', severity: 'critical', confidence: 85 },
    { regex: /\bDDoS\b|\bbenial of service/i, type: 'cyber_threat', desc: 'DDoS attack reference detected', severity: 'high', confidence: 73 },
    { regex: /\bbackdoor\b|\bc2\b|\bcommand.and.control/i, type: 'cyber_threat', desc: 'C2/backdoor reference detected', severity: 'critical', confidence: 80 },
  ];

  patterns.forEach(({ regex, type, desc, severity, confidence }) => {
    if (regex.test(text)) indicators.push({ type, description: desc, severity, confidence });
  });

  // PII exposure
  if (/[\w.-]+@[\w.-]+\.\w+/.test(text)) indicators.push({ type: 'pii', description: 'Email address detected in content — potential PII exposure', severity: 'medium', confidence: 87 });
  if (/\+?\d{1,3}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}/.test(text) && ((text.match(/\d/g)?.length ?? 0) > 6)) indicators.push({ type: 'pii', description: 'Phone number pattern detected — potential PII exposure', severity: 'medium', confidence: 62 });
  if (/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(text)) indicators.push({ type: 'pii', description: 'IP address detected in content', severity: 'low', confidence: 80 });

  // Threat keyword density
  const threatKwCount = keywords.filter(k => k.category !== 'general').length;
  if (threatKwCount >= 7) indicators.push({ type: 'keyword_density', description: `${threatKwCount} threat-related keywords detected — high threat density`, severity: 'high', confidence: 73 });
  else if (threatKwCount >= 4) indicators.push({ type: 'keyword_density', description: `${threatKwCount} threat-related keywords detected — moderate threat density`, severity: 'medium', confidence: 58 });

  return indicators;
}

function calculateContentRisk(indicators: Indicator[], sentiment: SentimentData): { score: number; level: RiskLevel } {
  let score = 0;
  indicators.forEach(i => { score += i.severity === 'critical' ? 20 : i.severity === 'high' ? 14 : i.severity === 'medium' ? 7 : 3; });
  if (sentiment.negative > 5) score += 8;
  if (sentiment.negative > 15) score += 12;
  score = Math.min(score, 100);
  const level: RiskLevel = score >= 75 ? 'critical' : score >= 55 ? 'high' : score >= 35 ? 'medium' : score >= 15 ? 'low' : 'safe';
  return { score, level };
}

export default function ContentAnalyzer({ investigations, activeInvestigation, onSelectInvestigation, onRefreshInvestigations, onRefreshStats }: ContentAnalyzerProps) {
  const { isDark } = useTheme();
  const [content, setContent] = useState('');
  const [sourceType, setSourceType] = useState<SourceType>('social_post');
  const [sourceUrl, setSourceUrl] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ContentAnalysis | null>(null);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ indicators: true, sentiment: true, keywords: true, entities: true, trends: false });
  const toggle = (k: string) => setExpanded(p => ({ ...p, [k]: !p[k] }));

  const analyze = async () => {
    if (!content.trim()) return;
    setAnalyzing(true); setError('');
    try {
      const keywords = extractKeywords(content);
      const entities = extractEntities(content);
      const sentiment = analyzeSentiment(content);
      const riskIndicators = detectThreats(content, keywords);
      const threatIndicators = riskIndicators.filter(i => i.type !== 'pii' && i.type !== 'keyword_density');
      const { score, level } = calculateContentRisk(riskIndicators, sentiment);

      const trends: TrendEntry[] = keywords.slice(0, 8).map(kw => ({
        topic: kw.keyword, frequency: kw.frequency, trend_direction: 'stable' as const, relevance: kw.relevance,
      }));

      const reputationData = {
        sourceType, hasUrl: !!sourceUrl, contentLength: content.length,
        entityCount: entities.length, threatKeywordCount: keywords.filter(k => k.category !== 'general').length,
        uniqueCategories: [...new Set(keywords.filter(k => k.category !== 'general').map(k => k.category))],
      };

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const row = {
        investigation_id: activeInvestigation?.id ?? null, source_type: sourceType, source_url: sourceUrl || null,
        content, keywords, entities, sentiment, trends, risk_indicators: riskIndicators,
        reputation_data: reputationData, threat_indicators: threatIndicators,
        risk_score: score, risk_level: level,
        analysis_summary: { keywordCount: keywords.length, entityCount: entities.length, riskIndicatorCount: riskIndicators.length, sentimentOverall: sentiment.overall, threatCategoryCount: [...new Set(riskIndicators.map(i => i.type))].length },
        user_id: user.id,
      };

      const { data, error: ie } = await supabase.from('content_analyses').insert(row).select().single();
      if (ie) throw ie;
      setResult(data); onRefreshStats();
      await supabase.from('audit_logs').insert({ user_id: user.id, action: 'analyze_content', resource_type: 'content_analysis', resource_id: data.id, details: { source_type: sourceType, risk_score: score, risk_level: level } });
    } catch (err: any) { setError(err.message || 'Analysis failed'); }
    finally { setAnalyzing(false); }
  };

  const sourceTypes: { value: SourceType; label: string }[] = [
    { value: 'social_post', label: 'Social Media Post' }, { value: 'comment', label: 'Comment' },
    { value: 'profile', label: 'Profile Description' }, { value: 'website', label: 'Website Content' },
    { value: 'description', label: 'Description/Caption' }, { value: 'other', label: 'Other' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'} flex items-center gap-3`}><Brain className="w-6 h-6 text-brand-500" /> Content Analyzer</h1>
        <p className="text-sm text-surface-500 mt-0.5">AI-powered keyword extraction, entity recognition, sentiment analysis, threat detection, and PII identification</p>
      </div>

      <InvestigationSelector investigations={investigations} activeInvestigation={activeInvestigation} onSelect={onSelectInvestigation} onRefresh={onRefreshInvestigations} />

      <div className="card p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><label className="label">Source Type</label><select value={sourceType} onChange={e => setSourceType(e.target.value as SourceType)} className="input-base text-sm">{sourceTypes.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}</select></div>
          <div><label className="label">Source URL (optional)</label><input type="text" value={sourceUrl} onChange={e => setSourceUrl(e.target.value)} className="input-base text-sm font-mono" placeholder="https://..." /></div>
        </div>
        <div>
          <label className="label"><MessageSquare className="w-3.5 h-3.5 inline mr-1" /> Content to Analyze</label>
          <textarea value={content} onChange={e => setContent(e.target.value)} className="input-base resize-none" rows={7} placeholder="Paste public social media post, comment, profile description, or website content here for AI-powered analysis..." />
          <div className="flex justify-between mt-2">
            <span className="text-xs text-surface-400">{content.length} characters</span>
            <button onClick={analyze} disabled={analyzing || !content.trim()} className="btn-primary text-sm disabled:opacity-50">
              {analyzing ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Analyzing...</> : <><Brain className="w-4 h-4 mr-2" />Analyze Content</>}
            </button>
          </div>
        </div>
        {error && <p className={`text-sm ${isDark ? 'text-danger-400 bg-danger-500/10 border-danger-500/30' : 'text-danger-600 bg-danger-50 border-danger-200'} border rounded-lg p-3`}>{error}</p>}
      </div>

      {result && (
        <div className="space-y-4 animate-slide-up">
          <div className="card p-5 flex items-center gap-6">
            <RiskBadge level={result.risk_level} score={result.risk_score} size="lg" />
            <div className="flex-1">
              <h3 className={`text-base font-semibold ${isDark ? 'text-white' : 'text-surface-900'}`}>Content Analysis Results</h3>
              <p className="text-sm text-surface-500">{sourceTypes.find(s => s.value === result.source_type)?.label} | {content.length} chars | {result.entities.length} entities | {result.keywords.length} keywords</p>
            </div>
          </div>

          {result.risk_indicators.length > 0 && (
            <Collapsible title="Risk Indicators" icon={<AlertTriangle className="w-4 h-4 text-danger-500" />} open={expanded.indicators} onToggle={() => toggle('indicators')} count={result.risk_indicators.length} isDark={isDark}>
              <div className="space-y-2">{result.risk_indicators.map((ind, i) => (
                <div key={i} className={`p-3 rounded-lg border ${ind.severity === 'critical' ? (isDark ? 'bg-danger-500/10 border-danger-500/30' : 'bg-danger-50 border-danger-200') : ind.severity === 'high' ? (isDark ? 'bg-orange-500/10 border-orange-500/30' : 'bg-orange-50 border-orange-200') : ind.severity === 'medium' ? (isDark ? 'bg-warning-500/10 border-warning-500/30' : 'bg-warning-50 border-warning-200') : (isDark ? 'bg-white/[0.03] border-white/[0.06]' : 'bg-surface-50 border-surface-200')}`}>
                  <div className="flex items-center justify-between mb-1"><RiskBadge level={ind.severity} /><span className="text-xs text-surface-500 font-mono">{ind.confidence}% confidence</span></div>
                  <p className={`text-xs ${isDark ? 'text-surface-300' : 'text-surface-700'} font-medium mb-2`}>{ind.description}</p>
                  <ConfidenceBar value={ind.confidence} />
                </div>
              ))}</div>
            </Collapsible>
          )}

          <Collapsible title="Sentiment Analysis" icon={<MessageSquare className="w-4 h-4 text-brand-500" />} open={expanded.sentiment} onToggle={() => toggle('sentiment')} isDark={isDark}>
            <div className="space-y-3">
              <div className="flex items-center gap-4 mb-2">
                <span className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-surface-900'}`}>{result.sentiment.overall > 0 ? '+' : ''}{result.sentiment.overall}</span>
                <span className="text-sm text-surface-500">Overall Sentiment Score</span>
              </div>
              <SentimentBar label="Positive" value={result.sentiment.positive} max={Math.max(result.sentiment.positive, result.sentiment.negative, result.sentiment.neutral, 1)} color="bg-success-500" isDark={isDark} />
              <SentimentBar label="Negative" value={result.sentiment.negative} max={Math.max(result.sentiment.positive, result.sentiment.negative, result.sentiment.neutral, 1)} color="bg-danger-500" isDark={isDark} />
              <SentimentBar label="Neutral" value={result.sentiment.neutral} max={Math.max(result.sentiment.positive, result.sentiment.negative, result.sentiment.neutral, 1)} color="bg-surface-400" isDark={isDark} />
            </div>
          </Collapsible>

          <Collapsible title="Keyword Analysis" icon={<Hash className="w-4 h-4 text-brand-500" />} open={expanded.keywords} onToggle={() => toggle('keywords')} count={result.keywords.length} isDark={isDark}>
            <div className="flex flex-wrap gap-2">
              {result.keywords.map((kw, i) => (
                <span key={i} className={`badge ${kw.category !== 'general' ? (isDark ? 'bg-danger-500/10 border-danger-500/30 text-danger-400' : 'bg-danger-50 border-danger-200 text-danger-700') : (isDark ? 'bg-white/[0.03] border-white/[0.06] text-surface-400' : 'bg-surface-50 border-surface-200 text-surface-600')}`}>
                  {kw.keyword}<span className="ml-1 opacity-60">({kw.frequency})</span>
                  {kw.category !== 'general' && <Tag className="w-2.5 h-2.5 ml-1" />}
                </span>
              ))}
            </div>
          </Collapsible>

          {result.entities.length > 0 && (
            <Collapsible title="Entity Extraction" icon={<Users className="w-4 h-4 text-brand-500" />} open={expanded.entities} onToggle={() => toggle('entities')} count={result.entities.length} isDark={isDark}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className={`text-xs text-surface-500 border-b ${isDark ? 'border-white/[0.06]' : 'border-surface-200'}`}><th className="py-2 text-left font-semibold">Entity</th><th className="py-2 text-left font-semibold">Type</th><th className="py-2 text-right font-semibold">Freq</th><th className="py-2 text-right font-semibold">Relevance</th></tr></thead>
                  <tbody>{result.entities.map((ent, i) => (
                    <tr key={i} className={`border-b last:border-0 ${isDark ? 'border-white/[0.04]' : 'border-surface-100'}`}>
                      <td className={`py-2 font-mono text-xs ${isDark ? 'text-surface-200' : 'text-surface-800'} max-w-[200px] truncate`}>{ent.entity}</td>
                      <td className="py-2"><span className={`badge ${isDark ? 'bg-brand-500/10 border-brand-500/20 text-brand-300' : 'bg-brand-50 border-brand-200 text-brand-700'}`}>{ent.type.replace(/_/g, ' ')}</span></td>
                      <td className={`py-2 text-right font-mono text-xs ${isDark ? 'text-surface-400' : 'text-surface-600'}`}>{ent.frequency}</td>
                      <td className="py-2 text-right"><div className="flex items-center justify-end gap-1"><div className={`w-16 h-1.5 rounded-full overflow-hidden ${isDark ? 'bg-white/[0.06]' : 'bg-surface-100'}`}><div className="h-full bg-brand-500 rounded-full" style={{ width: `${ent.relevance}%` }} /></div><span className="text-xs font-mono text-surface-500">{ent.relevance}%</span></div></td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            </Collapsible>
          )}

          {result.trends.length > 0 && (
            <Collapsible title="Trend Analysis" icon={<TrendingUp className="w-4 h-4 text-brand-500" />} open={expanded.trends} onToggle={() => toggle('trends')} isDark={isDark}>
              <div className="space-y-2">{result.trends.map((t, i) => (
                <div key={i} className={`flex items-center justify-between p-2.5 rounded-lg border ${isDark ? 'bg-white/[0.03] border-white/[0.06]' : 'bg-surface-50 border-surface-200'}`}>
                  <span className={`text-sm font-mono ${isDark ? 'text-surface-200' : 'text-surface-800'}`}>{t.topic}</span>
                  <div className="flex items-center gap-3"><span className="text-xs text-surface-500">Freq: {t.frequency}</span><span className={`text-xs font-mono ${isDark ? 'text-surface-400' : 'text-surface-600'}`}>Rel: {t.relevance}%</span></div>
                </div>
              ))}</div>
            </Collapsible>
          )}
        </div>
      )}
    </div>
  );
}

function Collapsible({ title, icon, open, onToggle, count, isDark, children }: { title: string; icon: React.ReactNode; open: boolean; onToggle: () => void; count?: number; isDark?: boolean; children: React.ReactNode }) {
  return (
    <div className="card overflow-hidden">
      <button onClick={onToggle} className={`w-full flex items-center justify-between px-5 py-4 transition-colors ${isDark ? 'hover:bg-white/[0.05]' : 'hover:bg-surface-50'}`}>
        <span className={`flex items-center gap-2 text-sm font-semibold ${isDark ? 'text-surface-200' : 'text-surface-800'}`}>{icon}{title}{count !== undefined && <span className={`text-xs font-normal ml-1 ${isDark ? 'text-surface-400' : 'text-surface-400'}`}>({count})</span>}</span>
        {open ? <ChevronUp className={`w-4 h-4 ${isDark ? 'text-surface-400' : 'text-surface-400'}`} /> : <ChevronDown className={`w-4 h-4 ${isDark ? 'text-surface-400' : 'text-surface-400'}`} />}
      </button>
      {open && <div className="px-5 pb-5">{children}</div>}
    </div>
  );
}

function SentimentBar({ label, value, max, color, isDark }: { label: string; value: number; max: number; color: string; isDark?: boolean }) {
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return (
    <div>
      <div className="flex justify-between text-xs text-surface-500 mb-1"><span>{label}</span><span className="font-mono">{value}%</span></div>
      <div className={`h-2 rounded-full overflow-hidden ${isDark ? 'bg-white/[0.06]' : 'bg-surface-100'}`}><div className={`h-full ${color} rounded-full transition-all duration-500`} style={{ width: `${pct}%` }} /></div>
    </div>
  );
}
