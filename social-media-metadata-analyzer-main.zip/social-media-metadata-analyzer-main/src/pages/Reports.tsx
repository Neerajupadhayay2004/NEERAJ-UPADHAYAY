import { useState, useEffect } from 'react';
import { BarChart3, Download, FileText, Globe, Image, Shield, AlertTriangle, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { ImageAnalysis, URLAnalysis, ContentAnalysis, RiskLevel } from '../types';
import RiskBadge from '../components/RiskBadge';
import { useTheme } from '../hooks/useTheme';

interface ReportsProps { onRefreshStats: () => void; }

export default function Reports(_props: ReportsProps) {
  const { isDark } = useTheme();
  const [imageAnalyses, setImageAnalyses] = useState<ImageAnalysis[]>([]);
  const [urlAnalyses, setUrlAnalyses] = useState<URLAnalysis[]>([]);
  const [contentAnalyses, setContentAnalyses] = useState<ContentAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [reportType, setReportType] = useState<'summary' | 'image' | 'url' | 'content'>('summary');

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setLoading(true);
    const [img, url, content] = await Promise.all([
      supabase.from('image_analyses').select('*').order('created_at', { ascending: false }),
      supabase.from('url_analyses').select('*').order('created_at', { ascending: false }),
      supabase.from('content_analyses').select('*').order('created_at', { ascending: false }),
    ]);
    setImageAnalyses(img.data || []); setUrlAnalyses(url.data || []); setContentAnalyses(content.data || []); setLoading(false);
  };

  const exportReport = () => {
    const report = generateReport();
    const blob = new Blob([report], { type: 'text/plain' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = u; a.download = `sentineleye-report-${new Date().toISOString().split('T')[0]}.txt`; a.click(); URL.revokeObjectURL(u);
  };

  const generateReport = () => {
    const d = '='.repeat(60); const d2 = '-'.repeat(60);
    let r = `${d}\nSENTINELEYE - INVESTIGATION REPORT\n${d}\nGenerated: ${new Date().toISOString()}\nType: ${reportType.toUpperCase()}\n\n`;
    const all = [...imageAnalyses, ...urlAnalyses, ...contentAnalyses];
    const crit = all.filter(i => (i as any).risk_level === 'critical' || (i as any).risk_level === 'high').length;
    r += `${d2}\nEXECUTIVE SUMMARY\n${d2}\nTotal: ${all.length} | Images: ${imageAnalyses.length} | URLs: ${urlAnalyses.length} | Content: ${contentAnalyses.length}\nCritical/High Risk: ${crit}\n\n`;

    if (reportType === 'summary' || reportType === 'image') {
      r += `${d2}\nIMAGE ANALYSES\n${d2}\n`;
      imageAnalyses.forEach((a, i) => { r += `\n[${i+1}] ${a.file_name} | Risk: ${a.risk_level.toUpperCase()} (${a.risk_score}/100)\n`; if (a.metadata_anomalies.length) a.metadata_anomalies.forEach(an => r += `  - [${an.severity.toUpperCase()}] ${an.description}\n`); });
    }
    if (reportType === 'summary' || reportType === 'url') {
      r += `\n${d2}\nURL ANALYSES\n${d2}\n`;
      urlAnalyses.forEach((a, i) => { r += `\n[${i+1}] ${a.url} | Risk: ${a.risk_level.toUpperCase()} (${a.risk_score}/100)\n`; a.phishing_indicators.forEach(ind => r += `  - [PHISHING/${ind.severity.toUpperCase()}] ${ind.description}\n`); a.scam_indicators.forEach(ind => r += `  - [SCAM/${ind.severity.toUpperCase()}] ${ind.description}\n`); });
    }
    if (reportType === 'summary' || reportType === 'content') {
      r += `\n${d2}\nCONTENT ANALYSES\n${d2}\n`;
      contentAnalyses.forEach((a, i) => { r += `\n[${i+1}] ${a.source_type.toUpperCase()} | Risk: ${a.risk_level.toUpperCase()} (${a.risk_score}/100)\n`; a.risk_indicators.forEach(ind => r += `  - [${ind.severity.toUpperCase()}] ${ind.description}\n`); r += `  Entities: ${a.entities.map(e => `${e.entity}(${e.type})`).join(', ')}\n`; });
    }
    r += `\n${d}\nEND OF REPORT\n${d}\n`;
    return r;
  };

  const dist = () => {
    const d: Record<string, number> = { safe: 0, low: 0, medium: 0, high: 0, critical: 0 };
    [...imageAnalyses, ...urlAnalyses, ...contentAnalyses].forEach(a => { const l = (a as any).risk_level as string; if (l in d) d[l] += 1; });
    return d as Record<RiskLevel, number>;
  };

  if (loading) return <div className="flex items-center justify-center h-96"><div className="w-8 h-8 border-2 border-brand-200 border-t-brand-600 rounded-full animate-spin" /></div>;

  const d = dist();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'} flex items-center gap-3`}><BarChart3 className="w-6 h-6 text-brand-500" /> Reports & Analytics</h1><p className="text-sm text-surface-500 mt-0.5">Investigation analytics and export reports</p></div>
        <button onClick={exportReport} className="btn-primary text-sm"><Download className="w-4 h-4 mr-2" />Export Report</button>
      </div>

      <div className="flex gap-2">
        {(['summary', 'image', 'url', 'content'] as const).map(t => (
          <button key={t} onClick={() => setReportType(t)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${reportType === t ? (isDark ? 'bg-brand-500/10 text-brand-300 border border-brand-500/20' : 'bg-brand-50 text-brand-700 border border-brand-200') : (isDark ? 'bg-white/[0.05] text-surface-400 hover:bg-white/[0.08] border border-white/[0.06]' : 'bg-white text-surface-600 hover:bg-surface-50 border border-surface-200')}`}>
            {t === 'summary' ? 'Summary' : t === 'image' ? 'Images' : t === 'url' ? 'URLs' : 'Content'}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <MiniStat icon={Shield} label="Safe" value={d.safe} color="text-surface-500" isDark={isDark} />
        <MiniStat icon={Shield} label="Low" value={d.low} color={isDark ? 'text-success-400' : 'text-success-600'} isDark={isDark} />
        <MiniStat icon={AlertTriangle} label="Medium" value={d.medium} color={isDark ? 'text-warning-400' : 'text-warning-600'} isDark={isDark} />
        <MiniStat icon={AlertTriangle} label="High" value={d.high} color={isDark ? 'text-orange-400' : 'text-orange-600'} isDark={isDark} />
        <MiniStat icon={AlertTriangle} label="Critical" value={d.critical} color={isDark ? 'text-danger-400' : 'text-danger-600'} isDark={isDark} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="section-title mb-4"><Image className="w-4 h-4 text-brand-500" /> Image Analysis</h3>
          {imageAnalyses.length === 0 ? <p className="text-sm text-surface-400">No image analyses yet</p> : (
            <div className="space-y-2">{imageAnalyses.slice(0, 5).map(a => (
              <div key={a.id} className={`flex items-center justify-between p-2.5 rounded-lg ${isDark ? 'bg-white/[0.03] border border-white/[0.06]' : 'bg-surface-50 border border-surface-200'}`}>
                <div className="flex items-center gap-2 min-w-0"><Image className="w-3.5 h-3.5 text-brand-400 flex-shrink-0" /><span className={`text-xs ${isDark ? 'text-surface-300' : 'text-surface-700'} truncate font-medium`}>{a.file_name}</span></div>
                <RiskBadge level={a.risk_level} score={a.risk_score} />
              </div>
            ))}{imageAnalyses.length > 5 && <p className="text-xs text-surface-400 text-center">+{imageAnalyses.length - 5} more</p>}</div>
          )}
        </div>
        <div className="card p-6">
          <h3 className="section-title mb-4"><Globe className={`w-4 h-4 ${isDark ? 'text-success-400' : 'text-success-600'}`} /> URL Analysis</h3>
          {urlAnalyses.length === 0 ? <p className="text-sm text-surface-400">No URL analyses yet</p> : (
            <div className="space-y-2">{urlAnalyses.slice(0, 5).map(a => (
              <div key={a.id} className={`flex items-center justify-between p-2.5 rounded-lg ${isDark ? 'bg-white/[0.03] border border-white/[0.06]' : 'bg-surface-50 border border-surface-200'}`}>
                <div className="flex items-center gap-2 min-w-0"><Globe className="w-3.5 h-3.5 text-success-500 flex-shrink-0" /><span className={`text-xs ${isDark ? 'text-surface-300' : 'text-surface-700'} font-mono truncate`}>{a.domain}</span></div>
                <RiskBadge level={a.risk_level} score={a.risk_score} />
              </div>
            ))}{urlAnalyses.length > 5 && <p className="text-xs text-surface-400 text-center">+{urlAnalyses.length - 5} more</p>}</div>
          )}
        </div>
        <div className="card p-6 lg:col-span-2">
          <h3 className="section-title mb-4"><FileText className={`w-4 h-4 ${isDark ? 'text-warning-400' : 'text-warning-600'}`} /> Content Analysis</h3>
          {contentAnalyses.length === 0 ? <p className="text-sm text-surface-400">No content analyses yet</p> : (
            <div className="space-y-2">{contentAnalyses.slice(0, 5).map(a => (
              <div key={a.id} className={`flex items-center justify-between p-2.5 rounded-lg ${isDark ? 'bg-white/[0.03] border border-white/[0.06]' : 'bg-surface-50 border border-surface-200'}`}>
                <div className="flex items-center gap-2 min-w-0"><FileText className="w-3.5 h-3.5 text-warning-500 flex-shrink-0" /><span className={`text-xs ${isDark ? 'text-surface-300' : 'text-surface-700'} truncate`}>{a.content.slice(0, 60)}...</span></div>
                <RiskBadge level={a.risk_level} score={a.risk_score} />
              </div>
            ))}{contentAnalyses.length > 5 && <p className="text-xs text-surface-400 text-center">+{contentAnalyses.length - 5} more</p>}</div>
          )}
        </div>
      </div>

      <div className="card p-6">
        <h3 className="section-title mb-4"><Clock className="w-4 h-4 text-brand-500" /> Recent Activity</h3>
        <div className="space-y-2">
          {[...imageAnalyses.map(a => ({ ...a, _t: 'image' })), ...urlAnalyses.map(a => ({ ...a, _t: 'url' })), ...contentAnalyses.map(a => ({ ...a, _t: 'content' }))]
            .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, 10)
            .map((item: any, i: number) => {
              const Icon = item._t === 'image' ? Image : item._t === 'url' ? Globe : FileText;
              const color = item._t === 'image' ? 'text-brand-500' : item._t === 'url' ? (isDark ? 'text-success-400' : 'text-success-600') : (isDark ? 'text-warning-400' : 'text-warning-600');
              const label = item._t === 'image' ? item.file_name : item._t === 'url' ? item.domain || item.url : item.content?.slice(0, 40) + '...';
              return (
                <div key={i} className={`flex items-center gap-3 p-2 rounded-lg ${isDark ? 'hover:bg-white/[0.05]' : 'hover:bg-surface-50'} transition-colors`}>
                  <div className={`w-7 h-7 rounded-full ${isDark ? 'bg-white/[0.03] border border-white/[0.06]' : 'bg-surface-50 border border-surface-200'} flex items-center justify-center`}><Icon className={`w-3.5 h-3.5 ${color}`} /></div>
                  <span className={`text-xs ${isDark ? 'text-surface-300' : 'text-surface-700'} truncate flex-1 font-medium`}>{label}</span>
                  <RiskBadge level={item.risk_level} />
                  <span className="text-xs text-surface-400 font-mono">{new Date(item.created_at).toLocaleDateString()}</span>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}

function MiniStat({ icon: Icon, label, value, color, isDark }: { icon: any; label: string; value: number; color: string; isDark: boolean }) {
  return (
    <div className="card p-4 text-center">
      <Icon className={`w-5 h-5 mx-auto mb-1 ${color}`} />
      <p className={`text-xl font-bold ${isDark ? 'text-white' : 'text-surface-900'}`}>{value}</p>
      <p className="text-xs text-surface-500">{label}</p>
    </div>
  );
}
