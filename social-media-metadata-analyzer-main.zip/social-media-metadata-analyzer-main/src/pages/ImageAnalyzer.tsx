import { useState, useCallback } from 'react';
import {
  Scan, Upload, MapPin, Camera, Clock, HardDrive,
  AlertTriangle, FileImage, Loader2, ChevronDown, ChevronUp, Info, CheckCircle, XCircle
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Investigation, ImageAnalysis, MetadataAnomaly, RiskLevel } from '../types';
import RiskBadge from '../components/RiskBadge';
import InvestigationSelector from '../components/InvestigationSelector';
import { useTheme } from '../hooks/useTheme';

interface ImageAnalyzerProps {
  investigations: Investigation[];
  activeInvestigation: Investigation | null;
  onSelectInvestigation: (inv: Investigation | null) => void;
  onRefreshInvestigations: () => void;
  onRefreshStats: () => void;
}

export default function ImageAnalyzer({ investigations, activeInvestigation, onSelectInvestigation, onRefreshInvestigations, onRefreshStats }: ImageAnalyzerProps) {
  const { isDark } = useTheme();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ImageAnalysis | null>(null);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ exif: true, gps: true, camera: true, device: false, anomalies: true, timestamps: true });
  const toggle = (k: string) => setExpanded(p => ({ ...p, [k]: !p[k] }));

  const handleFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f); setError(''); setResult(null);
    const r = new FileReader();
    r.onload = (ev) => setPreview(ev.target?.result as string);
    r.readAsDataURL(f);
  }, []);

  // ---- Full EXIF Parser ----
  const parseImageMetadata = (buffer: ArrayBuffer) => {
    const view = new DataView(buffer);
    const exif: Record<string, unknown> = {};
    const gps: Record<string, unknown> = {};
    const camera: Record<string, unknown> = {};
    const device: Record<string, unknown> = {};
    const timestamps: Record<string, unknown> = {};
    const anomalies: MetadataAnomaly[] = [];

    // File-level properties
    exif.fileSize = buffer.byteLength;
    exif.byteLengthHex = '0x' + buffer.byteLength.toString(16).toUpperCase();

    // Check JPEG SOI marker
    const isJPEG = view.getUint16(0) === 0xFFD8;
    const isPNG = view.getUint16(0) === 0x8950;
    const isTIFF = view.getUint16(0) === 0x4949 || view.getUint16(0) === 0x4D4D;
    const isHEIC = view.getUint16(4) === 0x66747970; // ftyp box

    exif.fileFormat = isJPEG ? 'JPEG' : isPNG ? 'PNG' : isTIFF ? 'TIFF' : isHEIC ? 'HEIC/HEIF' : 'Unknown';

    if (!isJPEG) {
      if (isPNG) {
        exif.hasExif = false;
        // Parse PNG text chunks (tEXt, iTXt, zTXt)
        let offset = 8; // After PNG signature
        while (offset < view.byteLength - 8) {
          const chunkLen = (view.getUint8(offset) << 24) | (view.getUint8(offset+1) << 16) | (view.getUint8(offset+2) << 8) | view.getUint8(offset+3);
          const chunkType = String.fromCharCode(view.getUint8(offset+4), view.getUint8(offset+5), view.getUint8(offset+6), view.getUint8(offset+7));
          if (chunkType === 'tEXt' || chunkType === 'iTXt') {
            const dataStart = offset + 8;
            const dataEnd = Math.min(dataStart + chunkLen, view.byteLength);
            const textData: string[] = [];
            for (let i = dataStart; i < dataEnd; i++) textData.push(String.fromCharCode(view.getUint8(i)));
            const raw = textData.join('');
            if (raw.includes('Software')) device.software = raw.split('Software')[1]?.split('\0')[1] || 'Detected';
            if (raw.includes('Comment')) exif.pngComment = raw.split('Comment')[1]?.split('\0')[1] || 'Detected';
            exif.hasTextChunk = true;
          }
          offset += 12 + chunkLen; // 4 len + 4 type + data + 4 crc
          if (chunkType === 'IEND') break;
          if (chunkLen > view.byteLength) break;
        }
        anomalies.push({ type: 'no_exif', field: 'EXIF', description: 'PNG files do not contain EXIF metadata by default', severity: 'low' });
      } else {
        exif.hasExif = false;
        anomalies.push({ type: 'missing', field: 'EXIF', description: 'No EXIF data found — format may not support embedded metadata', severity: 'medium' });
      }
    } else {
      // Parse JPEG APP1 (EXIF)
      let offset = 2;
      while (offset < view.byteLength - 4) {
        const marker = view.getUint16(offset);
        if (marker === 0xFFE1) {
          const len = view.getUint16(offset + 2);
          const header = String.fromCharCode(view.getUint8(offset+4), view.getUint8(offset+5), view.getUint8(offset+6), view.getUint8(offset+7));
          if (header === 'Exif') {
            exif.hasExif = true;
            exif.app1Length = len;
            const tOff = offset + 10;
            if (tOff + 8 <= view.byteLength) {
              const bo = view.getUint16(tOff);
              const le = bo === 0x4949;
              exif.byteOrder = le ? 'Little Endian (II)' : 'Big Endian (MM)';
              const ifdOff = le ? view.getUint32(tOff+4, true) : view.getUint32(tOff+4, false);
              parseIFD(view, tOff + ifdOff, le, exif, camera, device, timestamps, gps, tOff, 0);
            }
          }
          break;
        } else if ((marker & 0xFF00) === 0xFF00) {
          if (marker === 0xFFE0) exif.hasJFIF = true;
          if (marker === 0xFFE2) exif.hasICCProfile = true;
          offset += 2 + view.getUint16(offset + 2);
        } else break;
      }
    }

    // ---- Anomaly Detection ----
    if (!exif.hasExif) {
      anomalies.push({ type: 'no_exif', field: 'EXIF', description: 'No EXIF metadata present — may have been stripped for privacy or obfuscation', severity: 'medium' });
    } else {
      // Check if GPS present (privacy risk)
      if (gps.latitude && gps.longitude) {
        anomalies.push({ type: 'geolocation', field: 'GPS', description: `GPS coordinates found: ${Number(gps.latitude).toFixed(6)}, ${Number(gps.longitude).toFixed(6)} — potential privacy exposure`, severity: 'high' });
      }
      // Software editing detection
      if (device.software) {
        const editingSoftware = ['photoshop', 'gimp', 'lightroom', 'snapseed', 'picasa', 'canva', 'pixlr'];
        const swLower = String(device.software).toLowerCase();
        if (editingSoftware.some(s => swLower.includes(s))) {
          anomalies.push({ type: 'edited', field: 'Software', description: `Image edited with: ${device.software} — metadata may have been modified`, severity: 'medium' });
        } else {
          anomalies.push({ type: 'software', field: 'Software', description: `Processing software detected: ${device.software}`, severity: 'low' });
        }
      }
      // No camera but has EXIF = possible screenshot
      if (!camera.make && !camera.model && exif.hasExif) {
        anomalies.push({ type: 'screenshot', field: 'Camera', description: 'EXIF present but no camera info — likely a screenshot or processed image', severity: 'low' });
      }
      // Timestamp anomalies
      if (timestamps.dateTimeOriginal && timestamps.dateTimeDigitized) {
        if (timestamps.dateTimeOriginal !== timestamps.dateTimeDigitized) {
          anomalies.push({ type: 'timestamp_mismatch', field: 'Timestamps', description: 'Original and digitized timestamps differ — image may have been modified after capture', severity: 'medium' });
        }
      }
      // Missing orientation
      if (exif.hasExif && !exif.orientation) {
        anomalies.push({ type: 'missing_orientation', field: 'Orientation', description: 'No orientation tag — some viewers may display image incorrectly', severity: 'low' });
      }
    }

    // ---- Risk Score ----
    let riskScore = 0;
    if (exif.hasExif) riskScore += 5;
    if (gps.latitude) riskScore += 30;
    if (camera.make) riskScore += 3;
    if (device.software) riskScore += 10;
    if (anomalies.some(a => a.severity === 'high' || a.severity === 'critical')) riskScore += 20;
    if (!exif.hasExif) riskScore += 5;
    if (anomalies.some(a => a.type === 'edited')) riskScore += 15;
    if (anomalies.some(a => a.type === 'timestamp_mismatch')) riskScore += 10;
    riskScore = Math.min(riskScore, 100);
    const riskLevel: RiskLevel = riskScore >= 75 ? 'critical' : riskScore >= 55 ? 'high' : riskScore >= 35 ? 'medium' : riskScore >= 15 ? 'low' : 'safe';

    return { exif, gps, camera, device, timestamps, anomalies, riskScore, riskLevel };
  };

  const readStr = (v: DataView, off: number, cnt: number, le: boolean, tOff: number): string => {
    try {
      const dOff = cnt > 4 ? tOff + (le ? v.getUint32(off, true) : v.getUint32(off, false)) : off;
      let s = '';
      for (let i = 0; i < cnt && dOff + i < v.byteLength; i++) { const c = v.getUint8(dOff + i); if (c === 0) break; s += String.fromCharCode(c); }
      return s.trim();
    } catch { return ''; }
  };

  const readRational = (v: DataView, off: number, le: boolean, tOff: number): number => {
    try {
      const dOff = tOff + (le ? v.getUint32(off, true) : v.getUint32(off, false));
      const num = le ? v.getUint32(dOff, true) : v.getUint32(dOff, false);
      const den = le ? v.getUint32(dOff + 4, true) : v.getUint32(dOff + 4, false);
      return den ? num / den : 0;
    } catch { return 0; }
  };

  const parseIFD = (v: DataView, off: number, le: boolean, exif: any, cam: any, dev: any, ts: any, gps: any, tOff: number, depth: number) => {
    if (depth > 4) return;
    try {
      if (off + 2 > v.byteLength) return;
      const cnt = le ? v.getUint16(off, true) : v.getUint16(off, false);
      for (let i = 0; i < cnt && (off + 2 + i * 12 + 12) <= v.byteLength; i++) {
        const tO = off + 2 + i * 12;
        const tag = le ? v.getUint16(tO, true) : v.getUint16(tO, false);
        const vc = le ? v.getUint32(tO + 4, true) : v.getUint32(tO + 4, false);
        const vO = tO + 8;

        // IFD0 tags
        if (tag === 0x010F) cam.make = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x0110) cam.model = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x0112) exif.orientation = vc;
        else if (tag === 0x011A) exif.xResolution = readRational(v, vO, le, tOff);
        else if (tag === 0x011B) exif.yResolution = readRational(v, vO, le, tOff);
        else if (tag === 0x0128) exif.resolutionUnit = vc === 2 ? 'inches' : vc === 3 ? 'centimeters' : vc;
        else if (tag === 0x0131) dev.software = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x0132) ts.dateTime = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x013B) dev.artist = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x0213) exif.yCbCrPositioning = vc === 1 ? 'Centered' : vc === 2 ? 'Co-sited' : vc;
        else if (tag === 0x8298) dev.copyright = readStr(v, vO, vc, le, tOff);
        // Exif sub-IFD pointer
        else if (tag === 0x8769) {
          const eOff = tOff + (le ? v.getUint32(vO, true) : v.getUint32(vO, false));
          parseExifIFD(v, eOff, le, exif, cam, dev, ts, tOff);
        }
        // GPS sub-IFD pointer
        else if (tag === 0x8825) {
          const gOff = tOff + (le ? v.getUint32(vO, true) : v.getUint32(vO, false));
          parseGPSIFD(v, gOff, le, gps, tOff);
        }
        // Interop IFD
        else if (tag === 0xA005) {
          const iOff = tOff + (le ? v.getUint32(vO, true) : v.getUint32(vO, false));
          parseIFD(v, iOff, le, exif, cam, dev, ts, gps, tOff, depth + 1);
        }
      }
    } catch { /* partial */ }
  };

  const parseExifIFD = (v: DataView, off: number, le: boolean, exif: any, cam: any, _dev: any, ts: any, tOff: number) => {
    try {
      if (off + 2 > v.byteLength) return;
      const cnt = le ? v.getUint16(off, true) : v.getUint16(off, false);
      for (let i = 0; i < cnt && (off + 2 + i * 12 + 12) <= v.byteLength; i++) {
        const tO = off + 2 + i * 12;
        const tag = le ? v.getUint16(tO, true) : v.getUint16(tO, false);
        const vc = le ? v.getUint32(tO + 4, true) : v.getUint32(tO + 4, false);
        const vO = tO + 8;

        if (tag === 0x9000) exif.exifVersion = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x9003) ts.dateTimeOriginal = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x9004) ts.dateTimeDigitized = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x9201) exif.exposureTime = readRational(v, vO, le, tOff);
        else if (tag === 0x9202) exif.fNumber = readRational(v, vO, le, tOff);
        else if (tag === 0x9204) exif.exposureBias = readRational(v, vO, le, tOff);
        else if (tag === 0x9205) exif.maxAperture = readRational(v, vO, le, tOff);
        else if (tag === 0x9207) exif.meteringMode = vc;
        else if (tag === 0x9209) exif.flash = vc;
        else if (tag === 0x920A) cam.focalLength = readRational(v, vO, le, tOff);
        else if (tag === 0xA001) exif.colorSpace = vc === 1 ? 'sRGB' : vc === 0xFFFF ? 'Uncalibrated' : vc;
        else if (tag === 0xA002) exif.pixelWidth = le ? v.getUint32(vO, true) : v.getUint32(vO, false);
        else if (tag === 0xA003) exif.pixelHeight = le ? v.getUint32(vO, true) : v.getUint32(vO, false);
        else if (tag === 0xA405) cam.focalLength35mm = le ? v.getUint16(vO, true) : v.getUint16(vO, false);
        else if (tag === 0xA433) cam.lensMake = readStr(v, vO, vc, le, tOff);
        else if (tag === 0xA434) cam.lensModel = readStr(v, vO, vc, le, tOff);
        else if (tag === 0xA432) cam.lensInfo = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x9286) exif.userComment = 'Present (binary)';
        else if (tag === 0x829D) exif.fNumber2 = readRational(v, vO, le, tOff);
        else if (tag === 0x8822) exif.exposureProgram = vc;
        else if (tag === 0x8827) exif.isoSpeed = le ? v.getUint16(vO, true) : v.getUint16(vO, false);
        else if (tag === 0x9290) ts.subSecTime = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x9291) ts.subSecTimeOrig = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x9292) ts.subSecTimeDigi = readStr(v, vO, vc, le, tOff);
      }
    } catch { /* partial */ }
  };

  const parseGPSIFD = (v: DataView, off: number, le: boolean, gps: any, tOff: number) => {
    try {
      if (off + 2 > v.byteLength) return;
      const cnt = le ? v.getUint16(off, true) : v.getUint16(off, false);
      for (let i = 0; i < cnt && (off + 2 + i * 12 + 12) <= v.byteLength; i++) {
        const tO = off + 2 + i * 12;
        const tag = le ? v.getUint16(tO, true) : v.getUint16(tO, false);
        const vc = le ? v.getUint32(tO + 4, true) : v.getUint32(tO + 4, false);
        const vO = tO + 8;
        if (tag === 0x0001) gps.latitudeRef = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x0002) gps.latitude = readGPSCoord(v, tO, le, tOff);
        else if (tag === 0x0003) gps.longitudeRef = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x0004) gps.longitude = readGPSCoord(v, tO, le, tOff);
        else if (tag === 0x0005) gps.altitudeRef = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x0006) gps.altitude = readRational(v, vO, le, tOff);
        else if (tag === 0x0007) gps.gpsTimeStamp = readStr(v, vO, vc, le, tOff);
        else if (tag === 0x001D) gps.dateStamp = readStr(v, vO, vc, le, tOff);
      }
    } catch { /* partial */ }
  };

  const readGPSCoord = (v: DataView, tO: number, le: boolean, tOff: number): number => {
    try {
      const dOff = tOff + (le ? v.getUint32(tO + 8, true) : v.getUint32(tO + 8, false));
      const deg = readRational(v, tO + 8, le, tOff);
      // For GPS coords stored as 3 rationals
      const secOff = dOff + 16;
      if (secOff + 8 <= v.byteLength) {
        const min = le ? v.getUint32(dOff + 8, true) / v.getUint32(dOff + 12, true) : v.getUint32(dOff + 8, false) / v.getUint32(dOff + 12, false);
        const sec = le ? v.getUint32(dOff + 16, true) / v.getUint32(dOff + 20, true) : v.getUint32(dOff + 16, false) / v.getUint32(dOff + 20, false);
        return deg + min / 60 + sec / 3600;
      }
      return deg;
    } catch { return 0; }
  };

  const analyze = async () => {
    if (!file) return;
    setAnalyzing(true); setError('');
    try {
      const buf = await file.arrayBuffer();
      const meta = parseImageMetadata(buf);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const row = {
        investigation_id: activeInvestigation?.id ?? null,
        file_name: file.name, file_size: file.size, file_type: file.type.split('/')[1] || 'unknown', mime_type: file.type,
        width: (meta.exif.pixelWidth as number) || null, height: (meta.exif.pixelHeight as number) || null,
        exif_data: meta.exif, gps_data: meta.gps, camera_data: meta.camera, device_data: meta.device, timestamps: meta.timestamps,
        metadata_anomalies: meta.anomalies, risk_score: meta.riskScore, risk_level: meta.riskLevel,
        analysis_summary: { hasExif: !!meta.exif.hasExif, hasGPS: !!(meta.gps.latitude || meta.gps.longitude), hasCamera: !!(meta.camera.make || meta.camera.model), anomalyCount: meta.anomalies.length, fileFormat: meta.exif.fileFormat },
        user_id: user.id,
      };

      const { data, error: ie } = await supabase.from('image_analyses').insert(row).select().single();
      if (ie) throw ie;
      setResult(data); onRefreshStats();
      await supabase.from('audit_logs').insert({ user_id: user.id, action: 'analyze_image', resource_type: 'image_analysis', resource_id: data.id, details: { file_name: file.name, risk_score: meta.riskScore, risk_level: meta.riskLevel } });
    } catch (err: any) { setError(err.message || 'Analysis failed'); }
    finally { setAnalyzing(false); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'} flex items-center gap-3`}><Scan className="w-6 h-6 text-brand-500" /> Image Metadata Checker</h1>
        <p className="text-sm text-surface-500 mt-0.5">Extract EXIF, GPS, camera details, device info, timestamps, and detect metadata anomalies</p>
      </div>

      <InvestigationSelector investigations={investigations} activeInvestigation={activeInvestigation} onSelect={onSelectInvestigation} onRefresh={onRefreshInvestigations} />

      {/* Upload */}
      <div className="card p-6">
        <div className="flex items-start gap-6">
          <div className="flex-1">
            <label className="label"><Upload className="w-3.5 h-3.5 inline mr-1" /> Upload Image</label>
            <div className={`border-2 border-dashed ${isDark ? 'border-white/[0.15]' : 'border-surface-300'} rounded-xl p-8 text-center ${isDark ? 'hover:border-brand-400 hover:bg-brand-500/[0.08]' : 'hover:border-brand-400 hover:bg-brand-50/30'} transition-colors cursor-pointer`}>
              <input type="file" accept="image/*" onChange={handleFile} className="hidden" id="img-up" />
              <label htmlFor="img-up" className="cursor-pointer">
                <FileImage className={`w-10 h-10 mx-auto ${isDark ? 'text-surface-500' : 'text-surface-300'} mb-3`} />
                <p className={`text-sm ${isDark ? 'text-surface-400' : 'text-surface-600'} font-medium`}>Click to upload or drag image here</p>
                <p className={`text-xs ${isDark ? 'text-surface-500' : 'text-surface-400'} mt-1`}>JPEG, PNG, TIFF, HEIC supported</p>
              </label>
            </div>
            {file && (
              <div className="mt-3 flex items-center gap-3">
                <span className={`flex-1 text-sm ${isDark ? 'text-surface-400' : 'text-surface-600'}`}><span className={`font-medium ${isDark ? 'text-white' : 'text-surface-900'}`}>{file.name}</span> <span className={isDark ? 'text-surface-500' : 'text-surface-400'}>({(file.size / 1024).toFixed(1)} KB)</span></span>
                <button onClick={analyze} disabled={analyzing} className="btn-primary text-sm disabled:opacity-50">
                  {analyzing ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Analyzing...</> : <><Scan className="w-4 h-4 mr-2" />Analyze Metadata</>}
                </button>
              </div>
            )}
            {error && <p className={`mt-2 text-sm ${isDark ? 'text-danger-400 bg-danger-500/10 border-danger-500/30' : 'text-danger-600 bg-danger-50 border-danger-200'} border rounded-lg p-3`}>{error}</p>}
          </div>
          {preview && (
            <div className={`w-48 h-48 rounded-xl overflow-hidden border ${isDark ? 'border-white/[0.06]' : 'border-surface-200'} flex-shrink-0 shadow-sm`}>
              <img src={preview} alt="Preview" className="w-full h-full object-cover" />
            </div>
          )}
        </div>
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-4 animate-slide-up">
          {/* Header */}
          <div className="card p-5 flex items-center gap-6">
            <RiskBadge level={result.risk_level} score={result.risk_score} size="lg" />
            <div className="flex-1 min-w-0">
              <h3 className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-surface-900'}`}>{result.file_name}</h3>
              <p className="text-sm text-surface-500">{result.file_type?.toUpperCase()} | {result.width}x{result.height} | {(result.file_size! / 1024).toFixed(1)} KB</p>
            </div>
          </div>

          {/* Anomalies */}
          {result.metadata_anomalies.length > 0 && (
            <Collapsible title="Metadata Anomalies" icon={<AlertTriangle className="w-4 h-4 text-danger-500" />} open={expanded.anomalies} onToggle={() => toggle('anomalies')} count={result.metadata_anomalies.length} isDark={isDark}>
              <div className="space-y-2">
                {result.metadata_anomalies.map((a, i) => (
                  <div key={i} className={`p-3 rounded-lg border ${a.severity === 'high' || a.severity === 'critical' ? isDark ? 'bg-danger-500/10 border-danger-500/30' : 'bg-danger-50 border-danger-200' : a.severity === 'medium' ? isDark ? 'bg-warning-500/10 border-warning-500/30' : 'bg-warning-50 border-warning-200' : isDark ? 'bg-white/[0.03] border-white/[0.06]' : 'bg-surface-50 border-surface-200'}`}>
                    <div className="flex items-center gap-2 mb-1"><RiskBadge level={a.severity} /><span className={`text-sm font-medium ${isDark ? 'text-surface-300' : 'text-surface-800'}`}>{a.type.replace(/_/g, ' ')}</span></div>
                    <p className={`text-xs ${isDark ? 'text-surface-400' : 'text-surface-600'}`}>{a.description}</p>
                  </div>
                ))}
              </div>
            </Collapsible>
          )}

          <Collapsible title="EXIF Data" icon={<Info className="w-4 h-4 text-brand-500" />} open={expanded.exif} onToggle={() => toggle('exif')} count={Object.keys(result.exif_data).length} isDark={isDark}>
            <DataTable data={result.exif_data} isDark={isDark} />
          </Collapsible>

          <Collapsible title="GPS Information" icon={<MapPin className={`w-4 h-4 ${isDark ? 'text-success-400' : 'text-success-600'}`} />} open={expanded.gps} onToggle={() => toggle('gps')} isDark={isDark}>
            {result.gps_data.latitude || result.gps_data.longitude ? (
              <>
                <DataTable data={result.gps_data} isDark={isDark} />
                {result.gps_data.latitude && result.gps_data.longitude && (
                  <div className={`mt-3 p-3 rounded-lg ${isDark ? 'bg-danger-500/10 border-danger-500/30' : 'bg-danger-50 border-danger-200'} border`}>
                    <p className={`text-xs font-mono ${isDark ? 'text-danger-400' : 'text-danger-700'}`}>Coordinates: {Number(result.gps_data.latitude).toFixed(6)}, {Number(result.gps_data.longitude).toFixed(6)}</p>
                    <p className={`text-xs ${isDark ? 'text-danger-400' : 'text-danger-600'} mt-1`}>Privacy Risk: GPS data reveals physical location</p>
                  </div>
                )}
              </>
            ) : <p className="text-sm text-surface-500">No GPS data found in image metadata</p>}
          </Collapsible>

          <Collapsible title="Camera Details" icon={<Camera className="w-4 h-4 text-brand-500" />} open={expanded.camera} onToggle={() => toggle('camera')} count={Object.keys(result.camera_data).length} isDark={isDark}>
            <DataTable data={result.camera_data} isDark={isDark} />
          </Collapsible>

          <Collapsible title="Device Information" icon={<HardDrive className="w-4 h-4 text-surface-500" />} open={expanded.device} onToggle={() => toggle('device')} isDark={isDark}>
            <DataTable data={result.device_data} isDark={isDark} />
          </Collapsible>

          <Collapsible title="Timestamps" icon={<Clock className={`w-4 h-4 ${isDark ? 'text-warning-400' : 'text-warning-600'}`} />} open={expanded.timestamps} onToggle={() => toggle('timestamps')} count={Object.keys(result.timestamps).length} isDark={isDark}>
            <DataTable data={result.timestamps} isDark={isDark} />
          </Collapsible>
        </div>
      )}
    </div>
  );
}

function Collapsible({ title, icon, open, onToggle, count, children, isDark }: { title: string; icon: React.ReactNode; open: boolean; onToggle: () => void; count?: number; children: React.ReactNode; isDark: boolean }) {
  return (
    <div className="card overflow-hidden">
      <button onClick={onToggle} className={`w-full flex items-center justify-between px-5 py-4 ${isDark ? 'hover:bg-white/[0.03]' : 'hover:bg-surface-50'} transition-colors`}>
        <span className={`flex items-center gap-2 text-sm font-semibold ${isDark ? 'text-surface-300' : 'text-surface-800'}`}>{icon}{title}{count !== undefined && <span className={`text-xs ${isDark ? 'text-surface-500' : 'text-surface-400'} font-normal ml-1`}>({count} fields)</span>}</span>
        {open ? <ChevronUp className={`w-4 h-4 ${isDark ? 'text-surface-500' : 'text-surface-400'}`} /> : <ChevronDown className={`w-4 h-4 ${isDark ? 'text-surface-500' : 'text-surface-400'}`} />}
      </button>
      {open && <div className="px-5 pb-5">{children}</div>}
    </div>
  );
}

function DataTable({ data, isDark }: { data: Record<string, unknown>; isDark: boolean }) {
  const entries = Object.entries(data);
  if (!entries.length) return <p className="text-sm text-surface-500">No data available</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <tbody>
          {entries.map(([k, v]) => {
            const boolish = typeof v === 'boolean';
            return (
              <tr key={k} className={`border-b ${isDark ? 'border-white/[0.04]' : 'border-surface-100'} last:border-0`}>
                <td className={`py-2 pr-4 ${isDark ? 'text-surface-500' : 'text-surface-500'} font-mono text-xs whitespace-nowrap`}>{k}</td>
                <td className={`py-2 font-mono text-xs ${boolish && v ? isDark ? 'text-success-400' : 'text-success-600' : boolish && !v ? isDark ? 'text-danger-400' : 'text-danger-600' : isDark ? 'text-surface-300' : 'text-surface-800'}`}>
                  {boolish ? (v ? <CheckCircle className="w-4 h-4 inline text-success-500" /> : <XCircle className="w-4 h-4 inline text-danger-500" />) : String(v)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
