import { useState, useEffect } from 'react';
import {
  Scan, Globe, FileText, Shield, ShieldAlert,
  TrendingUp, FolderOpen, FileSearch, Clock, AlertTriangle,
  ChevronRight, Zap, Eye, Target, Layers, BarChart3
} from 'lucide-react';
import { useTheme } from '../hooks/useTheme';
import type { DashboardStats, Page } from '../types';
import { RiskGauge } from '../components/RiskBadge';

interface DashboardProps {
  stats: DashboardStats;
  setCurrentPage: (page: Page) => void;
}

export default function Dashboard({ stats, setCurrentPage }: DashboardProps) {
  const { isDark } = useTheme();
  const riskLevel = stats.averageRiskScore >= 75 ? 'critical' : stats.averageRiskScore >= 55 ? 'high' : stats.averageRiskScore >= 35 ? 'medium' : stats.averageRiskScore >= 15 ? 'low' : 'safe';

  // Animated counter effect
  const [displayStats, setDisplayStats] = useState({ ...stats });
  useEffect(() => {
    const duration = 800;
    const steps = 30;
    const interval = duration / steps;
    let step = 0;
    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const ease = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      setDisplayStats({
        totalInvestigations: Math.round(stats.totalInvestigations * ease),
        activeInvestigations: Math.round(stats.activeInvestigations * ease),
        imageAnalyses: Math.round(stats.imageAnalyses * ease),
        urlAnalyses: Math.round(stats.urlAnalyses * ease),
        contentAnalyses: Math.round(stats.contentAnalyses * ease),
        evidenceCount: Math.round(stats.evidenceCount * ease),
        criticalFindings: Math.round(stats.criticalFindings * ease),
        averageRiskScore: Math.round(stats.averageRiskScore * ease),
      });
      if (step >= steps) clearInterval(timer);
    }, interval);
    return () => clearInterval(timer);
  }, [stats]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className={`text-2xl lg:text-3xl font-bold ${isDark ? 'text-white' : 'text-surface-900'}`}>
            Investigation Dashboard
          </h1>
          <p className={`text-sm mt-0.5 ${isDark ? 'text-surface-400' : 'text-surface-500'}`}>OSINT analysis overview and threat intelligence</p>
        </div>
        <div className={`flex items-center gap-2 text-xs font-mono px-3 py-2 rounded-xl border ${
          isDark ? 'bg-white/[0.03] border-white/[0.06] text-surface-400' : 'bg-white border-surface-200 text-surface-500'
        }`}>
          <Clock className="w-3.5 h-3.5" />
          {new Date().toLocaleString()}
        </div>
      </div>

      {/* Stats Grid - Responsive */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <StatCard3D
          icon={FolderOpen} label="Active Cases" value={displayStats.activeInvestigations}
          subtitle={`${displayStats.totalInvestigations} total`} color="brand"
          onClick={() => setCurrentPage('investigations')} delay={0}
        />
        <StatCard3D
          icon={Scan} label="Image Analyses" value={displayStats.imageAnalyses}
          subtitle="EXIF & metadata" color="success"
          onClick={() => setCurrentPage('image-analyzer')} delay={100}
        />
        <StatCard3D
          icon={Globe} label="URL Analyses" value={displayStats.urlAnalyses}
          subtitle="Domain intelligence" color="brand"
          onClick={() => setCurrentPage('url-analyzer')} delay={200}
        />
        <StatCard3D
          icon={AlertTriangle} label="Critical" value={displayStats.criticalFindings}
          subtitle="Requires attention" color="danger"
          onClick={() => setCurrentPage('evidence')} delay={300}
        />
      </div>

      {/* Main panels - 3 column on desktop, stack on mobile */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Risk Overview */}
        <div className="card-3d p-6 animate-card-enter" style={{ animationDelay: '0.1s' }}>
          <h2 className="section-title mb-5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isDark ? 'bg-brand-500/10' : 'bg-brand-50'}`}>
              <Shield className={`w-4 h-4 ${isDark ? 'text-brand-400' : 'text-brand-600'}`} />
            </div>
            Risk Overview
          </h2>
          <div className="flex flex-col items-center gap-5">
            <RiskGauge score={displayStats.averageRiskScore} level={riskLevel} />
            <div className="w-full space-y-3">
              <AnalysisBar label="Image Analysis" count={stats.imageAnalyses} max={Math.max(stats.imageAnalyses + stats.urlAnalyses + stats.contentAnalyses, 1)} color="bg-brand-500" />
              <AnalysisBar label="URL Analysis" count={stats.urlAnalyses} max={Math.max(stats.imageAnalyses + stats.urlAnalyses + stats.contentAnalyses, 1)} color="bg-success-500" />
              <AnalysisBar label="Content Analysis" count={stats.contentAnalyses} max={Math.max(stats.imageAnalyses + stats.urlAnalyses + stats.contentAnalyses, 1)} color="bg-warning-500" />
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="card-3d p-6 animate-card-enter" style={{ animationDelay: '0.2s' }}>
          <h2 className="section-title mb-5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isDark ? 'bg-brand-500/10' : 'bg-brand-50'}`}>
              <Zap className={`w-4 h-4 ${isDark ? 'text-brand-400' : 'text-brand-600'}`} />
            </div>
            Quick Actions
          </h2>
          <div className="space-y-2.5">
            <QuickAction icon={Scan} label="Analyze Image Metadata" desc="Extract EXIF, GPS, device data" onClick={() => setCurrentPage('image-analyzer')} />
            <QuickAction icon={Globe} label="Investigate URL" desc="WHOIS, SSL, DNS, reputation" onClick={() => setCurrentPage('url-analyzer')} />
            <QuickAction icon={FileText} label="Analyze Public Content" desc="Keywords, entities, sentiment" onClick={() => setCurrentPage('content-analyzer')} />
            <QuickAction icon={FileSearch} label="View Evidence Board" desc="Track and manage findings" onClick={() => setCurrentPage('evidence')} />
          </div>
        </div>

        {/* Intelligence Summary */}
        <div className="card-3d p-6 animate-card-enter" style={{ animationDelay: '0.3s' }}>
          <h2 className="section-title mb-5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isDark ? 'bg-brand-500/10' : 'bg-brand-50'}`}>
              <TrendingUp className={`w-4 h-4 ${isDark ? 'text-brand-400' : 'text-brand-600'}`} />
            </div>
            Intelligence Summary
          </h2>
          <div className="space-y-5">
            <InfoBlock title="Analysis Distribution" items={[
              { label: 'Image Metadata', value: stats.imageAnalyses, icon: Scan },
              { label: 'URL Intelligence', value: stats.urlAnalyses, icon: Globe },
              { label: 'Content Analysis', value: stats.contentAnalyses, icon: FileText },
            ]} />
            <InfoBlock title="Evidence & Findings" items={[
              { label: 'Total Evidence', value: stats.evidenceCount, icon: FileSearch },
              { label: 'Critical Findings', value: stats.criticalFindings, icon: AlertTriangle },
            ]} />
            <div className={`pt-4 border-t ${isDark ? 'border-white/[0.06]' : 'border-surface-100'}`}>
              <div className={`flex items-center gap-2 text-xs ${isDark ? 'text-surface-500' : 'text-surface-400'}`}>
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Ethical OSINT: Analyze only publicly available data</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <FeatureCard
          icon={Eye} title="Image Intelligence"
          desc="Deep EXIF parsing, GPS extraction, anomaly detection across JPEG, PNG, TIFF formats"
          color="brand" onClick={() => setCurrentPage('image-analyzer')}
        />
        <FeatureCard
          icon={Target} title="URL Threat Detection"
          desc="Phishing detection, typosquatting, brand impersonation, SSL/TLS analysis"
          color="danger" onClick={() => setCurrentPage('url-analyzer')}
        />
        <FeatureCard
          icon={Layers} title="NLP Content Analysis"
          desc="8 threat categories, 15+ pattern detectors, entity extraction, sentiment scoring"
          color="success" onClick={() => setCurrentPage('content-analyzer')}
        />
        <FeatureCard
          icon={BarChart3} title="Investigation Reports"
          desc="Risk distribution analytics, activity timeline, evidence tracking, text export"
          color="warning" onClick={() => setCurrentPage('reports')}
        />
      </div>
    </div>
  );
}

function StatCard3D({ icon: Icon, label, value, subtitle, color, onClick, delay }: any) {
  const { isDark } = useTheme();
  const colors: Record<string, { bg: string; icon: string; glow: string }> = {
    brand: {
      bg: isDark ? 'bg-brand-500/10' : 'bg-brand-50',
      icon: isDark ? 'text-brand-400' : 'text-brand-600',
      glow: isDark ? 'shadow-brand-500/20' : 'shadow-brand-500/10',
    },
    success: {
      bg: isDark ? 'bg-success-500/10' : 'bg-success-50',
      icon: isDark ? 'text-success-400' : 'text-success-600',
      glow: isDark ? 'shadow-success-500/20' : 'shadow-success-500/10',
    },
    danger: {
      bg: isDark ? 'bg-danger-500/10' : 'bg-danger-50',
      icon: isDark ? 'text-danger-400' : 'text-danger-600',
      glow: isDark ? 'shadow-danger-500/20' : 'shadow-danger-500/10',
    },
    warning: {
      bg: isDark ? 'bg-warning-500/10' : 'bg-warning-50',
      icon: isDark ? 'text-warning-400' : 'text-warning-600',
      glow: isDark ? 'shadow-warning-500/20' : 'shadow-warning-500/10',
    },
  };
  const c = colors[color] || colors.brand;

  return (
    <button
      onClick={onClick}
      className={`stat-card group cursor-pointer w-full text-left animate-card-enter`}
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center border transition-transform duration-300 group-hover:scale-110 ${c.bg} ${isDark ? 'border-white/[0.06]' : 'border-surface-200'}`}>
        <Icon className={`w-5 h-5 ${c.icon}`} />
      </div>
      <div className="flex-1 min-w-0">
        <p className={`text-xs font-medium ${isDark ? 'text-surface-400' : 'text-surface-500'}`}>{label}</p>
        <p className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-surface-900'}`}>{value}</p>
        <p className={`text-[11px] ${isDark ? 'text-surface-500' : 'text-surface-400'}`}>{subtitle}</p>
      </div>
      <ChevronRight className={`w-4 h-4 transition-colors ${isDark ? 'text-surface-600 group-hover:text-brand-400' : 'text-surface-300 group-hover:text-brand-500'}`} />
    </button>
  );
}

function QuickAction({ icon: Icon, label, desc, onClick }: any) {
  const { isDark } = useTheme();
  return (
    <button onClick={onClick} className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all duration-200 text-left group ${
      isDark ? 'bg-white/[0.02] hover:bg-brand-500/10 border-white/[0.04] hover:border-brand-500/20' : 'bg-surface-50 hover:bg-brand-50 border-surface-200 hover:border-brand-200'
    }`}>
      <Icon className={`w-4 h-4 transition-colors ${isDark ? 'text-surface-400 group-hover:text-brand-400' : 'text-surface-400 group-hover:text-brand-500'}`} />
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium transition-colors ${isDark ? 'text-surface-300 group-hover:text-brand-300' : 'text-surface-700 group-hover:text-brand-700'}`}>{label}</p>
        <p className={`text-[11px] ${isDark ? 'text-surface-500' : 'text-surface-400'}`}>{desc}</p>
      </div>
      <ChevronRight className={`w-3.5 h-3.5 transition-colors ${isDark ? 'text-surface-600 group-hover:text-brand-400' : 'text-surface-300 group-hover:text-brand-400'}`} />
    </button>
  );
}

function AnalysisBar({ label, count, max, color }: { label: string; count: number; max: number; color: string }) {
  const { isDark } = useTheme();
  const pct = max > 0 ? (count / max) * 100 : 0;
  return (
    <div>
      <div className={`flex justify-between text-xs mb-1 ${isDark ? 'text-surface-400' : 'text-surface-500'}`}>
        <span>{label}</span><span className="font-mono">{count}</span>
      </div>
      <div className={`h-2 rounded-full overflow-hidden ${isDark ? 'bg-white/[0.06]' : 'bg-surface-100'}`}>
        <div className={`h-full ${color} rounded-full transition-all duration-1000`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function InfoBlock({ title, items }: { title: string; items: { label: string; value: number; icon: any }[] }) {
  const { isDark } = useTheme();
  return (
    <div>
      <h3 className={`text-sm font-semibold mb-2 ${isDark ? 'text-surface-300' : 'text-surface-700'}`}>{title}</h3>
      <div className="space-y-2">
        {items.map(item => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="flex justify-between items-center text-xs">
              <span className={`flex items-center gap-1.5 ${isDark ? 'text-surface-500' : 'text-surface-500'}`}>
                <Icon className="w-3 h-3" />{item.label}
              </span>
              <span className={`font-mono font-semibold ${isDark ? 'text-surface-300' : 'text-surface-800'}`}>{item.value}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc, color, onClick }: any) {
  const { isDark } = useTheme();
  const colorMap: Record<string, { bg: string; text: string; border: string }> = {
    brand: {
      bg: isDark ? 'from-brand-600/20 to-brand-600/5' : 'from-brand-50 to-brand-100/50',
      text: isDark ? 'text-brand-400' : 'text-brand-600',
      border: isDark ? 'border-brand-500/20 hover:border-brand-500/40' : 'border-brand-200 hover:border-brand-300',
    },
    danger: {
      bg: isDark ? 'from-danger-600/20 to-danger-600/5' : 'from-danger-50 to-danger-100/50',
      text: isDark ? 'text-danger-400' : 'text-danger-600',
      border: isDark ? 'border-danger-500/20 hover:border-danger-500/40' : 'border-danger-200 hover:border-danger-300',
    },
    success: {
      bg: isDark ? 'from-success-600/20 to-success-600/5' : 'from-success-50 to-success-100/50',
      text: isDark ? 'text-success-400' : 'text-success-600',
      border: isDark ? 'border-success-500/20 hover:border-success-500/40' : 'border-success-200 hover:border-success-300',
    },
    warning: {
      bg: isDark ? 'from-warning-600/20 to-warning-600/5' : 'from-warning-50 to-warning-100/50',
      text: isDark ? 'text-warning-400' : 'text-warning-600',
      border: isDark ? 'border-warning-500/20 hover:border-warning-500/40' : 'border-warning-200 hover:border-warning-300',
    },
  };
  const c = colorMap[color] || colorMap.brand;

  return (
    <button
      onClick={onClick}
      className={`card-3d p-5 text-left bg-gradient-to-br ${c.bg} border ${c.border} animate-card-enter`}
    >
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${isDark ? 'bg-white/[0.06]' : 'bg-white/80'}`}>
        <Icon className={`w-5 h-5 ${c.text}`} />
      </div>
      <h3 className={`text-sm font-semibold mb-1 ${isDark ? 'text-white' : 'text-surface-900'}`}>{title}</h3>
      <p className={`text-xs leading-relaxed ${isDark ? 'text-surface-400' : 'text-surface-500'}`}>{desc}</p>
    </button>
  );
}
