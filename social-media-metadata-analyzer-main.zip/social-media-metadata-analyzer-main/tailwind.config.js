/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        brand: {
          50: '#eef5ff', 100: '#d9e8ff', 200: '#bcd7ff', 300: '#8ebeff',
          400: '#599bff', 500: '#3378ff', 600: '#1b59f5', 700: '#1445e1',
          800: '#1739b6', 900: '#19358f', 950: '#142257',
        },
        surface: {
          50: '#ffffff', 100: '#f8fafc', 200: '#f1f5f9', 300: '#e2e8f0',
          400: '#cbd5e1', 500: '#94a3b8', 600: '#64748b', 700: '#475569',
          800: '#334155', 900: '#1e293b', 950: '#0f172a',
        },
        danger: {
          50: '#fff1f2', 100: '#ffe4e6', 200: '#fecdd3', 300: '#fda4af',
          400: '#fb7185', 500: '#f43f5e', 600: '#e11d48', 700: '#be123c',
          800: '#9f1239', 900: '#881337', 950: '#4c0519',
        },
        success: {
          50: '#f0fdf4', 100: '#dcfce7', 200: '#bbf7d0', 300: '#86efac',
          400: '#4ade80', 500: '#22c55e', 600: '#16a34a', 700: '#15803d',
          800: '#166534', 900: '#14532d', 950: '#052e16',
        },
        warning: {
          50: '#fefce8', 100: '#fef9c3', 200: '#fef08a', 300: '#fde047',
          400: '#facc15', 500: '#eab308', 600: '#ca8a04', 700: '#a16207',
          800: '#854d0e', 900: '#713f12', 950: '#422006',
        },
        neon: {
          blue: '#3378ff',
          green: '#22c55e',
          red: '#f43f5e',
          yellow: '#eab308',
          purple: '#8b5cf6',
        },
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'slide-down': 'slideDown 0.3s ease-out',
        'float': 'float 6s ease-in-out infinite',
        'glow-pulse': 'glowPulse 2s ease-in-out infinite alternate',
        'card-enter': 'cardEnter 0.6s cubic-bezier(0.23, 1, 0.32, 1)',
        'spin-slow': 'spin 3s linear infinite',
        'counter': 'counter 1s ease-out forwards',
        'shimmer': 'shimmer 2s linear infinite',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        slideUp: { '0%': { opacity: '0', transform: 'translateY(20px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        slideDown: { '0%': { opacity: '0', transform: 'translateY(-10px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        float: { '0%, 100%': { transform: 'translateY(0px)' }, '50%': { transform: 'translateY(-8px)' } },
        glowPulse: { '0%': { boxShadow: '0 0 5px rgba(51,120,255,0.2), 0 0 20px rgba(51,120,255,0.1)' }, '100%': { boxShadow: '0 0 10px rgba(51,120,255,0.4), 0 0 40px rgba(51,120,255,0.2)' } },
        cardEnter: { '0%': { opacity: '0', transform: 'perspective(600px) rotateX(8deg) translateY(30px)' }, '100%': { opacity: '1', transform: 'perspective(600px) rotateX(0deg) translateY(0)' } },
        counter: { '0%': { opacity: '0', transform: 'scale(0.5)' }, '100%': { opacity: '1', transform: 'scale(1)' } },
        shimmer: { '0%': { backgroundPosition: '-200% 0' }, '100%': { backgroundPosition: '200% 0' } },
      },
      perspective: {
        '600': '600px',
        '800': '800px',
        '1000': '1000px',
      },
      transformOrigin: {
        'center-bottom': 'center bottom',
      },
    },
  },
  plugins: [],
};
