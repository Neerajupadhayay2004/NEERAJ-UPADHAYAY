# Profile Intelligence Tool - OSINT Analysis Platform

A comprehensive Open Source Intelligence (OSINT) tool for analyzing public social media profiles. This application ethically collects and analyzes publicly available information from multiple platforms to generate detailed intelligence reports.

![Profile Intelligence Tool](https://images.pexels.com/photo-1551288049-bebda4e38f71?auto=compress&cs=tinysrgb&w=1200)

## Features

- **Multi-Platform Search**: Search usernames across 7 major social media platforms
- **Intelligent Analysis**: Automated risk assessment and intelligence scoring
- **PDF Reports**: Professional, downloadable intelligence reports
- **JSON Export**: Raw data export for further analysis
- **Dashboard Analytics**: Visual statistics and trends
- **Investigation History**: Track and search past investigations

## Supported Platforms

- GitHub
- X (Twitter)
- Reddit
- Instagram (public only)
- TikTok (public only)
- YouTube
- Medium

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    PROFILE INTELLIGENCE TOOL                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌───────────────┐    ┌───────────────┐    ┌───────────────┐   │
│  │   Frontend    │    │   Backend     │    │   Database    │   │
│  │   (React)     │◄──►│   (FastAPI)   │◄──►│  (Supabase)   │   │
│  │               │    │               │    │               │   │
│  │  - Tailwind   │    │  - Platform   │    │  - Postgres   │   │
│  │  - TypeScript │    │    Detection  │    │  - RLS        │   │
│  │  - Recharts   │    │  - Risk       │    │               │   │
│  │               │    │    Analysis   │    │               │   │
│  │               │    │  - PDF Gen    │    │               │   │
│  └───────────────┘    └───────────────┘    └───────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Project Structure

```
project/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   └── routes/
│   │   │       ├── search.py      # Username search endpoints
│   │   │       ├── report.py      # Report retrieval endpoints
│   │   │       ├── export.py      # PDF/JSON export endpoints
│   │   │       └── history.py     # Investigation history
│   │   ├── core/
│   │   │   ├── config.py         # Application configuration
│   │   │   └── database.py       # Supabase connection
│   │   ├── models/
│   │   │   └── investigation.py  # Data models
│   │   ├── schemas/
│   │   │   └── investigation.py  # Pydantic schemas
│   │   ├── services/
│   │   │   ├── platform_detector.py  # Platform detection logic
│   │   │   ├── risk_analyzer.py      # Risk analysis engine
│   │   │   └── investigation.py      # Investigation orchestration
│   │   ├── pdf_generator/
│   │   │   └── report_generator.py   # PDF report creation
│   │   ├── utils/
│   │   └── main.py               # FastAPI application entry
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/           # Shared UI components
│   │   │   ├── dashboard/        # Dashboard widgets
│   │   │   ├── reports/          # Report components
│   │   │   └── search/           # Search components
│   │   ├── pages/
│   │   │   ├── SearchPage.tsx
│   │   │   ├── DashboardPage.tsx
│   │   │   ├── ReportPage.tsx
│   │   │   └── HistoryPage.tsx
│   │   ├── services/
│   │   │   └── api.ts            # API client
│   │   ├── types/
│   │   │   └── index.ts          # TypeScript types
│   │   ├── App.tsx
│   │   └── main.tsx
│   ├── index.html
│   ├── package.json
│   ├── tailwind.config.js
│   └── vite.config.ts
└── docs/
    ├── ARCHITECTURE.md
    └── API_REFERENCE.md
```

## Database Schema

### Tables

#### investigations
Stores each search/investigation session.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| username | VARCHAR(255) | Username searched |
| search_timestamp | TIMESTAMP | When search occurred |
| status | VARCHAR(50) | pending/in_progress/completed/failed |
| platforms_searched | TEXT[] | List of platforms searched |
| platforms_found | TEXT[] | Platforms where username was found |
| total_profiles | INTEGER | Number of profiles discovered |
| intelligence_score | INTEGER | Overall score (0-100) |
| risk_level | VARCHAR(20) | low/medium/high/critical |

#### profiles
Stores discovered profile information.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| investigation_id | UUID | Foreign key to investigations |
| platform | VARCHAR(100) | Platform name |
| username | VARCHAR(255) | Username on platform |
| display_name | VARCHAR(255) | Profile display name |
| bio | TEXT | Profile bio/description |
| followers_count | INTEGER | Number of followers |
| posts_count | INTEGER | Number of posts |

#### risk_indicators
Stores risk analysis results.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| investigation_id | UUID | Foreign key to investigations |
| indicator_type | VARCHAR(100) | Type of risk indicator |
| severity | VARCHAR(20) | low/medium/high/critical |
| description | TEXT | Risk description |
| evidence | JSONB | Supporting evidence |

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/search | Search username across platforms |
| GET | /api/report/{id} | Get full investigation report |
| GET | /api/report/{id}/summary | Get investigation summary |
| GET | /api/export/pdf/{id} | Download PDF report |
| GET | /api/export/json/{id} | Download JSON data |
| GET | /api/history | Get investigation history |
| GET | /api/history/search | Search history by username |
| GET | /api/history/stats | Get dashboard statistics |
| GET | /api/platforms | List supported platforms |

## Quick Start

### Prerequisites

- Node.js 18+
- Python 3.11+
- Supabase account (pre-configured)

### Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# Run the API server
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

### Environment Variables

The backend uses the following environment variables (pre-configured):

```env
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

## Risk Analysis

The tool analyzes several risk indicators:

### Username Patterns
- Long number sequences at end
- Suspicious keywords (temp, fake, spam, bot)
- Email patterns in username

### Account Characteristics
- New accounts (< 30 days old)
- Low activity relative to followers
- Excessive external links in profile
- Suspicious follower-to-post ratio

### Cross-Platform Analysis
- Username duplication across platforms
- Profile consistency checks

## Intelligence Scoring

Scores range from 0-100:

| Score Range | Risk Level | Description |
|-------------|------------|-------------|
| 0-20 | Low | Minimal risk indicators |
| 21-40 | Medium | Some concerning patterns |
| 41-60 | High | Multiple risk indicators |
| 61-100 | Critical | Significant concerns identified |

## Ethical Considerations

This tool is designed for legitimate OSINT purposes only:

- **Public Data Only**: Only accesses publicly available information
- **No Authentication Bypass**: Does not attempt to access private profiles
- **Rate Limiting**: Respects platform rate limits
- **No Data Storage Risk**: Does not collect passwords or private data
- **Legal Compliance**: Designed for ethical security research

### Use Cases

- Security research and threat intelligence
- Identity verification
- Brand monitoring
- Background checks (with consent)

## Security Features

- Row Level Security (RLS) on all database tables
- Input validation and sanitization
- Rate limiting support
- CORS configuration
- Structured logging

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests (if available)
5. Submit a pull request

## License

MIT License - See LICENSE file for details.

## Disclaimer

This tool is for educational and legitimate security research purposes only. Users are responsible for ensuring compliance with applicable laws and regulations. The developers do not condone any illegal use of this software.

---

**Built with**: FastAPI, React, Tailwind CSS, Supabase, ReportLab

**Author**: OSINT Intelligence Team
