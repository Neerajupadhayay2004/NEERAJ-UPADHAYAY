-- Profile Intelligence Tool Database Schema
-- OSINT investigation tables for public profile analysis

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Investigations table: stores each search/investigation session
CREATE TABLE investigations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(255) NOT NULL,
    search_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    status VARCHAR(50) DEFAULT 'pending',
    platforms_searched TEXT[] DEFAULT '{}',
    platforms_found TEXT[] DEFAULT '{}',
    total_profiles INTEGER DEFAULT 0,
    intelligence_score INTEGER DEFAULT 0,
    risk_level VARCHAR(20) DEFAULT 'low',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Profiles table: stores discovered profile information
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    investigation_id UUID REFERENCES investigations(id) ON DELETE CASCADE,
    platform VARCHAR(100) NOT NULL,
    platform_url VARCHAR(500),
    username VARCHAR(255) NOT NULL,
    display_name VARCHAR(255),
    bio TEXT,
    profile_picture_url VARCHAR(500),
    account_created_date DATE,
    followers_count INTEGER DEFAULT 0,
    following_count INTEGER DEFAULT 0,
    posts_count INTEGER DEFAULT 0,
    is_verified BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE,
    external_links TEXT[] DEFAULT '{}',
    last_activity_date TIMESTAMP WITH TIME ZONE,
    raw_metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Risk indicators table: stores risk analysis results
CREATE TABLE risk_indicators (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    investigation_id UUID REFERENCES investigations(id) ON DELETE CASCADE,
    profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    indicator_type VARCHAR(100) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    description TEXT NOT NULL,
    evidence JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Metadata history table: tracks changes in profile data over time
CREATE TABLE metadata_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    field_name VARCHAR(100) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    change_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX idx_investigations_username ON investigations(username);
CREATE INDEX idx_investigations_search_timestamp ON investigations(search_timestamp DESC);
CREATE INDEX idx_profiles_investigation_id ON profiles(investigation_id);
CREATE INDEX idx_profiles_platform ON profiles(platform);
CREATE INDEX idx_risk_indicators_investigation_id ON risk_indicators(investigation_id);
CREATE INDEX idx_metadata_history_profile_id ON metadata_history(profile_id);

-- Enable Row Level Security
ALTER TABLE investigations ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_indicators ENABLE ROW LEVEL SECURITY;
ALTER TABLE metadata_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for investigations table
CREATE POLICY "select_investigations_authenticated" ON investigations FOR SELECT
    TO authenticated USING (true);

CREATE POLICY "insert_investigations_authenticated" ON investigations FOR INSERT
    TO authenticated WITH CHECK (true);

CREATE POLICY "update_investigations_authenticated" ON investigations FOR UPDATE
    TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "delete_investigations_authenticated" ON investigations FOR DELETE
    TO authenticated USING (true);

-- RLS Policies for profiles table
CREATE POLICY "select_profiles_authenticated" ON profiles FOR SELECT
    TO authenticated USING (true);

CREATE POLICY "insert_profiles_authenticated" ON profiles FOR INSERT
    TO authenticated WITH CHECK (true);

CREATE POLICY "update_profiles_authenticated" ON profiles FOR UPDATE
    TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "delete_profiles_authenticated" ON profiles FOR DELETE
    TO authenticated USING (true);

-- RLS Policies for risk_indicators table
CREATE POLICY "select_risk_indicators_authenticated" ON risk_indicators FOR SELECT
    TO authenticated USING (true);

CREATE POLICY "insert_risk_indicators_authenticated" ON risk_indicators FOR INSERT
    TO authenticated WITH CHECK (true);

CREATE POLICY "delete_risk_indicators_authenticated" ON risk_indicators FOR DELETE
    TO authenticated USING (true);

-- RLS Policies for metadata_history table
CREATE POLICY "select_metadata_history_authenticated" ON metadata_history FOR SELECT
    TO authenticated USING (true);

CREATE POLICY "insert_metadata_history_authenticated" ON metadata_history FOR INSERT
    TO authenticated WITH CHECK (true);

-- Function to automatically update the updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_investigations_updated_at
    BEFORE UPDATE ON investigations
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();