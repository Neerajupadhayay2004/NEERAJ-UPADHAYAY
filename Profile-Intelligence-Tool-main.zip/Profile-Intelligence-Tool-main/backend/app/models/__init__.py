"""Models module initialization."""
from .investigation import Investigation, Profile, RiskIndicator

__all__ = ["Investigation", "Profile", "RiskIndicator"]
