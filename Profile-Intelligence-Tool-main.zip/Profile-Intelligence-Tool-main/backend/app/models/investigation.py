"""
Data models for database entities.
These represent the database tables directly.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime, date
from uuid import UUID


@dataclass
class Investigation:
    """Model for investigations table."""
    id: Optional[UUID] = None
    username: str = ""
    search_timestamp: Optional[datetime] = None
    status: str = "pending"
    platforms_searched: List[str] = field(default_factory=list)
    platforms_found: List[str] = field(default_factory=list)
    total_profiles: int = 0
    intelligence_score: int = 0
    risk_level: str = "low"
    notes: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Investigation":
        """Create Investigation instance from dictionary."""
        return cls(
            id=data.get("id"),
            username=data.get("username", ""),
            search_timestamp=data.get("search_timestamp"),
            status=data.get("status", "pending"),
            platforms_searched=data.get("platforms_searched", []),
            platforms_found=data.get("platforms_found", []),
            total_profiles=data.get("total_profiles", 0),
            intelligence_score=data.get("intelligence_score", 0),
            risk_level=data.get("risk_level", "low"),
            notes=data.get("notes"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert Investigation to dictionary."""
        return {
            "id": str(self.id) if self.id else None,
            "username": self.username,
            "search_timestamp": self.search_timestamp.isoformat() if self.search_timestamp else None,
            "status": self.status,
            "platforms_searched": self.platforms_searched,
            "platforms_found": self.platforms_found,
            "total_profiles": self.total_profiles,
            "intelligence_score": self.intelligence_score,
            "risk_level": self.risk_level,
            "notes": self.notes,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


@dataclass
class Profile:
    """Model for profiles table."""
    id: Optional[UUID] = None
    investigation_id: Optional[UUID] = None
    platform: str = ""
    platform_url: Optional[str] = None
    username: str = ""
    display_name: Optional[str] = None
    bio: Optional[str] = None
    profile_picture_url: Optional[str] = None
    account_created_date: Optional[date] = None
    followers_count: int = 0
    following_count: int = 0
    posts_count: int = 0
    is_verified: bool = False
    is_public: bool = True
    external_links: List[str] = field(default_factory=list)
    last_activity_date: Optional[datetime] = None
    raw_metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Profile":
        """Create Profile instance from dictionary."""
        return cls(
            id=data.get("id"),
            investigation_id=data.get("investigation_id"),
            platform=data.get("platform", ""),
            platform_url=data.get("platform_url"),
            username=data.get("username", ""),
            display_name=data.get("display_name"),
            bio=data.get("bio"),
            profile_picture_url=data.get("profile_picture_url"),
            account_created_date=data.get("account_created_date"),
            followers_count=data.get("followers_count", 0),
            following_count=data.get("following_count", 0),
            posts_count=data.get("posts_count", 0),
            is_verified=data.get("is_verified", False),
            is_public=data.get("is_public", True),
            external_links=data.get("external_links", []),
            last_activity_date=data.get("last_activity_date"),
            raw_metadata=data.get("raw_metadata", {}),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert Profile to dictionary."""
        return {
            "id": str(self.id) if self.id else None,
            "investigation_id": str(self.investigation_id) if self.investigation_id else None,
            "platform": self.platform,
            "platform_url": self.platform_url,
            "username": self.username,
            "display_name": self.display_name,
            "bio": self.bio,
            "profile_picture_url": self.profile_picture_url,
            "account_created_date": self.account_created_date.isoformat() if self.account_created_date else None,
            "followers_count": self.followers_count,
            "following_count": self.following_count,
            "posts_count": self.posts_count,
            "is_verified": self.is_verified,
            "is_public": self.is_public,
            "external_links": self.external_links,
            "last_activity_date": self.last_activity_date.isoformat() if self.last_activity_date else None,
            "raw_metadata": self.raw_metadata,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


@dataclass
class RiskIndicator:
    """Model for risk_indicators table."""
    id: Optional[UUID] = None
    investigation_id: Optional[UUID] = None
    profile_id: Optional[UUID] = None
    indicator_type: str = ""
    severity: str = "low"
    description: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RiskIndicator":
        """Create RiskIndicator instance from dictionary."""
        return cls(
            id=data.get("id"),
            investigation_id=data.get("investigation_id"),
            profile_id=data.get("profile_id"),
            indicator_type=data.get("indicator_type", ""),
            severity=data.get("severity", "low"),
            description=data.get("description", ""),
            evidence=data.get("evidence", {}),
            created_at=data.get("created_at"),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert RiskIndicator to dictionary."""
        return {
            "id": str(self.id) if self.id else None,
            "investigation_id": str(self.investigation_id) if self.investigation_id else None,
            "profile_id": str(self.profile_id) if self.profile_id else None,
            "indicator_type": self.indicator_type,
            "severity": self.severity,
            "description": self.description,
            "evidence": self.evidence,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
