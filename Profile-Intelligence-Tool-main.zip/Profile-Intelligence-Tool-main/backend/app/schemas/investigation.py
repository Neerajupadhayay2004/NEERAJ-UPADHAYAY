"""
Pydantic schemas for request/response validation.
Defines data models for the OSINT Profile Intelligence API.
"""

from pydantic import BaseModel, Field, HttpUrl
from typing import List, Optional, Dict, Any
from datetime import datetime, date
from uuid import UUID
from enum import Enum


class RiskLevel(str, Enum):
    """Risk level enumeration."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class InvestigationStatus(str, Enum):
    """Investigation status enumeration."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class Platform(str, Enum):
    """Supported social media platforms."""
    GITHUB = "github"
    TWITTER_X = "twitter_x"
    REDDIT = "reddit"
    INSTAGRAM = "instagram"
    TIKTOK = "tiktok"
    YOUTUBE = "youtube"
    MEDIUM = "medium"


# Request Schemas
class SearchRequest(BaseModel):
    """Schema for username search request."""
    username: str = Field(
        ...,
        min_length=1,
        max_length=255,
        description="Username to search across platforms"
    )
    platforms: Optional[List[Platform]] = Field(
        default=None,
        description="Specific platforms to search (optional, searches all if not provided)"
    )
    include_risk_analysis: bool = Field(
        default=True,
        description="Whether to perform risk analysis"
    )


# Response Schemas
class ProfileData(BaseModel):
    """Schema for profile data response."""
    id: Optional[UUID] = None
    platform: str
    platform_url: Optional[str] = None
    username: str
    display_name: Optional[str] = None
    bio: Optional[str] = None
    profile_picture_url: Optional[str] = None
    account_created_date: Optional[date] = None
    followers_count: int = 0
    following_count: int = 0
    posts_count: int = 0
    is_verified: bool = False
    is_public: bool = True
    external_links: List[str] = []
    last_activity_date: Optional[datetime] = None
    raw_metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None


class RiskIndicatorData(BaseModel):
    """Schema for risk indicator data."""
    id: Optional[UUID] = None
    indicator_type: str
    severity: RiskLevel
    description: str
    evidence: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None


class InvestigationSummary(BaseModel):
    """Schema for investigation summary."""
    id: UUID
    username: str
    search_timestamp: datetime
    status: InvestigationStatus
    platforms_searched: List[str] = []
    platforms_found: List[str] = []
    total_profiles: int = 0
    intelligence_score: int = Field(ge=0, le=100)
    risk_level: RiskLevel
    notes: Optional[str] = None


class InvestigationDetail(InvestigationSummary):
    """Schema for detailed investigation response."""
    profiles: List[ProfileData] = []
    risk_indicators: List[RiskIndicatorData] = []
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class SearchResponse(BaseModel):
    """Schema for search endpoint response."""
    investigation_id: UUID
    username: str
    status: InvestigationStatus
    message: str
    platforms_searching: List[str]


class ReportMetadata(BaseModel):
    """Schema for report metadata."""
    report_id: UUID
    investigation_id: UUID
    generated_at: datetime
    format: str
    file_size: Optional[int] = None


class ErrorResponse(BaseModel):
    """Schema for error responses."""
    error: str
    detail: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class PlatformStatus(BaseModel):
    """Schema for platform search status."""
    platform: str
    status: str
    found: bool = False
    profile_url: Optional[str] = None
    error: Optional[str] = None


class SearchProgress(BaseModel):
    """Schema for search progress updates."""
    investigation_id: UUID
    total_platforms: int
    completed_platforms: int
    current_platform: Optional[str] = None
    platform_statuses: List[PlatformStatus] = []
    progress_percentage: float = 0.0


# History Schemas
class HistoryItem(BaseModel):
    """Schema for single history item."""
    id: UUID
    username: str
    search_timestamp: datetime
    platforms_found: List[str] = []
    risk_level: RiskLevel
    intelligence_score: int


class HistoryResponse(BaseModel):
    """Schema for history endpoint response."""
    items: List[HistoryItem]
    total: int
    page: int
    page_size: int
    has_next: bool


# Export Schemas
class ExportRequest(BaseModel):
    """Schema for export request."""
    investigation_id: UUID
    format: str = Field(description="Export format: 'pdf' or 'json'")
    include_raw_data: bool = Field(
        default=False,
        description="Include raw metadata in export"
    )


class ExportResponse(BaseModel):
    """Schema for export response."""
    download_url: str
    filename: str
    format: str
    expires_at: Optional[datetime] = None
