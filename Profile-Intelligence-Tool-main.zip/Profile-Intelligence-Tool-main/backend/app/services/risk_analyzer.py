"""
Risk Analysis Service for OSINT.
Analyzes profile data to identify potential risk indicators.
"""

import re
from typing import List, Dict, Any, Optional
from datetime import datetime, date, timedelta
import structlog
from ..core.config import settings
from ..models import Profile, RiskIndicator

logger = structlog.get_logger()


class RiskAnalyzer:
    """Analyzes profiles for potential risk indicators."""

    # Suspicious username patterns
    SUSPICIOUS_PATTERNS = [
        r"[0-9]{6,}$",  # Long number sequences at end
        r"temp|fake|spam|bot|test",  # Suspicious keywords
        r"^[a-z]{1,3}[0-9]+$",  # Very short name with numbers
        r"gmail|yahoo|hotmail|outlook",  # Email patterns in username
    ]

    # Risk severity thresholds
    SEVERITY_THRESHOLDS = {
        "critical": 80,
        "high": 60,
        "medium": 40,
        "low": 20
    }

    def __init__(self):
        self.weights = {
            "new_account": settings.RISK_WEIGHT_NEW_ACCOUNT,
            "suspicious_pattern": settings.RISK_WEIGHT_SUSPICIOUS_PATTERN,
            "duplicate_username": settings.RISK_WEIGHT_DUPLICATE_USERNAME,
            "excessive_links": settings.RISK_WEIGHT_EXCESSIVE_LINKS,
            "low_activity": settings.RISK_WEIGHT_LOW_ACTIVITY,
        }

    def analyze_username_patterns(self, username: str) -> Dict[str, Any]:
        """Analyze username for suspicious patterns."""
        indicators = []

        for pattern in self.SUSPICIOUS_PATTERNS:
            if re.search(pattern, username, re.IGNORECASE):
                indicators.append({
                    "pattern": pattern,
                    "matched": True,
                    "description": f"Username matches suspicious pattern: {pattern}"
                })

        return {
            "has_suspicious_patterns": len(indicators) > 0,
            "patterns_found": indicators,
            "risk_count": len(indicators)
        }

    def check_new_account(self, created_date: Optional[date]) -> Dict[str, Any]:
        """Check if account is newly created (less than 30 days)."""
        if not created_date:
            return {"is_new": False, "days_old": None}

        days_old = (date.today() - created_date).days
        is_new = days_old < 30

        return {
            "is_new": is_new,
            "days_old": days_old,
            "threshold_days": 30
        }

    def check_duplicate_username(
        self,
        profiles: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Check if username appears on multiple platforms."""
        platforms_found = [p.get("platform") for p in profiles if p.get("username")]
        unique_platforms = len(platforms_found)
        duplicate_count = len(profiles) if len(profiles) > 1 else 0

        return {
            "is_duplicate_across_platforms": unique_platforms > 1,
            "platform_count": unique_platforms,
            "platforms": platforms_found
        }

    def check_excessive_links(
        self,
        external_links: List[str],
        bio: Optional[str] = None
    ) -> Dict[str, Any]:
        """Check for excessive external links which could indicate spam."""
        link_count = len(external_links)

        # Check for links in bio
        bio_links = []
        if bio:
            url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
            bio_links = re.findall(url_pattern, bio)

        total_links = link_count + len(bio_links)
        excessive_threshold = 5

        return {
            "is_excessive": total_links > excessive_threshold,
            "total_links": total_links,
            "profile_links": link_count,
            "bio_links": len(bio_links),
            "threshold": excessive_threshold
        }

    def check_low_activity(
        self,
        posts_count: int,
        followers_count: int,
        account_age_days: int
    ) -> Dict[str, Any]:
        """Check for suspiciously low activity patterns."""
        if account_age_days == 0:
            return {"is_low_activity": False, "score": 0}

        # Calculate average posts per month
        posts_per_month = (posts_count / max(account_age_days / 30, 1))

        # Calculate follower-to-post ratio if there are posts
        follower_ratio = followers_count / max(posts_count, 1)

        # Thresholds
        low_posts_threshold = 1  # Less than 1 post per month
        high_follower_ratio_threshold = 100  # Very high followers relative to posts

        is_low_activity = posts_per_month < low_posts_threshold
        suspicious_follower_ratio = follower_ratio > high_follower_ratio_threshold and followers_count > 100

        return {
            "is_low_activity": is_low_activity,
            "posts_per_month": posts_per_month,
            "follower_ratio": follower_ratio,
            "suspicious_follower_ratio": suspicious_follower_ratio
        }

    def calculate_intelligence_score(
        self,
        risk_indicators: List[Dict[str, Any]],
        profiles_count: int
    ) -> int:
        """
        Calculate overall intelligence score (0-100).
        Higher score means more confidence or more risk indicators found.
        """
        base_score = min(profiles_count * 10, 50)  # Max 50 points from profiles found

        risk_score = 0
        for indicator in risk_indicators:
            severity = indicator.get("severity", "low")
            weight = self.SEVERITY_THRESHOLDS.get(severity, 20)
            risk_score += weight * 0.5

        # Combine scores
        total_score = base_score + risk_score

        # Cap at 100
        return min(int(total_score), 100)

    def determine_risk_level(self, score: int) -> str:
        """Determine overall risk level based on score."""
        if score >= self.SEVERITY_THRESHOLDS["critical"]:
            return "critical"
        elif score >= self.SEVERITY_THRESHOLDS["high"]:
            return "high"
        elif score >= self.SEVERITY_THRESHOLDS["medium"]:
            return "medium"
        else:
            return "low"

    async def analyze_profiles(
        self,
        investigation_id: str,
        profiles: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Perform comprehensive risk analysis on detected profiles.
        Returns list of risk indicators.
        """
        risk_indicators = []
        username = profiles[0].get("username", "") if profiles else ""

        # Analyze username patterns
        username_analysis = self.analyze_username_patterns(username)
        if username_analysis["has_suspicious_patterns"]:
            for pattern_info in username_analysis["patterns_found"]:
                risk_indicators.append({
                    "investigation_id": investigation_id,
                    "indicator_type": "suspicious_username_pattern",
                    "severity": "medium",
                    "description": pattern_info["description"],
                    "evidence": pattern_info
                })

        # Analyze each profile
        for profile in profiles:
            # Check for new accounts
            created_date = profile.get("account_created_date")
            new_account_check = self.check_new_account(created_date)

            if new_account_check["is_new"]:
                risk_indicators.append({
                    "investigation_id": investigation_id,
                    "indicator_type": "new_account",
                    "severity": "medium",
                    "description": f"Account on {profile.get('platform')} is less than 30 days old ({new_account_check['days_old']} days)",
                    "evidence": new_account_check
                })

            # Check for excessive links
            links_check = self.check_excessive_links(
                profile.get("external_links", []),
                profile.get("bio")
            )

            if links_check["is_excessive"]:
                risk_indicators.append({
                    "investigation_id": investigation_id,
                    "indicator_type": "excessive_external_links",
                    "severity": "low",
                    "description": f"Profile on {profile.get('platform')} has {links_check['total_links']} external links",
                    "evidence": links_check
                })

            # Check for low activity (potential bot)
            account_age = 0
            if created_date:
                account_age = (date.today() - created_date).days

            activity_check = self.check_low_activity(
                profile.get("posts_count", 0),
                profile.get("followers_count", 0),
                account_age
            )

            if activity_check["is_low_activity"]:
                risk_indicators.append({
                    "investigation_id": investigation_id,
                    "indicator_type": "low_activity",
                    "severity": "low",
                    "description": f"Account on {profile.get('platform')} shows low activity: {activity_check['posts_per_month']:.1f} posts/month",
                    "evidence": activity_check
                })

            # Check for suspiciously high follower ratio
            if activity_check.get("suspicious_follower_ratio"):
                risk_indicators.append({
                    "investigation_id": investigation_id,
                    "indicator_type": "suspicious_follower_ratio",
                    "severity": "high",
                    "description": f"Account on {profile.get('platform')} has unusually high follower-to-post ratio: {activity_check['follower_ratio']:.1f}",
                    "evidence": activity_check
                })

        # Check for duplicate username across platforms
        duplicate_check = self.check_duplicate_username(profiles)
        if duplicate_check["is_duplicate_across_platforms"]:
            risk_indicators.append({
                "investigation_id": investigation_id,
                "indicator_type": "duplicate_username",
                "severity": "low",
                "description": f"Username found on {duplicate_check['platform_count']} platforms: {', '.join(duplicate_check['platforms'])}",
                "evidence": duplicate_check
            })

        logger.info(
            "risk_analysis_completed",
            investigation_id=investigation_id,
            indicators_count=len(risk_indicators)
        )

        return risk_indicators

    def get_summary_statistics(
        self,
        profiles: List[Dict[str, Any]],
        risk_indicators: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Generate summary statistics for the investigation."""
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}

        for indicator in risk_indicators:
            severity = indicator.get("severity", "low")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

        return {
            "total_profiles": len(profiles),
            "platforms_found": list(set(p.get("platform") for p in profiles)),
            "total_risk_indicators": len(risk_indicators),
            "severity_breakdown": severity_counts,
            "intelligence_score": self.calculate_intelligence_score(
                risk_indicators,
                len(profiles)
            )
        }
