"""Services module initialization."""
from .investigation import investigation_service
from .platform_detector import search_all_platforms, PlatformDetectorFactory
from .risk_analyzer import RiskAnalyzer

__all__ = [
    "investigation_service",
    "search_all_platforms",
    "PlatformDetectorFactory",
    "RiskAnalyzer",
]
