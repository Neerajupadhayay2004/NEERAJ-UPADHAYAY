"""
Investigation Service.
Main orchestrator for OSINT investigation workflow.
"""

import asyncio
from typing import List, Dict, Any, Optional
from uuid import UUID
import structlog
from ..core.database import db
from ..core.config import settings
from .platform_detector import search_all_platforms
from .risk_analyzer import RiskAnalyzer
from ..models import Investigation, Profile, RiskIndicator

logger = structlog.get_logger()


class InvestigationService:
    """Service for managing investigations."""

    def __init__(self):
        self.risk_analyzer = RiskAnalyzer()

    async def create_and_run_investigation(
        self,
        username: str,
        platforms: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Create a new investigation and run platform searches.

        Args:
            username: Username to investigate
            platforms: Optional list of specific platforms to search

        Returns:
            Investigation data with all discovered profiles and risk analysis
        """
        logger.info("starting_investigation", username=username)

        # Determine platforms to search
        search_platforms = platforms or settings.SUPPORTED_PLATFORMS

        # Create investigation record
        investigation = await db.create_investigation(
            username=username,
            platforms_searched=search_platforms
        )

        investigation_id = str(investigation.get("id"))

        try:
            # Update status to in_progress
            await db.update_investigation(
                investigation_id,
                {"status": "in_progress"}
            )

            # Search platforms concurrently
            logger.info("searching_platforms", platforms=search_platforms)
            discovered_profiles = await search_all_platforms(
                username=username,
                platforms=search_platforms
            )

            logger.info(
                "profiles_discovered",
                count=len(discovered_profiles),
                platforms=[p.get("platform") for p in discovered_profiles]
            )

            # Save profiles to database
            saved_profiles = []
            for profile_data in discovered_profiles:
                profile_data["investigation_id"] = investigation_id
                saved_profile = await db.create_profile(profile_data)
                if saved_profile:
                    saved_profiles.append(saved_profile)

            # Perform risk analysis
            risk_indicators = await self.risk_analyzer.analyze_profiles(
                investigation_id,
                discovered_profiles
            )

            # Save risk indicators
            saved_indicators = []
            for indicator_data in risk_indicators:
                saved_indicator = await db.create_risk_indicator(indicator_data)
                if saved_indicator:
                    saved_indicators.append(saved_indicator)

            # Calculate intelligence score
            summary = self.risk_analyzer.get_summary_statistics(
                discovered_profiles,
                risk_indicators
            )

            intelligence_score = summary["intelligence_score"]
            risk_level = self.risk_analyzer.determine_risk_level(intelligence_score)

            # Update investigation with final results
            await db.update_investigation(
                investigation_id,
                {
                    "status": "completed",
                    "platforms_found": summary["platforms_found"],
                    "total_profiles": summary["total_profiles"],
                    "intelligence_score": intelligence_score,
                    "risk_level": risk_level
                }
            )

            # Return complete investigation data
            return {
                "id": investigation_id,
                "username": username,
                "search_timestamp": investigation.get("search_timestamp"),
                "status": "completed",
                "platforms_searched": search_platforms,
                "platforms_found": summary["platforms_found"],
                "total_profiles": summary["total_profiles"],
                "intelligence_score": intelligence_score,
                "risk_level": risk_level,
                "profiles": saved_profiles,
                "risk_indicators": saved_indicators,
                "summary": summary
            }

        except Exception as e:
            logger.error("investigation_failed", error=str(e))
            await db.update_investigation(
                investigation_id,
                {"status": "failed", "notes": str(e)}
            )
            raise

    async def get_investigation(self, investigation_id: str) -> Dict[str, Any]:
        """Retrieve complete investigation data with profiles and risk indicators."""
        investigation = await db.get_investigation(investigation_id)

        if not investigation:
            return None

        profiles = await db.get_profiles_by_investigation(investigation_id)
        risk_indicators = await db.get_risk_indicators(investigation_id)

        return {
            **investigation,
            "profiles": profiles,
            "risk_indicators": risk_indicators
        }

    async def get_history(
        self,
        limit: int = 50,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Retrieve investigation history with pagination."""
        items = await db.get_investigation_history(limit=limit, offset=offset)

        return {
            "items": items,
            "total": len(items),
            "page": offset // limit + 1,
            "page_size": limit,
            "has_next": len(items) == limit
        }

    async def search_by_username(self, username: str) -> List[Dict[str, Any]]:
        """Search previous investigations by username."""
        return await db.search_investigations_by_username(username)


investigation_service = InvestigationService()
