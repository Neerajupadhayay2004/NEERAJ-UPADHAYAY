"""
Platform detection service for OSINT.
Handles searching usernames across social media platforms using public APIs.
"""

import httpx
import asyncio
import re
from typing import Dict, Any, Optional, List
from datetime import datetime, date
from bs4 import BeautifulSoup
import structlog
from ..core.config import settings

logger = structlog.get_logger()


class BasePlatformDetector:
    """Base class for platform-specific detectors."""

    def __init__(self):
        self.timeout = settings.SEARCH_TIMEOUT
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

    async def fetch_url(self, url: str) -> Optional[str]:
        """Fetch URL content with error handling."""
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=self.headers, follow_redirects=True)
                if response.status_code == 200:
                    return response.text
                return None
        except Exception as e:
            logger.debug("fetch_failed", url=url, error=str(e))
            return None

    async def fetch_json(self, url: str) -> Optional[Dict]:
        """Fetch JSON response from URL."""
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=self.headers, follow_redirects=True)
                if response.status_code == 200:
                    return response.json()
                return None
        except Exception as e:
            logger.debug("json_fetch_failed", url=url, error=str(e))
            return None

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check if profile exists on this platform. Override in subclasses."""
        raise NotImplementedError

    def calculate_account_age_days(self, created_date: date) -> int:
        """Calculate account age in days."""
        if created_date:
            return (date.today() - created_date).days
        return 0


class GitHubDetector(BasePlatformDetector):
    """GitHub profile detector using public API."""

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check GitHub profile using public API."""
        api_url = f"https://api.github.com/users/{username}"

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, headers=self.headers)
                if response.status_code == 200:
                    data = response.json()

                    return {
                        "platform": "github",
                        "platform_url": data.get("html_url", ""),
                        "username": username,
                        "display_name": data.get("name"),
                        "bio": data.get("bio"),
                        "profile_picture_url": data.get("avatar_url"),
                        "account_created_date": datetime.strptime(
                            data.get("created_at", "2020-01-01T00:00:00Z"),
                            "%Y-%m-%dT%H:%M:%SZ"
                        ).date() if data.get("created_at") else None,
                        "followers_count": data.get("followers", 0),
                        "following_count": data.get("following", 0),
                        "posts_count": data.get("public_repos", 0),
                        "is_public": True,
                        "external_links": [data.get("blog")] if data.get("blog") else [],
                        "is_verified": False,
                        "raw_metadata": data
                    }
                return None
        except Exception as e:
            logger.error("github_detect_failed", error=str(e))
            return None


class RedditDetector(BasePlatformDetector):
    """Reddit profile detector."""

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check Reddit profile using public API."""
        api_url = f"https://www.reddit.com/user/{username}/about.json"

        self.headers["User-Agent"] = "OSINT-Profile-Tool/1.0"

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, headers=self.headers)
                if response.status_code == 200:
                    data = response.json()
                    if data.get("kind") == "t2":
                        user_data = data.get("data", {})

                        created_timestamp = user_data.get("created_utc", 0)

                        return {
                            "platform": "reddit",
                            "platform_url": f"https://www.reddit.com/user/{username}",
                            "username": username,
                            "display_name": user_data.get("subreddit", {}).get("display_name_prefixed", username),
                            "bio": user_data.get("subreddit", {}).get("public_description"),
                            "profile_picture_url": None,
                            "account_created_date": datetime.utcfromtimestamp(created_timestamp).date() if created_timestamp else None,
                            "followers_count": 0,
                            "following_count": 0,
                            "posts_count": user_data.get("link_karma", 0) + user_data.get("comment_karma", 0),
                            "is_public": True,
                            "external_links": [],
                            "is_verified": user_data.get("verified", False),
                            "raw_metadata": data
                        }
                return None
        except Exception as e:
            logger.error("reddit_detect_failed", error=str(e))
            return None


class TwitterXDetector(BasePlatformDetector):
    """Twitter/X profile detector - limited public access."""

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check Twitter/X profile via public page scraping."""
        url = f"https://x.com/{username}"

        # Note: Twitter has strict rate limits and may block automated requests
        # This is a simplified check that may not always work
        html_content = await self.fetch_url(url)

        if html_content and "This account doesn't exist" not in html_content:
            # Basic metadata extraction (limited due to SPA)
            return {
                "platform": "twitter_x",
                "platform_url": url,
                "username": username,
                "display_name": None,
                "bio": None,
                "profile_picture_url": None,
                "account_created_date": None,
                "followers_count": 0,
                "following_count": 0,
                "posts_count": 0,
                "is_public": True,
                "external_links": [],
                "is_verified": False,
                "raw_metadata": {"status": "profile_exists_but_metadata_limited"}
            }
        return None


class MediumDetector(BasePlatformDetector):
    """Medium profile detector."""

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check Medium profile via public page."""
        url = f"https://medium.com/@{username}"

        html_content = await self.fetch_url(url)

        if html_content:
            soup = BeautifulSoup(html_content, 'lxml')

            # Try to extract metadata from the page
            display_name = None
            bio = None

            # Extract from meta tags or JSON-LD
            title_tag = soup.find('title')
            if title_tag and "@" in title_tag.text:
                display_name = title_tag.text.split("@")[0].strip()

            meta_desc = soup.find('meta', {'name': 'description'})
            if meta_desc:
                bio = meta_desc.get('content')

            return {
                "platform": "medium",
                "platform_url": url,
                "username": username,
                "display_name": display_name,
                "bio": bio,
                "profile_picture_url": None,
                "account_created_date": None,
                "followers_count": 0,
                "following_count": 0,
                "posts_count": 0,
                "is_public": True,
                "external_links": [],
                "is_verified": False,
                "raw_metadata": {"html_parsed": True}
            }
        return None


class YouTubeDetector(BasePlatformDetector):
    """YouTube channel detector."""

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check YouTube channel."""
        # YouTube channels can have custom URLs or channel IDs
        possible_urls = [
            f"https://www.youtube.com/@{username}",
            f"https://www.youtube.com/c/{username}",
            f"https://www.youtube.com/user/{username}"
        ]

        for url in possible_urls:
            html_content = await self.fetch_url(url)

            if html_content and "This page isn't available" not in html_content:
                soup = BeautifulSoup(html_content, 'lxml')

                display_name = None
                subscribers = 0

                title_tag = soup.find('title')
                if title_tag:
                    display_name = title_tag.text.replace(" - YouTube", "").strip()

                return {
                    "platform": "youtube",
                    "platform_url": url,
                    "username": username,
                    "display_name": display_name,
                    "bio": None,
                    "profile_picture_url": None,
                    "account_created_date": None,
                    "followers_count": subscribers,
                    "following_count": 0,
                    "posts_count": 0,
                    "is_public": True,
                    "external_links": [],
                    "is_verified": False,
                    "raw_metadata": {"html_parsed": True, "url_pattern": url}
                }
        return None


class InstagramDetector(BasePlatformDetector):
    """Instagram profile detector - limited public access without API."""

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check Instagram profile via public page."""
        url = f"https://www.instagram.com/{username}/"

        html_content = await self.fetch_url(url)

        if html_content and "Sorry, this page isn't available" not in html_content:
            # Instagram requires login for most metadata
            # This is a basic existence check
            return {
                "platform": "instagram",
                "platform_url": url,
                "username": username,
                "display_name": None,
                "bio": None,
                "profile_picture_url": None,
                "account_created_date": None,
                "followers_count": 0,
                "following_count": 0,
                "posts_count": 0,
                "is_public": True,
                "external_links": [],
                "is_verified": False,
                "raw_metadata": {"status": "profile_exists_but_requires_login_for_details"}
            }
        return None


class TikTokDetector(BasePlatformDetector):
    """TikTok profile detector."""

    async def check_profile_exists(self, username: str) -> Optional[Dict[str, Any]]:
        """Check TikTok profile via public page."""
        url = f"https://www.tiktok.com/@{username}"

        html_content = await self.fetch_url(url)

        if html_content and "Couldn't find this account" not in html_content:
            soup = BeautifulSoup(html_content, 'lxml')

            display_name = None
            followers = 0

            title_tag = soup.find('title')
            if title_tag:
                display_name = title_tag.text.strip()

            return {
                "platform": "tiktok",
                "platform_url": url,
                "username": username,
                "display_name": display_name,
                "bio": None,
                "profile_picture_url": None,
                "account_created_date": None,
                "followers_count": followers,
                "following_count": 0,
                "posts_count": 0,
                "is_public": True,
                "external_links": [],
                "is_verified": False,
                "raw_metadata": {"html_parsed": True}
            }
        return None


class PlatformDetectorFactory:
    """Factory for creating platform-specific detectors."""

    detectors = {
        "github": GitHubDetector,
        "twitter_x": TwitterXDetector,
        "reddit": RedditDetector,
        "instagram": InstagramDetector,
        "tiktok": TikTokDetector,
        "youtube": YouTubeDetector,
        "medium": MediumDetector,
    }

    @classmethod
    def get_detector(cls, platform: str) -> Optional[BasePlatformDetector]:
        """Get detector instance for a platform."""
        detector_class = cls.detectors.get(platform)
        if detector_class:
            return detector_class()
        return None

    @classmethod
    def get_supported_platforms(cls) -> List[str]:
        """Get list of supported platforms."""
        return list(cls.detectors.keys())


async def search_all_platforms(
    username: str,
    platforms: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """Search username across all or specified platforms concurrently."""

    search_platforms = platforms or PlatformDetectorFactory.get_supported_platforms()
    results = []

    tasks = []
    for platform in search_platforms:
        detector = PlatformDetectorFactory.get_detector(platform)
        if detector:
            tasks.append(detector.check_profile_exists(username))

    # Execute searches concurrently
    detection_results = await asyncio.gather(*tasks, return_exceptions=True)

    for platform, result in zip(search_platforms, detection_results):
        if isinstance(result, Exception):
            logger.error("platform_search_error", platform=platform, error=str(result))
        elif result:
            results.append(result)

    return results
