"""
PDF Report Generation Module.
Creates professional intelligence reports in PDF format.
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, HRFlowable, ListFlowable, ListItem
)
from reportlab.graphics.shapes import Drawing, Line, Rect
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.lib.utils import ImageReader
from typing import Dict, Any, List, Optional
from datetime import datetime, date
import io
import structlog
from PIL import Image as PILImage

logger = structlog.get_logger()


class IntelligenceReportGenerator:
    """Generates PDF intelligence reports."""

    # Color scheme for cybersecurity theme
    COLORS = {
        "primary": colors.Color(0.1, 0.3, 0.5),  # Dark blue
        "secondary": colors.Color(0.2, 0.6, 0.8),  # Light blue
        "accent": colors.Color(0.9, 0.4, 0.1),  # Orange
        "critical": colors.red,
        "high": colors.Color(0.8, 0.2, 0.2),  # Dark red
        "medium": colors.Color(0.9, 0.6, 0.1),  # Orange
        "low": colors.Color(0.2, 0.7, 0.3),  # Green
        "background": colors.Color(0.95, 0.95, 0.95),  # Light gray
        "text": colors.Color(0.1, 0.1, 0.1),  # Dark gray
    }

    def __init__(self):
        self.page_size = letter
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()

    def _setup_custom_styles(self):
        """Configure custom paragraph styles for the report."""
        # Title style
        self.styles.add(ParagraphStyle(
            'ReportTitle',
            parent=self.styles['Heading1'],
            fontSize=28,
            textColor=self.COLORS['primary'],
            alignment=TA_CENTER,
            spaceAfter=20,
            fontName='Helvetica-Bold'
        ))

        # Section header style
        self.styles.add(ParagraphStyle(
            'SectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=self.COLORS['primary'],
            spaceBefore=15,
            spaceAfter=10,
            fontName='Helvetica-Bold',
            borderPadding=5,
            borderWidth=0,
            borderColor=self.COLORS['secondary']
        ))

        # Subsection style
        self.styles.add(ParagraphStyle(
            'SubSection',
            parent=self.styles['Heading3'],
            fontSize=12,
            textColor=self.COLORS['secondary'],
            spaceBefore=10,
            spaceAfter=5,
            fontName='Helvetica-Bold'
        ))

        # Body text style
        self.styles.add(ParagraphStyle(
            'BodyText',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=self.COLORS['text'],
            alignment=TA_JUSTIFY,
            spaceBefore=5,
            spaceAfter=5,
            leading=14,
            fontName='Helvetica'
        ))

        # Metadata style
        self.styles.add(ParagraphStyle(
            'MetaText',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.gray,
            alignment=TA_LEFT,
            fontName='Helvetica-Oblique'
        ))

        # Risk indicator style
        self.styles.add(ParagraphStyle(
            'RiskText',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=self.COLORS['text'],
            spaceBefore=3,
            spaceAfter=3,
            leftIndent=20,
            fontName='Helvetica'
        ))

    def _create_header(self) -> List:
        """Create the report header section."""
        elements = []

        # Report title
        title = Paragraph(
            "PROFILE INTELLIGENCE REPORT",
            self.styles['ReportTitle']
        )
        elements.append(title)

        # Subtitle with classification
        subtitle = Paragraph(
            "<b>CLASSIFICATION:</b> OPEN SOURCE INTELLIGENCE (OSINT) - PUBLIC DATA ONLY",
            self.styles['MetaText']
        )
        elements.append(subtitle)

        # Horizontal divider
        elements.append(HRFlowable(
            width="100%",
            thickness=2,
            color=self.COLORS['primary'],
            spaceBefore=10,
            spaceAfter=20
        ))

        return elements

    def _create_investigation_summary(
        self,
        investigation: Dict[str, Any]
    ) -> List:
        """Create investigation summary section."""
        elements = []

        elements.append(Paragraph("Investigation Summary", self.styles['SectionHeader']))

        # Summary table
        summary_data = [
            ["Investigation ID", str(investigation.get("id", "N/A"))],
            ["Username Investigated", investigation.get("username", "N/A")],
            ["Investigation Date", self._format_datetime(investigation.get("search_timestamp"))],
            ["Status", investigation.get("status", "N/A").upper()],
            ["Intelligence Score", f"{investigation.get('intelligence_score', 0)}/100"],
            ["Risk Level", investigation.get("risk_level", "low").upper()],
            ["Platforms Found", str(len(investigation.get("platforms_found", [])))],
            ["Total Profiles", str(investigation.get("total_profiles", 0))],
        ]

        table = Table(summary_data, colWidths=[2.5*inch, 4*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), self.COLORS['background']),
            ('TEXTCOLOR', (0, 0), (0, -1), self.COLORS['primary']),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.gray),
            ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.white, self.COLORS['background']]),
            ('LEFTPADDING', (0, 0), (-1, -1), 10),
            ('RIGHTPADDING', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 20))

        return elements

    def _create_platform_presence(
        self,
        profiles: List[Dict[str, Any]]
    ) -> List:
        """Create platform presence section."""
        elements = []

        elements.append(Paragraph("Platform Presence Analysis", self.styles['SectionHeader']))

        if not profiles:
            elements.append(Paragraph(
                "No profiles were found across searched platforms.",
                self.styles['BodyText']
            ))
            return elements

        # Platform presence table
        platform_data = [["Platform", "Username", "Display Name", "Followers", "Posts", "Status"]]

        for profile in profiles:
            status = "Verified" if profile.get("is_verified") else "Public"
            platform_data.append([
                profile.get("platform", "Unknown").upper(),
                profile.get("username", "N/A"),
                profile.get("display_name", "N/A") or "N/A",
                self._format_number(profile.get("followers_count", 0)),
                self._format_number(profile.get("posts_count", 0)),
                status
            ])

        table = Table(platform_data, colWidths=[1.2*inch, 1.5*inch, 1.5*inch, 1*inch, 1*inch, 1*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), self.COLORS['primary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (3, 1), (4, -1), 'RIGHT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.gray),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, self.COLORS['background']]),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('RIGHTPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 20))

        return elements

    def _create_profile_details(
        self,
        profiles: List[Dict[str, Any]]
    ) -> List:
        """Create detailed profile information section."""
        elements = []

        elements.append(Paragraph("Profile Details", self.styles['SectionHeader']))

        for profile in profiles:
            # Profile header
            platform_name = profile.get("platform", "Unknown").replace("_", " ").upper()
            elements.append(Paragraph(
                f"{platform_name}",
                self.styles['SubSection']
            ))

            # Profile URL
            profile_url = profile.get("platform_url", "")
            if profile_url:
                elements.append(Paragraph(
                    f"<b>URL:</b> {profile_url}",
                    self.styles['BodyText']
                ))

            # Bio
            bio = profile.get("bio")
            if bio:
                elements.append(Paragraph(
                    f"<b>Bio:</b> {bio[:200]}{'...' if len(bio) > 200 else ''}",
                    self.styles['BodyText']
                ))

            # Account age
            created_date = profile.get("account_created_date")
            if created_date:
                elements.append(Paragraph(
                    f"<b>Account Created:</b> {created_date}",
                    self.styles['BodyText']
                ))

            # Stats
            stats = []
            if profile.get("followers_count"):
                stats.append(f"Followers: {self._format_number(profile['followers_count'])}")
            if profile.get("following_count"):
                stats.append(f"Following: {self._format_number(profile['following_count'])}")
            if profile.get("posts_count"):
                stats.append(f"Posts: {self._format_number(profile['posts_count'])}")

            if stats:
                elements.append(Paragraph(
                    f"<b>Statistics:</b> {' | '.join(stats)}",
                    self.styles['BodyText']
                ))

            # External links
            external_links = profile.get("external_links", [])
            if external_links:
                elements.append(Paragraph(
                    f"<b>External Links:</b> {', '.join(external_links[:5])}",
                    self.styles['BodyText']
                ))

            elements.append(Spacer(1, 15))

        return elements

    def _create_risk_analysis(
        self,
        risk_indicators: List[Dict[str, Any]],
        risk_level: str
    ) -> List:
        """Create risk analysis section."""
        elements = []

        elements.append(Paragraph("Risk Analysis", self.styles['SectionHeader']))

        if not risk_indicators:
            elements.append(Paragraph(
                "No significant risk indicators were identified during this investigation.",
                self.styles['BodyText']
            ))
            return elements

        # Risk overview
        risk_color = self._get_risk_color(risk_level)
        elements.append(Paragraph(
            f"<b>Overall Risk Assessment:</b> <font color=\"{self._get_hex_color(risk_color)}\">{risk_level.upper()}</font>",
            self.styles['BodyText']
        ))
        elements.append(Spacer(1, 10))

        # Risk indicators table
        risk_data = [["Indicator Type", "Severity", "Description"]]

        for indicator in risk_indicators:
            risk_data.append([
                indicator.get("indicator_type", "N/A").replace("_", " ").upper(),
                indicator.get("severity", "low").upper(),
                indicator.get("description", "N/A")[:100]
            ])

        table = Table(risk_data, colWidths=[2*inch, 1*inch, 3.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), self.COLORS['primary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.gray),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, self.COLORS['background']]),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('RIGHTPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 20))

        return elements

    def _create_intelligence_summary(
        self,
        investigation: Dict[str, Any],
        profiles: List[Dict[str, Any]],
        risk_indicators: List[Dict[str, Any]]
    ) -> List:
        """Create intelligence summary section."""
        elements = []

        elements.append(Paragraph("Intelligence Summary", self.styles['SectionHeader']))

        score = investigation.get("intelligence_score", 0)
        risk_level = investigation.get("risk_level", "low")

        # Summary text
        summary_lines = [
            f"This investigation analyzed the username <b>'{investigation.get('username', 'N/A')}'</b> "
            f"across {len(investigation.get('platforms_searched', []))} social media platforms.",
            f"Profiles were discovered on {len(profiles)} platform(s).",
            f"The investigation identified {len(risk_indicators)} risk indicator(s) with an overall risk assessment of <b>{risk_level.upper()}</b>.",
            f"The intelligence score of <b>{score}/100</b> reflects the depth of information gathered and risk factors identified."
        ]

        for line in summary_lines:
            elements.append(Paragraph(line, self.styles['BodyText']))
            elements.append(Spacer(1, 5))

        # Recommendations based on risk level
        elements.append(Spacer(1, 10))
        elements.append(Paragraph("Recommendations:", self.styles['SubSection']))

        if risk_level == "critical":
            recommendations = [
                "Immediate review of this profile is recommended.",
                "Consider manual verification of profile authenticity.",
                "Report suspicious activity to relevant platform administrators if applicable."
            ]
        elif risk_level == "high":
            recommendations = [
                "Further investigation is recommended.",
                "Verify profile information through alternative sources.",
                "Monitor for future activity if ongoing concern exists."
            ]
        elif risk_level == "medium":
            recommendations = [
                "Continue routine monitoring.",
                "Document findings for future reference.",
                "Consider additional verification if interactions are planned."
            ]
        else:
            recommendations = [
                "No immediate action required.",
                "Standard monitoring recommended.",
                "Document for record-keeping purposes."
            ]

        for rec in recommendations:
            elements.append(Paragraph(
                f"<bullet>&bull;</bullet> {rec}",
                self.styles['BodyText']
            ))

        return elements

    def _create_footer_section(self) -> List:
        """Create report footer."""
        elements = []

        elements.append(Spacer(1, 30))
        elements.append(HRFlowable(
            width="100%",
            thickness=1,
            color=colors.gray,
            spaceBefore=10,
            spaceAfter=10
        ))

        # Disclaimer
        disclaimer = """
        <b>DISCLAIMER:</b> This report was generated using publicly available information from open sources.
        All data collected complies with ethical OSINT practices and does not involve unauthorized access
        or hacking. The information presented is accurate to the best of our knowledge at the time of
        collection but may change. This report is for informational purposes only.
        """
        elements.append(Paragraph(disclaimer, self.styles['MetaText']))

        # Footer info
        elements.append(Spacer(1, 10))
        elements.append(Paragraph(
            f"Report Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}",
            self.styles['MetaText']
        ))
        elements.append(Paragraph(
            "Profile Intelligence Tool v1.0.0 | OSINT Analysis Platform",
            self.styles['MetaText']
        ))

        return elements

    def _get_risk_color(self, risk_level: str) -> colors.Color:
        """Get color for risk level."""
        color_map = {
            "critical": self.COLORS['critical'],
            "high": self.COLORS['high'],
            "medium": self.COLORS['medium'],
            "low": self.COLORS['low']
        }
        return color_map.get(risk_level.lower(), self.COLORS['low'])

    def _get_hex_color(self, color: colors.Color) -> str:
        """Convert color to hex string."""
        return f"#{int(color.red*255):02x}{int(color.green*255):02x}{int(color.blue*255):02x}"

    def _format_datetime(self, dt) -> str:
        """Format datetime for display."""
        if not dt:
            return "N/A"
        if isinstance(dt, str):
            try:
                dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))
                return dt.strftime('%Y-%m-%d %H:%M:%S UTC')
            except:
                return dt
        return dt.strftime('%Y-%m-%d %H:%M:%S UTC')

    def _format_number(self, num: int) -> str:
        """Format numbers with K/M suffix."""
        if num >= 1000000:
            return f"{num/1000000:.1f}M"
        elif num >= 1000:
            return f"{num/1000:.1f}K"
        return str(num)

    def generate_report(
        self,
        investigation: Dict[str, Any],
        profiles: List[Dict[str, Any]],
        risk_indicators: List[Dict[str, Any]],
        output_buffer: Optional[io.BytesIO] = None
    ) -> io.BytesIO:
        """
        Generate a complete PDF report.

        Args:
            investigation: Investigation data
            profiles: List of discovered profiles
            risk_indicators: List of risk indicators
            output_buffer: Optional buffer to write to

        Returns:
            BytesIO buffer containing the PDF
        """
        buffer = output_buffer or io.BytesIO()

        doc = SimpleDocTemplate(
            buffer,
            pagesize=self.page_size,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=0.75*inch,
            bottomMargin=0.75*inch
        )

        # Build document elements
        elements = []

        # Header
        elements.extend(self._create_header())

        # Investigation summary
        elements.extend(self._create_investigation_summary(investigation))

        # Platform presence
        elements.extend(self._create_platform_presence(profiles))

        # Page break before details
        elements.append(PageBreak())

        # Profile details
        elements.extend(self._create_profile_details(profiles))

        # Risk analysis
        risk_level = investigation.get("risk_level", "low")
        elements.extend(self._create_risk_analysis(risk_indicators, risk_level))

        # Intelligence summary
        elements.extend(self._create_intelligence_summary(
            investigation,
            profiles,
            risk_indicators
        ))

        # Footer
        elements.extend(self._create_footer_section())

        # Build PDF
        doc.build(elements)

        buffer.seek(0)
        logger.info("pdf_report_generated", investigation_id=investigation.get("id"))

        return buffer


def generate_pdf_report(
    investigation: Dict[str, Any],
    profiles: List[Dict[str, Any]],
    risk_indicators: List[Dict[str, Any]]
) -> io.BytesIO:
    """Convenience function to generate PDF report."""
    generator = IntelligenceReportGenerator()
    return generator.generate_report(investigation, profiles, risk_indicators)
