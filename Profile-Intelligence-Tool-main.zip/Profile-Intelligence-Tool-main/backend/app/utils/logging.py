"""
Utility functions for the backend.
"""

import logging
import structlog
from datetime import datetime
from typing import Any, Dict
from ..core.config import settings


def setup_logging():
    """Configure structured logging for the application."""
    logging.basicConfig(
        format=settings.LOG_FORMAT,
        level=settings.LOG_LEVEL
    )

    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer()
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def format_datetime(dt: datetime, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """Format datetime for display."""
    if dt is None:
        return "N/A"
    return dt.strftime(format_str)


def calculate_percentage(value: int, total: int) -> float:
    """Calculate percentage safely."""
    if total == 0:
        return 0.0
    return round((value / total) * 100, 2)


def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """Truncate text to max length with suffix."""
    if not text or len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def format_number(num: int) -> str:
    """Format large numbers with K/M suffix."""
    if num >= 1000000:
        return f"{num/1000000:.1f}M"
    elif num >= 1000:
        return f"{num/1000:.1f}K"
    return str(num)


def generate_username_variants(username: str) -> list:
    """Generate common username variants for more thorough searching."""
    variants = [username]

    # Add underscore variants
    variants.append(username.replace(" ", "_"))
    variants.append(username.replace(".", "_"))

    # Add dash variants
    variants.append(username.replace(" ", "-"))
    variants.append(username.replace("_", "-"))

    # Remove special characters
    import re
    clean = re.sub(r"[^a-zA-Z0-9]", "", username)
    if clean != username and clean:
        variants.append(clean)

    # Lowercase variant
    if username != username.lower():
        variants.append(username.lower())

    return list(set(variants))


def validate_username(username: str) -> Dict[str, Any]:
    """Validate username format and return validation result."""
    result = {
        "valid": True,
        "errors": [],
        "warnings": []
    }

    if not username:
        result["valid"] = False
        result["errors"].append("Username cannot be empty")
        return result

    if len(username) > 255:
        result["valid"] = False
        result["errors"].append("Username cannot exceed 255 characters")

    if len(username) < 1:
        result["valid"] = False
        result["errors"].append("Username must be at least 1 character")

    # Check for reserved usernames
    reserved = ["admin", "root", "system", "administrator", "api"]
    if username.lower() in reserved:
        result["warnings"].append(
            f"'{username}' is a common reserved username"
        )

    return result
