"""Profile Intelligence Tool Backend Application."""
from .main import app

__all__ = ["app"]
