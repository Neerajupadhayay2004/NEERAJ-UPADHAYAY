"""API Routes initialization."""
from fastapi import APIRouter
from .search import router as search_router
from .report import router as report_router
from .export import router as export_router
from .history import router as history_router

api_router = APIRouter()
api_router.include_router(search_router, prefix="/api", tags=["search"])
api_router.include_router(report_router, prefix="/api", tags=["reports"])
api_router.include_router(export_router, prefix="/api", tags=["export"])
api_router.include_router(history_router, prefix="/api", tags=["history"])

__all__ = ["api_router"]
