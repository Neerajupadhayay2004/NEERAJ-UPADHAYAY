"""
Report API Routes.
Handles investigation reports and data retrieval.
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from typing import Dict, Any
from uuid import UUID
import io
import json
import structlog

from ...schemas import (
    InvestigationDetail,
    InvestigationSummary,
    ErrorResponse
)
from ...services import investigation_service
from ...pdf_generator import generate_pdf_report

logger = structlog.get_logger()
router = APIRouter(tags=["reports"])


@router.get("/report/{investigation_id}", response_model=InvestigationDetail)
async def get_report(investigation_id: str):
    """
    Retrieve a complete investigation report.

    Args:
        investigation_id: UUID of the investigation

    Returns:
        InvestigationDetail with all profiles, risk indicators, and metadata
    """
    result = await investigation_service.get_investigation(investigation_id)

    if not result:
        raise HTTPException(
            status_code=404,
            detail="Investigation not found"
        )

    return InvestigationDetail(
        id=result.get("id"),
        username=result.get("username"),
        search_timestamp=result.get("search_timestamp"),
        status=result.get("status"),
        platforms_searched=result.get("platforms_searched", []),
        platforms_found=result.get("platforms_found", []),
        total_profiles=result.get("total_profiles", 0),
        intelligence_score=result.get("intelligence_score", 0),
        risk_level=result.get("risk_level", "low"),
        notes=result.get("notes"),
        profiles=result.get("profiles", []),
        risk_indicators=result.get("risk_indicators", []),
        created_at=result.get("created_at"),
        updated_at=result.get("updated_at")
    )


@router.get("/report/{investigation_id}/summary")
async def get_report_summary(investigation_id: str) -> Dict[str, Any]:
    """
    Get a summary of the investigation without full details.

    Args:
        investigation_id: UUID of the investigation

    Returns:
        Summary with key metrics and platform presence
    """
    result = await investigation_service.get_investigation(investigation_id)

    if not result:
        raise HTTPException(
            status_code=404,
            detail="Investigation not found"
        )

    profiles = result.get("profiles", [])
    risk_indicators = result.get("risk_indicators", [])

    return {
        "investigation_id": investigation_id,
        "username": result.get("username"),
        "status": result.get("status"),
        "intelligence_score": result.get("intelligence_score"),
        "risk_level": result.get("risk_level"),
        "platforms_count": len(result.get("platforms_found", [])),
        "platforms": result.get("platforms_found", []),
        "risk_indicators_count": len(risk_indicators),
        "high_risk_count": len([r for r in risk_indicators if r.get("severity") in ["critical", "high"]]),
        "search_timestamp": result.get("search_timestamp")
    }
