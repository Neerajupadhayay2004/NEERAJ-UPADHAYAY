"""
History API Routes.
Handles investigation history queries.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Dict, Any, List
import structlog

from ...schemas import HistoryResponse, HistoryItem
from ...services import investigation_service

logger = structlog.get_logger()
router = APIRouter(tags=["history"])


@router.get("/history", response_model=HistoryResponse)
async def get_investigation_history(
    limit: int = Query(50, ge=1, le=100),
    page: int = Query(1, ge=1)
):
    """
    Retrieve investigation history with pagination.

    Returns a list of previous investigations ordered by most recent first.

    Args:
        limit: Number of items per page (default 50)
        page: Page number (default 1)

    Returns:
        HistoryResponse with paginated investigation summaries
    """
    try:
        offset = (page - 1) * limit
        result = await investigation_service.get_history(limit=limit, offset=offset)

        # Transform items to HistoryItem model
        history_items = []
        for item in result.get("items", []):
            history_items.append(HistoryItem(
                id=item.get("id"),
                username=item.get("username"),
                search_timestamp=item.get("search_timestamp"),
                platforms_found=item.get("platforms_found", []),
                risk_level=item.get("risk_level", "low"),
                intelligence_score=item.get("intelligence_score", 0)
            ))

        logger.info("history_retrieved", count=len(history_items))

        return HistoryResponse(
            items=history_items,
            total=result.get("total", 0),
            page=page,
            page_size=limit,
            has_next=result.get("has_next", False)
        )

    except Exception as e:
        logger.error("history_retrieval_failed", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve history: {str(e)}"
        )


@router.get("/history/search")
async def search_history_by_username(
    username: str = Query(..., min_length=1, max_length=255)
) -> List[Dict[str, Any]]:
    """
    Search investigation history by username.

    Args:
        username: Username to search for

    Returns:
        List of matching investigations
    """
    try:
        results = await investigation_service.search_by_username(username)

        logger.info(
            "username_history_search",
            username=username,
            results=len(results)
        )

        return results

    except Exception as e:
        logger.error("username_history_search_failed", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=f"Search failed: {str(e)}"
        )


@router.get("/history/stats")
async def get_investigation_statistics() -> Dict[str, Any]:
    """
    Get summary statistics about investigations.

    Returns counts and analytics about the investigation database.

    Returns:
        Dictionary with statistics including total investigations,
        platform distributions, and risk level breakdowns
    """
    try:
        # Get all investigations for stats calculation
        result = await investigation_service.get_history(limit=1000)

        items = result.get("items", [])

        # Calculate statistics
        total = len(items)

        # Platform distribution
        platform_counts: Dict[str, int] = {}
        for item in items:
            for platform in item.get("platforms_found", []):
                platform_counts[platform] = platform_counts.get(platform, 0) + 1

        # Risk level distribution
        risk_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for item in items:
            risk_level = item.get("risk_level", "low")
            risk_counts[risk_level] = risk_counts.get(risk_level, 0) + 1

        # Average intelligence score
        scores = [item.get("intelligence_score", 0) for item in items]
        avg_score = sum(scores) / max(len(scores), 1)

        return {
            "total_investigations": total,
            "platform_distribution": platform_counts,
            "risk_level_distribution": risk_counts,
            "average_intelligence_score": round(avg_score, 2),
            "most_searched_platforms": sorted(
                platform_counts.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]
        }

    except Exception as e:
        logger.error("statistics_retrieval_failed", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve statistics: {str(e)}"
        )
