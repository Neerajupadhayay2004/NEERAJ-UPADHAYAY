"""
Export API Routes.
Handles PDF and JSON exports of investigation reports.
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from typing import Dict, Any
from uuid import UUID
import io
import json
from datetime import datetime
import structlog

from ...schemas import ExportRequest, ExportResponse
from ...services import investigation_service
from ...pdf_generator import generate_pdf_report

logger = structlog.get_logger()
router = APIRouter(tags=["export"])


@router.get("/export/pdf/{investigation_id}")
async def export_pdf_report(investigation_id: str):
    """
    Generate and download a PDF report for an investigation.

    The PDF report includes:
    - Investigation summary
    - Platform presence analysis
    - Profile details
    - Risk indicators
    - Intelligence assessment

    Args:
        investigation_id: UUID of the investigation

    Returns:
        StreamingResponse with PDF content
    """
    result = await investigation_service.get_investigation(investigation_id)

    if not result:
        raise HTTPException(
            status_code=404,
            detail="Investigation not found"
        )

    try:
        # Generate PDF
        pdf_buffer = generate_pdf_report(
            investigation=result,
            profiles=result.get("profiles", []),
            risk_indicators=result.get("risk_indicators", [])
        )

        filename = f"osint_report_{result.get('username', 'unknown')}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.pdf"

        logger.info("pdf_exported", investigation_id=investigation_id)

        return StreamingResponse(
            pdf_buffer,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename={filename}"
            }
        )

    except Exception as e:
        logger.error("pdf_export_failed", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=f"PDF generation failed: {str(e)}"
        )


@router.get("/export/json/{investigation_id}")
async def export_json_report(investigation_id: str):
    """
    Export investigation data as JSON.

    Provides raw data export for further analysis or integration
    with other tools.

    Args:
        investigation_id: UUID of the investigation

    Returns:
        JSONResponse with complete investigation data
    """
    result = await investigation_service.get_investigation(investigation_id)

    if not result:
        raise HTTPException(
            status_code=404,
            detail="Investigation not found"
        )

    # Clean up data for export
    export_data = {
        "export_metadata": {
            "exported_at": datetime.utcnow().isoformat() + "Z",
            "format_version": "1.0",
            "tool": "Profile Intelligence Tool v1.0.0"
        },
        "investigation": {
            "id": str(result.get("id")),
            "username": result.get("username"),
            "search_timestamp": result.get("search_timestamp"),
            "status": result.get("status"),
            "platforms_searched": result.get("platforms_searched", []),
            "platforms_found": result.get("platforms_found", []),
            "total_profiles": result.get("total_profiles", 0),
            "intelligence_score": result.get("intelligence_score", 0),
            "risk_level": result.get("risk_level", "low"),
            "notes": result.get("notes")
        },
        "profiles": result.get("profiles", []),
        "risk_indicators": result.get("risk_indicators", []),
        "summary": {
            "platforms_count": len(result.get("platforms_found", [])),
            "risk_indicators_count": len(result.get("risk_indicators", [])),
            "has_high_risk": any(
                r.get("severity") in ["critical", "high"]
                for r in result.get("risk_indicators", [])
            )
        }
    }

    filename = f"osint_data_{result.get('username', 'unknown')}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"

    logger.info("json_exported", investigation_id=investigation_id)

    return JSONResponse(
        content=export_data,
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )


@router.post("/export")
async def export_report(export_request: Dict[str, Any]):
    """
    Generic export endpoint supporting multiple formats.

    Request body should include:
    - investigation_id: UUID of the investigation
    - format: 'pdf' or 'json'
    - include_raw_data: boolean (default False)

    Args:
        export_request: Export specifications

    Returns:
        Exported report in specified format
    """
    investigation_id = export_request.get("investigation_id")
    export_format = export_request.get("format", "json").lower()
    include_raw = export_request.get("include_raw_data", False)

    if not investigation_id:
        raise HTTPException(
            status_code=400,
            detail="investigation_id is required"
        )

    if export_format not in ["pdf", "json"]:
        raise HTTPException(
            status_code=400,
            detail="Invalid format. Use 'pdf' or 'json'"
        )

    if export_format == "pdf":
        return await export_pdf_report(investigation_id)
    else:
        return await export_json_report(investigation_id)
