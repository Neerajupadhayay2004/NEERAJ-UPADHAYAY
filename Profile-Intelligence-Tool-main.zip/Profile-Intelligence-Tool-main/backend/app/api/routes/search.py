"""
Search API Routes.
Handles username searches and investigation creation.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from typing import List, Optional
from uuid import UUID
import structlog

from ...schemas import (
    SearchRequest,
    SearchResponse,
    Platform,
    PlatformStatus,
    SearchProgress
)
from ...services import investigation_service

logger = structlog.get_logger()
router = APIRouter(tags=["search"])


@router.post("/search", response_model=SearchResponse)
async def search_username(
    request: SearchRequest,
    background_tasks: BackgroundTasks
):
    """
    Search for a username across social media platforms.

    This endpoint initiates an OSINT investigation to find public profiles
    across various platforms. The search runs asynchronously.

    Args:
        request: SearchRequest containing username and optional platform filters

    Returns:
        SearchResponse with investigation ID and status
    """
    username = request.username.strip()

    if len(username) < 1 or len(username) > 255:
        raise HTTPException(
            status_code=400,
            detail="Username must be between 1 and 255 characters"
        )

    # Get platforms to search
    platforms = None
    if request.platforms:
        platforms = [p.value for p in request.platforms]

    logger.info("search_initiated", username=username, platforms=platforms)

    try:
        # Run investigation synchronously for now (can be made async with background_tasks)
        result = await investigation_service.create_and_run_investigation(
            username=username,
            platforms=platforms
        )

        return SearchResponse(
            investigation_id=result.get("id"),
            username=username,
            status=result.get("status"),
            message="Investigation completed successfully",
            platforms_searching=result.get("platforms_searched", [])
        )

    except Exception as e:
        logger.error("search_failed", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=f"Search failed: {str(e)}"
        )


@router.post("/search/async", response_model=SearchResponse)
async def search_username_async(
    request: SearchRequest,
    background_tasks: BackgroundTasks
):
    """
    Initiate an asynchronous username search.

    The investigation runs in the background and results can be
    retrieved via the /report/{id} endpoint.

    Args:
        request: SearchRequest containing username and optional platform filters

    Returns:
        SearchResponse with investigation ID and pending status
    """
    username = request.username.strip()

    # Get platforms to search
    platforms = None
    if request.platforms:
        platforms = [p.value for p in request.platforms]

    async def run_search():
        """Background task for investigation."""
        await investigation_service.create_and_run_investigation(
            username=username,
            platforms=platforms
        )

    # Queue the background task (simplified - in production use Celery/RQ)
    background_tasks.add_task(run_search)

    logger.info("async_search_initiated", username=username)

    return SearchResponse(
        investigation_id=UUID(int=0),  # Will be assigned by background task
        username=username,
        status="pending",
        message="Investigation initiated. Check /report/{id} for results.",
        platforms_searching=platforms or ["all"]
    )


@router.get("/search/progress/{investigation_id}")
async def get_search_progress(investigation_id: str):
    """
    Get the progress of an ongoing investigation.

    Args:
        investigation_id: UUID of the investigation

    Returns:
        SearchProgress with current status of platform searches
    """
    result = await investigation_service.get_investigation(investigation_id)

    if not result:
        raise HTTPException(
            status_code=404,
            detail="Investigation not found"
        )

    # Build platform statuses
    platform_statuses = []
    for platform in result.get("platforms_searched", []):
        found = platform in result.get("platforms_found", [])
        profile = next(
            (p for p in result.get("profiles", []) if p.get("platform") == platform),
            None
        )
        platform_statuses.append(PlatformStatus(
            platform=platform,
            status="completed",
            found=found,
            profile_url=profile.get("platform_url") if profile else None
        ))

    progress = len(result.get("platforms_found", [])) / max(len(result.get("platforms_searched", [])), 1) * 100

    return SearchProgress(
        investigation_id=investigation_id,
        total_platforms=len(result.get("platforms_searched", [])),
        completed_platforms=len(result.get("platforms_found", [])),
        current_platform=None,
        platform_statuses=platform_statuses,
        progress_percentage=progress
    )
