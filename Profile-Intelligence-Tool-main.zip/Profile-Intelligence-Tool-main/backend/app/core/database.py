"""
Supabase database connection and utility functions.
Handles connection pooling and common database operations.
"""

from supabase import create_client, Client
from .config import settings
from typing import Optional, Dict, Any, List
import structlog

logger = structlog.get_logger()


class DatabaseManager:
    """Manages Supabase database connections and operations."""

    _instance: Optional["DatabaseManager"] = None
    _client: Optional[Client] = None

    def __new__(cls) -> "DatabaseManager":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if self._client is None:
            self._initialize_client()

    def _initialize_client(self) -> None:
        """Initialize the Supabase client with credentials."""
        try:
            self._client = create_client(
                settings.SUPABASE_URL,
                settings.SUPABASE_SERVICE_ROLE_KEY
            )
            logger.info("supabase_client_initialized")
        except Exception as e:
            logger.error("supabase_init_failed", error=str(e))
            raise

    @property
    def client(self) -> Client:
        """Get the Supabase client instance."""
        if self._client is None:
            self._initialize_client()
        return self._client

    async def create_investigation(
        self,
        username: str,
        platforms_searched: List[str]
    ) -> Dict[str, Any]:
        """Create a new investigation record."""
        try:
            result = self.client.table("investigations").insert({
                "username": username,
                "platforms_searched": platforms_searched,
                "status": "pending"
            }).execute()
            logger.info("investigation_created", username=username)
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error("create_investigation_failed", error=str(e))
            raise

    async def update_investigation(
        self,
        investigation_id: str,
        update_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Update an existing investigation."""
        try:
            result = self.client.table("investigations").update(update_data).eq(
                "id", investigation_id
            ).execute()
            logger.info("investigation_updated", id=investigation_id)
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error("update_investigation_failed", error=str(e))
            raise

    async def get_investigation(self, investigation_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve an investigation by ID."""
        try:
            result = self.client.table("investigations").select("*").eq(
                "id", investigation_id
            ).execute()
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error("get_investigation_failed", error=str(e))
            raise

    async def get_investigation_history(
        self,
        limit: int = 50,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """Retrieve investigation history with pagination."""
        try:
            result = self.client.table("investigations").select("*").order(
                "search_timestamp", desc=True
            ).range(offset, offset + limit - 1).execute()
            return result.data
        except Exception as e:
            logger.error("get_history_failed", error=str(e))
            raise

    async def create_profile(self, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new profile record."""
        try:
            result = self.client.table("profiles").insert(profile_data).execute()
            logger.info("profile_created", platform=profile_data.get("platform"))
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error("create_profile_failed", error=str(e))
            raise

    async def get_profiles_by_investigation(
        self,
        investigation_id: str
    ) -> List[Dict[str, Any]]:
        """Retrieve all profiles for an investigation."""
        try:
            result = self.client.table("profiles").select("*").eq(
                "investigation_id", investigation_id
            ).execute()
            return result.data
        except Exception as e:
            logger.error("get_profiles_failed", error=str(e))
            raise

    async def create_risk_indicator(
        self,
        indicator_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Create a new risk indicator."""
        try:
            result = self.client.table("risk_indicators").insert(indicator_data).execute()
            logger.info("risk_indicator_created")
            return result.data[0] if result.data else None
        except Exception as e:
            logger.error("create_risk_indicator_failed", error=str(e))
            raise

    async def get_risk_indicators(
        self,
        investigation_id: str
    ) -> List[Dict[str, Any]]:
        """Retrieve risk indicators for an investigation."""
        try:
            result = self.client.table("risk_indicators").select("*").eq(
                "investigation_id", investigation_id
            ).execute()
            return result.data
        except Exception as e:
            logger.error("get_risk_indicators_failed", error=str(e))
            raise

    async def search_investigations_by_username(
        self,
        username: str
    ) -> List[Dict[str, Any]]:
        """Search investigations by username."""
        try:
            result = self.client.table("investigations").select("*").ilike(
                "username", f"%{username}%"
            ).execute()
            return result.data
        except Exception as e:
            logger.error("search_username_failed", error=str(e))
            raise


db = DatabaseManager()
