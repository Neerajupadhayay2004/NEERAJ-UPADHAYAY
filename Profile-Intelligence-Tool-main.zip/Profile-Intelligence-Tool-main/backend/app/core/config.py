"""
Configuration settings for the OSINT Profile Intelligence Tool.
Uses environment variables with sensible defaults.
"""

from pydantic_settings import BaseSettings
from typing import List
import os
from dotenv import load_dotenv

load_dotenv()


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Application Metadata
    APP_NAME: str = "Profile Intelligence Tool"
    APP_VERSION: str = "1.0.0"
    APP_DESCRIPTION: str = "OSINT Profile Analysis and Intelligence Reporting"
    DEBUG: bool = True

    # Server Configuration
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # Supabase Configuration (pre-provisioned)
    SUPABASE_URL: str = ""
    SUPABASE_ANON_KEY: str = ""
    SUPABASE_SERVICE_ROLE_KEY: str = ""

    # CORS Settings
    CORS_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:3000"]
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: List[str] = ["*"]
    CORS_ALLOW_HEADERS: List[str] = ["*"]

    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 60

    # Platform Search Configuration
    MAX_CONCURRENT_SEARCHES: int = 5
    SEARCH_TIMEOUT: int = 30
    REQUEST_DELAY: float = 1.0

    # Supported Platforms
    SUPPORTED_PLATFORMS: List[str] = [
        "github",
        "twitter_x",
        "reddit",
        "instagram",
        "tiktok",
        "youtube",
        "medium",
    ]

    # Risk Scoring Weights
    RISK_WEIGHT_NEW_ACCOUNT: float = 0.3
    RISK_WEIGHT_SUSPICIOUS_PATTERN: float = 0.25
    RISK_WEIGHT_DUPLICATE_USERNAME: float = 0.2
    RISK_WEIGHT_EXCESSIVE_LINKS: float = 0.15
    RISK_WEIGHT_LOW_ACTIVITY: float = 0.1

    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
