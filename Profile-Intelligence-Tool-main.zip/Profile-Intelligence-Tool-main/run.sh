#!/bin/bash

# Profile Intelligence Tool - Development Runner

echo "========================================"
echo "Profile Intelligence Tool - OSINT Platform"
echo "========================================"

# Check if we're in the project root
if [ ! -d "backend" ] || [ ! -d "frontend" ]; then
    echo "Error: Please run this script from the project root directory"
    exit 1
fi

# Function to run backend
run_backend() {
    echo "Starting Backend Server..."
    cd backend

    # Create virtual environment if it doesn't exist
    if [ ! -d "venv" ]; then
        echo "Creating Python virtual environment..."
        python3 -m venv venv
    fi

    # Activate virtual environment
    source venv/bin/activate

    # Install dependencies
    echo "Installing backend dependencies..."
    pip install -q -r requirements.txt

    # Run server
    echo "Backend running at http://localhost:8000"
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
}

# Function to run frontend
run_frontend() {
    echo "Starting Frontend Development Server..."
    cd frontend

    # Install dependencies if node_modules doesn't exist
    if [ ! -d "node_modules" ]; then
        echo "Installing frontend dependencies..."
        npm install
    fi

    # Run development server
    echo "Frontend running at http://localhost:5173"
    npm run dev
}

# Main execution
case "$1" in
    backend)
        run_backend
        ;;
    frontend)
        run_frontend
        ;;
    *)
        echo "Usage: ./run.sh [backend|frontend]"
        echo ""
        echo "Options:"
        echo "  backend  - Start the FastAPI backend server"
        echo "  frontend - Start the React frontend development server"
        echo ""
        echo "For concurrent development, open two terminals:"
        echo "  Terminal 1: ./run.sh backend"
        echo "  Terminal 2: ./run.sh frontend"
        exit 1
        ;;
esac
