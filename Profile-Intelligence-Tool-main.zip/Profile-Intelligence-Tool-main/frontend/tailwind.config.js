/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cyber: {
          dark: '#0a0a0f',
          darker: '#050508',
          primary: '#1e3a5f',
          secondary: '#2563eb',
          accent: '#f97316',
          success: '#22c55e',
          warning: '#eab308',
          danger: '#ef4444',
          muted: '#64748b',
        },
        risk: {
          low: '#22c55e',
          medium: '#eab308',
          high: '#f97316',
          critical: '#ef4444',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'scan': 'scan 2s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        scan: {
          '0%, 100%': { transform: 'translateY(-100%)' },
          '50%': { transform: 'translateY(100%)' },
        },
        glow: {
          'from': { boxShadow: '0 0 5px #2563eb, 0 0 10px #2563eb' },
          'to': { boxShadow: '0 0 10px #2563eb, 0 0 20px #2563eb' },
        }
      },
      backgroundImage: {
        'cyber-gradient': 'linear-gradient(135deg, #0a0a0f 0%, #1e3a5f 50%, #0a0a0f 100%)',
        'card-gradient': 'linear-gradient(180deg, rgba(30, 58, 95, 0.3) 0%, rgba(10, 10, 15, 0.9) 100%)',
      }
    },
  },
  plugins: [],
}
