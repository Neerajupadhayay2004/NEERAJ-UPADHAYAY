import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/common';
import { SearchPage, DashboardPage, ReportPage, HistoryPage } from './pages';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-cyber-dark bg-cyber-gradient">
        <Header />
        <main className="pt-16">
          <Routes>
            <Route path="/" element={<SearchPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/report/:id" element={<ReportPage />} />
            <Route path="/history" element={<HistoryPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
