import { useState } from 'react';
import { Search, Shield, AlertTriangle, Loader2 } from 'lucide-react';
import { PlatformCard } from '../common';

const supportedPlatforms = [
  { id: 'github', name: 'GitHub', icon: 'GH', color: 'bg-gray-700' },
  { id: 'twitter_x', name: 'X (Twitter)', icon: 'X', color: 'bg-gray-900' },
  { id: 'reddit', name: 'Reddit', icon: 'RR', color: 'bg-orange-600' },
  { id: 'instagram', name: 'Instagram', icon: 'IG', color: 'bg-pink-600' },
  { id: 'tiktok', name: 'TikTok', icon: 'TT', color: 'bg-gray-800' },
  { id: 'youtube', name: 'YouTube', icon: 'YT', color: 'bg-red-600' },
  { id: 'medium', name: 'Medium', icon: 'M', color: 'bg-green-700' },
];

interface SearchFormProps {
  onSearch: (username: string, platforms?: string[]) => void;
  isLoading: boolean;
}

export function SearchForm({ onSearch, isLoading }: SearchFormProps) {
  const [username, setUsername] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onSearch(
        username.trim(),
        selectAll ? undefined : selectedPlatforms.length > 0 ? selectedPlatforms : undefined
      );
    }
  };

  const togglePlatform = (platformId: string) => {
    if (selectAll) {
      setSelectAll(false);
    }
    setSelectedPlatforms((prev) =>
      prev.includes(platformId)
        ? prev.filter((p) => p !== platformId)
        : [...prev, platformId]
    );
  };

  const toggleAll = () => {
    setSelectAll(!selectAll);
    if (!selectAll) {
      setSelectedPlatforms([]);
    }
  };

  return (
    <div className="cyber-card p-6 md:p-8">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-cyber-secondary/20 mb-4">
          <Shield className="w-8 h-8 text-cyber-secondary" />
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
          Profile Intelligence Search
        </h1>
        <p className="text-gray-400 text-sm md:text-base max-w-lg mx-auto">
          Enter a username to discover public social media profiles and gather
          OSINT intelligence across multiple platforms.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Username Input */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-gray-500" />
          </div>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Enter username to investigate..."
            className="cyber-input w-full pl-12 pr-4 py-4 text-lg"
            disabled={isLoading}
          />
        </div>

        {/* Platform Selection */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-300">
              Target Platforms
            </label>
            <button
              type="button"
              onClick={toggleAll}
              className="text-xs text-cyber-secondary hover:underline"
            >
              {selectAll ? 'Deselect All' : 'Select All'}
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {supportedPlatforms.map((platform) => (
              <button
                key={platform.id}
                type="button"
                onClick={() => togglePlatform(platform.id)}
                disabled={selectAll}
                className={`p-3 rounded-lg border text-sm font-medium transition-all ${
                  selectAll || selectedPlatforms.includes(platform.id)
                    ? 'border-cyber-secondary/50 bg-cyber-secondary/10 text-white'
                    : 'border-gray-700/50 bg-gray-900/50 text-gray-400 hover:border-gray-600'
                } ${selectAll ? 'cursor-default' : 'cursor-pointer'}`}
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`w-6 h-6 ${platform.color} rounded flex items-center justify-center text-white text-xs font-bold`}
                  >
                    {platform.icon}
                  </span>
                  <span className="truncate">{platform.name}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Disclaimer */}
        <div className="flex items-start gap-3 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
          <AlertTriangle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-yellow-200">
            <p className="font-medium mb-1">Important Notice</p>
            <p className="text-yellow-300/80">
              This tool only accesses publicly available information. It does not
              collect private data, passwords, or perform any unauthorized
              access. All searches comply with ethical OSINT practices.
            </p>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading || !username.trim()}
          className="cyber-button w-full flex items-center justify-center gap-3 text-lg py-4 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Investigating...
            </>
          ) : (
            <>
              <Shield className="w-5 h-5" />
              Start Investigation
            </>
          )}
        </button>
      </form>
    </div>
  );
}
