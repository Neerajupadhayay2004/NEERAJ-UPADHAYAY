import { Search, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import type { PlatformStatus } from '../../types';

interface SearchProgressProps {
  platforms: PlatformStatus[];
  progress: number;
  isComplete: boolean;
}

export function SearchProgress({ platforms, progress, isComplete }: SearchProgressProps) {
  return (
    <div className="cyber-card p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white">Search Progress</h3>
        <span className="text-sm text-gray-400">
          {Math.round(progress)}% Complete
        </span>
      </div>

      {/* Progress Bar */}
      <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden mb-6">
        <div
          className={`absolute inset-y-0 left-0 bg-cyber-secondary transition-all duration-500 ${
            isComplete ? 'bg-green-500' : ''
          }`}
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Platform Status Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {platforms.map((platform) => (
          <div
            key={platform.platform}
            className={`p-3 rounded-lg border transition-all ${
              platform.found
                ? 'border-green-500/30 bg-green-500/10'
                : platform.status === 'searching'
                ? 'border-cyber-secondary/30 bg-cyber-secondary/10 animate-pulse'
                : 'border-gray-700/30 bg-gray-900/30'
            }`}
          >
            <div className="flex items-center gap-2">
              {platform.status === 'searching' ? (
                <Loader2 className="w-4 h-4 text-cyber-secondary animate-spin" />
              ) : platform.found ? (
                <CheckCircle className="w-4 h-4 text-green-500" />
              ) : (
                <XCircle className="w-4 h-4 text-gray-500" />
              )}
              <span className="text-sm font-medium text-white capitalize">
                {platform.platform.replace('_', ' ')}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
