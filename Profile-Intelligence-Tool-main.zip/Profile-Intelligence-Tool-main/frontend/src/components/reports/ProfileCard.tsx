import { ExternalLink, MapPin, Calendar, Link as LinkIcon, Users, FileText } from 'lucide-react';
import { format } from 'date-fns';
import type { Profile } from '../../types';

interface ProfileCardProps {
  profile: Profile;
}

const platformColors: Record<string, string> = {
  github: 'bg-gray-700',
  twitter_x: 'bg-gray-900',
  reddit: 'bg-orange-600',
  instagram: 'bg-pink-600',
  tiktok: 'bg-gray-800',
  youtube: 'bg-red-600',
  medium: 'bg-green-700',
};

const platformNames: Record<string, string> = {
  github: 'GitHub',
  twitter_x: 'X (Twitter)',
  reddit: 'Reddit',
  instagram: 'Instagram',
  tiktok: 'TikTok',
  youtube: 'YouTube',
  medium: 'Medium',
};

export function ProfileCard({ profile }: ProfileCardProps) {
  const platformColor = platformColors[profile.platform] || 'bg-gray-700';
  const platformName = platformNames[profile.platform] || profile.platform;

  return (
    <div className="cyber-card p-5 hover:border-cyber-secondary/50 transition-colors">
      <div className="flex items-start gap-4">
        {/* Platform Logo */}
        <div
          className={`w-12 h-12 ${platformColor} rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0`}
        >
          {platformName.slice(0, 2).toUpperCase()}
        </div>

        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center justify-between gap-2 mb-2">
            <div>
              <h4 className="font-semibold text-white">{profile.display_name || profile.username}</h4>
              <p className="text-sm text-gray-400">@{profile.username}</p>
            </div>
            <a
              href={profile.platform_url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors"
            >
              <ExternalLink className="w-4 h-4 text-gray-400" />
            </a>
          </div>

          {/* Bio */}
          {profile.bio && (
            <p className="text-sm text-gray-300 mb-3 line-clamp-2">{profile.bio}</p>
          )}

          {/* Stats */}
          <div className="flex flex-wrap gap-4 text-xs text-gray-400 mb-3">
            {profile.followers_count > 0 && (
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3" />
                {profile.followers_count.toLocaleString()} followers
              </span>
            )}
            {profile.posts_count > 0 && (
              <span className="flex items-center gap-1">
                <FileText className="w-3 h-3" />
                {profile.posts_count.toLocaleString()} posts
              </span>
            )}
            {profile.account_created_date && (
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {format(new Date(profile.account_created_date), 'MMM yyyy')}
              </span>
            )}
          </div>

          {/* External Links */}
          {profile.external_links.length > 0 && (
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <LinkIcon className="w-3 h-3" />
              <span className="truncate">
                {profile.external_links.slice(0, 3).join(', ')}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function ProfileList({ profiles }: { profiles: Profile[] }) {
  if (profiles.length === 0) {
    return (
      <div className="cyber-card p-8 text-center">
        <p className="text-gray-400">No profiles were found for this username.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {profiles.map((profile) => (
        <ProfileCard key={profile.id} profile={profile} />
      ))}
    </div>
  );
}
