import { Download, Share2, Clock, User, Globe, Shield, FileJson } from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import type { Investigation } from '../../types';
import { RiskBadge, ScoreIndicator } from '../common';
import { exportApi } from '../../services/api';

interface ReportSummaryProps {
  investigation: Investigation;
}

export function ReportSummary({ investigation }: ReportSummaryProps) {
  const navigate = useNavigate();
  const searchDate = investigation.search_timestamp
    ? format(new Date(investigation.search_timestamp), 'PPpp')
    : 'Unknown';

  const handleExportPdf = async () => {
    try {
      await exportApi.downloadPdf(
        investigation.id,
        `osint_report_${investigation.username}_${format(new Date(), 'yyyyMMdd_HHmmss')}.pdf`
      );
    } catch (error) {
      console.error('Failed to export PDF:', error);
    }
  };

  const handleExportJson = async () => {
    try {
      await exportApi.downloadJson(
        investigation.id,
        `osint_data_${investigation.username}_${format(new Date(), 'yyyyMMdd_HHmmss')}.json`
      );
    } catch (error) {
      console.error('Failed to export JSON:', error);
    }
  };

  return (
    <div className="cyber-card p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-3">
            <User className="w-6 h-6 text-cyber-secondary" />
            {investigation.username}
          </h2>
          <div className="flex items-center gap-2 text-sm text-gray-400 mt-1">
            <Clock className="w-4 h-4" />
            Searched on {searchDate}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExportPdf} className="cyber-button-outline flex items-center gap-2 text-sm">
            <Download className="w-4 h-4" />
            PDF
          </button>
          <button onClick={handleExportJson} className="cyber-button-outline flex items-center gap-2 text-sm">
            <FileJson className="w-4 h-4" />
            JSON
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {/* Intelligence Score */}
        <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50 text-center">
          <p className="text-xs text-gray-500 mb-2">INTELLIGENCE SCORE</p>
          <ScoreIndicator score={investigation.intelligence_score} size="md" />
        </div>

        {/* Risk Level */}
        <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50 text-center">
          <p className="text-xs text-gray-500 mb-2">RISK LEVEL</p>
          <RiskBadge level={investigation.risk_level} size="lg" />
        </div>

        {/* Platforms Found */}
        <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50 text-center">
          <p className="text-xs text-gray-500 mb-2">PLATFORMS FOUND</p>
          <p className="text-2xl font-bold text-white">
            {investigation.platforms_found.length}
          </p>
          <p className="text-xs text-gray-500">
            of {investigation.platforms_searched.length} searched
          </p>
        </div>

        {/* Risk Indicators */}
        <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50 text-center">
          <p className="text-xs text-gray-500 mb-2">RISK INDICATORS</p>
          <p className="text-2xl font-bold text-white">
            {investigation.risk_indicators.length}
          </p>
          <p className="text-xs text-gray-500">
            issues identified
          </p>
        </div>
      </div>

      {/* Platforms Summary */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Globe className="w-4 h-4" />
          Platform Detection Results
        </h3>

        <div className="flex flex-wrap gap-2">
          {investigation.platforms_searched.map((platform) => {
            const found = investigation.platforms_found.includes(platform);
            return (
              <span
                key={platform}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  found
                    ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                    : 'bg-gray-800 text-gray-500 border border-gray-700'
                }`}
              >
                {platform.replace('_', ' ').toUpperCase()}
                {found ? ' ✓' : ' ✕'}
              </span>
            );
          })}
        </div>
      </div>

      {/* Notes */}
      {investigation.notes && (
        <div className="mt-6 p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
          <p className="text-xs text-gray-500 mb-1">NOTES</p>
          <p className="text-sm text-gray-300">{investigation.notes}</p>
        </div>
      )}
    </div>
  );
}
