import { AlertTriangle, Info, Shield, XCircle } from 'lucide-react';
import type { RiskIndicator } from '../../types';
import { RiskBadge } from '../common';

interface RiskIndicatorsProps {
  indicators: RiskIndicator[];
}

const severityConfig = {
  critical: {
    icon: XCircle,
    bg: 'bg-red-500/10 border-red-500/30',
    iconColor: 'text-red-400',
  },
  high: {
    icon: AlertTriangle,
    bg: 'bg-orange-500/10 border-orange-500/30',
    iconColor: 'text-orange-400',
  },
  medium: {
    icon: Info,
    bg: 'bg-yellow-500/10 border-yellow-500/30',
    iconColor: 'text-yellow-400',
  },
  low: {
    icon: Shield,
    bg: 'bg-green-500/10 border-green-500/30',
    iconColor: 'text-green-400',
  },
};

const indicatorTypeLabels: Record<string, string> = {
  suspicious_username_pattern: 'Suspicious Username Pattern',
  new_account: 'New Account',
  excessive_external_links: 'Excessive External Links',
  low_activity: 'Low Activity',
  suspicious_follower_ratio: 'Suspicious Follower Ratio',
  duplicate_username: 'Duplicate Username',
};

export function RiskIndicatorCard({ indicator }: { indicator: RiskIndicator }) {
  const config = severityConfig[indicator.severity];
  const Icon = config.icon;
  const label = indicatorTypeLabels[indicator.indicator_type] || indicator.indicator_type;

  return (
    <div className={`p-4 rounded-lg border ${config.bg}`}>
      <div className="flex items-start gap-3">
        <div className={`p-1 rounded ${config.iconColor}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between gap-2">
            <h4 className="text-sm font-medium text-white">{label}</h4>
            <RiskBadge level={indicator.severity} size="sm" />
          </div>
          <p className="text-sm text-gray-400 mt-1">{indicator.description}</p>
          {indicator.evidence && Object.keys(indicator.evidence).length > 0 && (
            <div className="mt-2 p-2 bg-gray-900/50 rounded text-xs">
              <pre className="text-gray-500 overflow-x-auto">
                {JSON.stringify(indicator.evidence, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function RiskIndicators({ indicators }: RiskIndicatorsProps) {
  if (indicators.length === 0) {
    return (
      <div className="cyber-card p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Risk Analysis</h3>
        <div className="flex items-center gap-3 p-4 rounded-lg bg-green-500/10 border border-green-500/30">
          <Shield className="w-6 h-6 text-green-400" />
          <div>
            <p className="font-medium text-green-400">No Risk Indicators Found</p>
            <p className="text-sm text-gray-400">
              This profile appears to be low risk based on the analysis.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Sort by severity
  const severityOrder = ['critical', 'high', 'medium', 'low'];
  const sortedIndicators = [...indicators].sort(
    (a, b) => severityOrder.indexOf(a.severity) - severityOrder.indexOf(b.severity)
  );

  return (
    <div className="cyber-card p-6">
      <h3 className="text-lg font-semibold text-white mb-4">
        Risk Analysis
        <span className="ml-2 text-sm font-normal text-gray-500">
          ({indicators.length} indicator{indicators.length !== 1 ? 's' : ''} found)
        </span>
      </h3>

      <div className="space-y-3">
        {sortedIndicators.map((indicator) => (
          <RiskIndicatorCard key={indicator.id} indicator={indicator} />
        ))}
      </div>
    </div>
  );
}
