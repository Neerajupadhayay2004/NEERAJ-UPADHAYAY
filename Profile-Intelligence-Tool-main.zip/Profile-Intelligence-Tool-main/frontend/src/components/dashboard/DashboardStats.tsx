import { TrendingUp, Users, AlertTriangle, Eye } from 'lucide-react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import type { DashboardStats } from '../../types';

interface DashboardStatsProps {
  stats: DashboardStats | null;
  isLoading: boolean;
}

const COLORS = ['#22c55e', '#eab308', '#f97316', '#ef4444'];

export function DashboardStatsPanel({ stats, isLoading }: DashboardStatsProps) {
  if (isLoading) {
    return (
      <div className="cyber-card p-6 animate-pulse">
        <div className="h-6 bg-gray-700 rounded w-1/4 mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-40 bg-gray-700 rounded" />
          <div className="h-40 bg-gray-700 rounded" />
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="cyber-card p-6">
        <p className="text-gray-400 text-center">No statistics available</p>
      </div>
    );
  }

  const riskData = Object.entries(stats.risk_level_distribution).map(([level, count]) => ({
    name: level.toUpperCase(),
    value: count,
  }));

  const platformData = stats.most_searched_platforms.map(([platform, count]) => ({
    name: platform,
    count,
  }));

  const statCards = [
    {
      title: 'Total Investigations',
      value: stats.total_investigations,
      icon: Eye,
      color: 'text-cyber-secondary',
    },
    {
      title: 'Avg. Intelligence Score',
      value: stats.average_intelligence_score.toFixed(1),
      icon: TrendingUp,
      color: 'text-green-400',
    },
    {
      title: 'Platforms Searched',
      value: Object.keys(stats.platform_distribution).length,
      icon: Users,
      color: 'text-yellow-400',
    },
    {
      title: 'High Risk Cases',
      value: (stats.risk_level_distribution.high || 0) + (stats.risk_level_distribution.critical || 0),
      icon: AlertTriangle,
      color: 'text-red-400',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <div key={stat.title} className="cyber-card p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg bg-gray-800 ${stat.color}`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-gray-400">{stat.title}</p>
                <p className="text-xl font-bold text-white">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Risk Distribution Pie Chart */}
        <div className="cyber-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Risk Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {riskData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(10, 10, 15, 0.95)',
                    border: '1px solid rgba(30, 58, 95, 0.5)',
                    borderRadius: '8px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Platform Distribution Bar Chart */}
        <div className="cyber-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Most Searched Platforms</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={platformData} layout="vertical">
                <XAxis type="number" stroke="#64748b" />
                <YAxis dataKey="name" type="category" stroke="#64748b" width={80} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(10, 10, 15, 0.95)',
                    border: '1px solid rgba(30, 58, 95, 0.5)',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="count" fill="#2563eb" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
