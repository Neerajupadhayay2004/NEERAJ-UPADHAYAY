export { DashboardStatsPanel } from './DashboardStats';
export { RecentInvestigations } from './RecentInvestigations';
