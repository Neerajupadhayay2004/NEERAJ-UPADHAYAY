import { format } from 'date-fns';
import { Clock, ExternalLink, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { HistoryItem } from '../../types';
import { RiskBadge } from '../common';

interface RecentInvestigationsProps {
  items: HistoryItem[];
  isLoading: boolean;
}

export function RecentInvestigations({ items, isLoading }: RecentInvestigationsProps) {
  if (isLoading) {
    return (
      <div className="cyber-card p-6">
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 bg-gray-700 rounded" />
          ))}
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="cyber-card p-6">
        <p className="text-gray-400 text-center py-8">
          No investigations yet. Start your first search!
        </p>
        <Link to="/" className="cyber-button inline-flex items-center gap-2 mx-auto">
          <ArrowRight className="w-4 h-4" />
          Start Searching
        </Link>
      </div>
    );
  }

  return (
    <div className="cyber-card overflow-hidden">
      <div className="p-4 border-b border-gray-700 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Recent Investigations</h3>
        <Link to="/history" className="text-sm text-cyber-secondary hover:underline">
          View All
        </Link>
      </div>

      <div className="divide-y divide-gray-700/50">
        {items.slice(0, 5).map((item) => (
          <Link
            key={item.id}
            to={`/report/${item.id}`}
            className="block p-4 hover:bg-cyber-primary/10 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3">
                  <span className="font-medium text-white truncate">
                    {item.username}
                  </span>
                  <RiskBadge level={item.risk_level} size="sm" />
                </div>
                <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {format(new Date(item.search_timestamp), 'MMM d, yyyy HH:mm')}
                  </span>
                  <span>{item.platforms_found.length} platforms</span>
                  <span>Score: {item.intelligence_score}</span>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-gray-500" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
