interface Platform {
  id: string;
  name: string;
  icon: string;
  color: string;
}

const supportedPlatforms: Platform[] = [
  { id: 'github', name: 'GitHub', icon: 'GH', color: 'bg-gray-700' },
  { id: 'twitter_x', name: 'X (Twitter)', icon: 'X', color: 'bg-gray-900' },
  { id: 'reddit', name: 'Reddit', icon: 'RR', color: 'bg-orange-600' },
  { id: 'instagram', name: 'Instagram', icon: 'IG', color: 'bg-pink-600' },
  { id: 'tiktok', name: 'TikTok', icon: 'TT', color: 'bg-gray-800' },
  { id: 'youtube', name: 'YouTube', icon: 'YT', color: 'bg-red-600' },
  { id: 'medium', name: 'Medium', icon: 'M', color: 'bg-green-700' },
];

interface PlatformCardProps {
  platformId: string;
  status: 'found' | 'not_found' | 'searching' | 'pending';
  profileUrl?: string;
  onClick?: () => void;
}

export function PlatformCard({ platformId, status, profileUrl, onClick }: PlatformCardProps) {
  const platform = supportedPlatforms.find((p) => p.id === platformId);

  if (!platform) return null;

  const statusStyles = {
    found: 'border-green-500/50 bg-green-500/10',
    not_found: 'border-gray-700/50 bg-gray-900/50 opacity-50',
    searching: 'border-cyber-secondary/50 bg-cyber-secondary/10 animate-pulse',
    pending: 'border-gray-700/50 bg-gray-900/50',
  };

  const statusIcons = {
    found: (
      <span className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center text-xs text-white">
        ✓
      </span>
    ),
    not_found: (
      <span className="w-5 h-5 rounded-full bg-gray-600 flex items-center justify-center text-xs text-gray-400">
        ✕
      </span>
    ),
    searching: (
      <span className="w-5 h-5 rounded-full bg-cyber-secondary animate-pulse flex items-center justify-center">
        <span className="w-2 h-2 rounded-full bg-white animate-ping" />
      </span>
    ),
    pending: (
      <span className="w-5 h-5 rounded-full bg-gray-700" />
    ),
  };

  return (
    <div
      onClick={onClick}
      className={`relative p-4 rounded-lg border ${statusStyles[status]} transition-all duration-300 cursor-pointer hover:scale-105`}
    >
      <div className="flex items-center gap-3">
        <div
          className={`w-10 h-10 ${platform.color} rounded-lg flex items-center justify-center text-white font-bold text-sm`}
        >
          {platform.icon}
        </div>
        <div className="flex-1">
          <p className="text-white font-medium">{platform.name}</p>
          <p className="text-xs text-gray-500 capitalize">{status.replace('_', ' ')}</p>
        </div>
        {statusIcons[status]}
      </div>
      {status === 'found' && profileUrl && (
        <a
          href={profileUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="block mt-2 text-xs text-cyber-secondary hover:underline truncate"
          onClick={(e) => e.stopPropagation()}
        >
          {profileUrl}
        </a>
      )}
    </div>
  );
}

export function PlatformGrid({
  platforms,
  foundPlatforms = [],
  profileUrls = {},
}: {
  platforms: string[];
  foundPlatforms?: string[];
  profileUrls?: Record<string, string>;
}) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
      {platforms.map((platformId) => (
        <PlatformCard
          key={platformId}
          platformId={platformId}
          status={foundPlatforms.includes(platformId) ? 'found' : 'not_found'}
          profileUrl={profileUrls[platformId]}
        />
      ))}
    </div>
  );
}
