import type { RiskLevel } from '../../types';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md' | 'lg';
}

const riskConfig: Record<RiskLevel, { label: string; bgClass: string; textClass: string }> = {
  low: {
    label: 'LOW',
    bgClass: 'bg-green-500/20 border-green-500/50',
    textClass: 'text-green-400',
  },
  medium: {
    label: 'MEDIUM',
    bgClass: 'bg-yellow-500/20 border-yellow-500/50',
    textClass: 'text-yellow-400',
  },
  high: {
    label: 'HIGH',
    bgClass: 'bg-orange-500/20 border-orange-500/50',
    textClass: 'text-orange-400',
  },
  critical: {
    label: 'CRITICAL',
    bgClass: 'bg-red-500/20 border-red-500/50',
    textClass: 'text-red-400',
  },
};

const sizeClasses = {
  sm: 'px-2 py-0.5 text-xs',
  md: 'px-3 py-1 text-sm',
  lg: 'px-4 py-1.5 text-base',
};

export function RiskBadge({ level, size = 'md' }: RiskBadgeProps) {
  const config = riskConfig[level];

  return (
    <span
      className={`inline-flex items-center font-semibold rounded-full border ${config.bgClass} ${config.textClass} ${sizeClasses[size]}`}
    >
      {config.label}
    </span>
  );
}

interface ScoreIndicatorProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
}

const scoreColors = (score: number) => {
  if (score >= 80) return 'text-red-400';
  if (score >= 60) return 'text-orange-400';
  if (score >= 40) return 'text-yellow-400';
  return 'text-green-400';
};

export function ScoreIndicator({ score, size = 'md' }: ScoreIndicatorProps) {
  const sizeClasses = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-4xl',
  };

  return (
    <div className="flex flex-col items-center">
      <span className={`font-bold ${sizeClasses[size]} ${scoreColors(score)}`}>
        {score}
      </span>
      <span className="text-xs text-gray-500">/ 100</span>
    </div>
  );
}
