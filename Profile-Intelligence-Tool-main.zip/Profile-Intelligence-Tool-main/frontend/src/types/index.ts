export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type InvestigationStatus = 'pending' | 'in_progress' | 'completed' | 'failed';

export interface Profile {
  id: string;
  platform: string;
  platform_url: string;
  username: string;
  display_name: string | null;
  bio: string | null;
  profile_picture_url: string | null;
  account_created_date: string | null;
  followers_count: number;
  following_count: number;
  posts_count: number;
  is_verified: boolean;
  is_public: boolean;
  external_links: string[];
  last_activity_date: string | null;
  raw_metadata: Record<string, unknown>;
  created_at: string;
}

export interface RiskIndicator {
  id: string;
  investigation_id: string;
  profile_id: string | null;
  indicator_type: string;
  severity: RiskLevel;
  description: string;
  evidence: Record<string, unknown>;
  created_at: string;
}

export interface Investigation {
  id: string;
  username: string;
  search_timestamp: string;
  status: InvestigationStatus;
  platforms_searched: string[];
  platforms_found: string[];
  total_profiles: number;
  intelligence_score: number;
  risk_level: RiskLevel;
  notes: string | null;
  profiles: Profile[];
  risk_indicators: RiskIndicator[];
  created_at: string;
  updated_at: string;
}

export interface SearchRequest {
  username: string;
  platforms?: string[];
  include_risk_analysis?: boolean;
}

export interface SearchResponse {
  investigation_id: string;
  username: string;
  status: InvestigationStatus;
  message: string;
  platforms_searching: string[];
}

export interface HistoryItem {
  id: string;
  username: string;
  search_timestamp: string;
  platforms_found: string[];
  risk_level: RiskLevel;
  intelligence_score: number;
}

export interface HistoryResponse {
  items: HistoryItem[];
  total: number;
  page: number;
  page_size: number;
  has_next: boolean;
}

export interface PlatformStatus {
  platform: string;
  status: string;
  found: boolean;
  profile_url: string | null;
  error: string | null;
}

export interface SearchProgress {
  investigation_id: string;
  total_platforms: number;
  completed_platforms: number;
  current_platform: string | null;
  platform_statuses: PlatformStatus[];
  progress_percentage: number;
}

export interface DashboardStats {
  total_investigations: number;
  platform_distribution: Record<string, number>;
  risk_level_distribution: Record<RiskLevel, number>;
  average_intelligence_score: number;
  most_searched_platforms: [string, number][];
}
