import axios, { AxiosError } from 'axios';
import type {
  SearchRequest,
  SearchResponse,
  Investigation,
  HistoryResponse,
  SearchProgress,
  DashboardStats,
} from '../types';

const API_BASE_URL = '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for logging
api.interceptors.request.use(
  (config) => {
    console.log(`[API] ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('[API] Request error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    const message = error.response?.data
      ? (error.response.data as { detail?: string; error?: string }).detail ||
        (error.response.data as { detail?: string; error?: string }).error ||
        'An error occurred'
      : error.message;
    console.error('[API] Response error:', message);
    return Promise.reject(new Error(message));
  }
);

export const searchApi = {
  searchUsername: async (username: string, platforms?: string[]): Promise<SearchResponse> => {
    const response = await api.post<SearchResponse>('/search', {
      username,
      platforms,
      include_risk_analysis: true,
    });
    return response.data;
  },

  getSearchProgress: async (investigationId: string): Promise<SearchProgress> => {
    const response = await api.get<SearchProgress>(`/search/progress/${investigationId}`);
    return response.data;
  },
};

export const reportApi = {
  getReport: async (investigationId: string): Promise<Investigation> => {
    const response = await api.get<Investigation>(`/report/${investigationId}`);
    return response.data;
  },

  getReportSummary: async (investigationId: string): Promise<Record<string, unknown>> => {
    const response = await api.get(`/report/${investigationId}/summary`);
    return response.data;
  },
};

export const exportApi = {
  exportPdf: async (investigationId: string): Promise<Blob> => {
    const response = await api.get(`/export/pdf/${investigationId}`, {
      responseType: 'blob',
    });
    return response.data;
  },

  exportJson: async (investigationId: string): Promise<unknown> => {
    const response = await api.get(`/export/json/${investigationId}`);
    return response.data;
  },

  downloadPdf: async (investigationId: string, filename: string): Promise<void> => {
    const blob = await exportApi.exportPdf(investigationId);
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  },

  downloadJson: async (investigationId: string, filename: string): Promise<void> => {
    const data = await exportApi.exportJson(investigationId);
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  },
};

export const historyApi = {
  getHistory: async (limit = 50, page = 1): Promise<HistoryResponse> => {
    const response = await api.get<HistoryResponse>('/history', {
      params: { limit, page },
    });
    return response.data;
  },

  searchByUsername: async (username: string): Promise<Investigation[]> => {
    const response = await api.get<Investigation[]>('/history/search', {
      params: { username },
    });
    return response.data;
  },

  getStatistics: async (): Promise<DashboardStats> => {
    const response = await api.get<DashboardStats>('/history/stats');
    return response.data;
  },
};

export const platformApi = {
  getPlatforms: async (): Promise<string[]> => {
    const response = await api.get<{ platforms: string[] }>('/platforms');
    return response.data.platforms;
  },
};

export default api;
