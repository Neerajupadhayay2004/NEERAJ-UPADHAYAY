import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { SearchForm } from '../components/search';
import { searchApi } from '../services/api';
import type { SearchResponse } from '../types';

export function SearchPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSearch = async (username: string, platforms?: string[]) => {
    setIsLoading(true);
    setError(null);

    try {
      const response: SearchResponse = await searchApi.searchUsername(username, platforms);

      if (response.investigation_id) {
        navigate(`/report/${response.investigation_id}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during search');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-3xl">
        {error && (
          <div className="mb-6 p-4 rounded-lg bg-red-500/10 border border-red-500/30">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        )}
        <SearchForm onSearch={handleSearch} isLoading={isLoading} />
      </div>
    </div>
  );
}
