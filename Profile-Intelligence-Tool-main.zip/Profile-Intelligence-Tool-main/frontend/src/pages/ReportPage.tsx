import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { reportApi } from '../services/api';
import { LoadingOverlay } from '../components/common';
import { ReportSummary, ProfileList, RiskIndicators } from '../components/reports';
import type { Investigation } from '../types';

export function ReportPage() {
  const { id } = useParams<{ id: string }>();
  const [investigation, setInvestigation] = useState<Investigation | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchReport = async () => {
      if (!id) return;

      try {
        const data = await reportApi.getReport(id);
        setInvestigation(data);
      } catch (err) {
        console.error('Failed to load report:', err);
        setError(err instanceof Error ? err.message : 'Failed to load report');
      } finally {
        setIsLoading(false);
      }
    };

    fetchReport();
  }, [id]);

  if (isLoading) {
    return <LoadingOverlay message="Loading investigation report..." />;
  }

  if (error || !investigation) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="cyber-card p-8 text-center max-w-md">
          <p className="text-red-400 mb-4">{error || 'Report not found'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Investigation Report</h1>
          <p className="text-gray-400">
            Detailed analysis for username: {investigation.username}
          </p>
        </div>

        <div className="space-y-6">
          {/* Report Summary */}
          <ReportSummary investigation={investigation} />

          {/* Profiles Section */}
          <section>
            <h2 className="text-xl font-semibold text-white mb-4">
              Discovered Profiles ({investigation.profiles.length})
            </h2>
            <ProfileList profiles={investigation.profiles} />
          </section>

          {/* Risk Analysis Section */}
          <section>
            <RiskIndicators indicators={investigation.risk_indicators} />
          </section>
        </div>
      </div>
    </div>
  );
}
