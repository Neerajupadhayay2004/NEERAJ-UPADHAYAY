import { useEffect, useState } from 'react';
import { historyApi } from '../services/api';
import { DashboardStatsPanel, RecentInvestigations } from '../components/dashboard';
import { LoadingOverlay } from '../components/common';
import type { DashboardStats, HistoryItem } from '../types';

export function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentItems, setRecentItems] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsData, historyData] = await Promise.all([
          historyApi.getStatistics(),
          historyApi.getHistory(5, 1),
        ]);
        setStats(statsData);
        setRecentItems(historyData.items);
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
        setError(err instanceof Error ? err.message : 'Failed to load dashboard');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  if (isLoading) {
    return <LoadingOverlay message="Loading dashboard..." />;
  }

  if (error) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="cyber-card p-8 text-center max-w-md">
          <p className="text-red-400 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="cyber-button"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Intelligence Dashboard</h1>
          <p className="text-gray-400">
            Overview of your OSINT investigations and analytics
          </p>
        </div>

        {/* Stats and Charts */}
        <section className="mb-8">
          <DashboardStatsPanel stats={stats} isLoading={false} />
        </section>

        {/* Recent Investigations */}
        <section>
          <RecentInvestigations items={recentItems} isLoading={false} />
        </section>
      </div>
    </div>
  );
}
