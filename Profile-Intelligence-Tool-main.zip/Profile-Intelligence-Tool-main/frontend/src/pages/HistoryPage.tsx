import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Search, Clock, ChevronRight } from 'lucide-react';
import { historyApi } from '../services/api';
import { LoadingSpinner, RiskBadge } from '../components/common';
import type { HistoryItem, HistoryResponse } from '../types';

export function HistoryPage() {
  const [data, setData] = useState<HistoryResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<HistoryItem[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async (pageNum: number) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await historyApi.getHistory(20, pageNum);
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load history');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData(page);
  }, [page]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setSearchResults(null);
      return;
    }

    setIsSearching(true);
    setError(null);
    try {
      const results = await historyApi.searchByUsername(searchQuery.trim());
      setSearchResults(results as unknown as HistoryItem[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Search failed');
    } finally {
      setIsSearching(false);
    }
  };

  const items = searchResults || data?.items || [];

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Investigation History</h1>
          <p className="text-gray-400">
            View and search your previous OSINT investigations
          </p>
        </div>

        {/* Search Bar */}
        <div className="cyber-card p-4 mb-6">
          <form onSubmit={handleSearch} className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by username..."
                className="cyber-input w-full pl-12"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="cyber-button-outline"
            >
              {isSearching ? <LoadingSpinner size="sm" /> : 'Search'}
            </button>
            {searchResults && (
              <button
                type="button"
                onClick={() => {
                  setSearchResults(null);
                  setSearchQuery('');
                }}
                className="text-sm text-cyber-secondary hover:underline self-center"
              >
                Clear
              </button>
            )}
          </form>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-lg bg-red-500/10 border border-red-500/30">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        )}

        {/* Results */}
        {isLoading && !searchResults ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner size="lg" />
          </div>
        ) : items.length === 0 ? (
          <div className="cyber-card p-8 text-center">
            <p className="text-gray-400">
              {searchResults
                ? 'No investigations found matching your search.'
                : 'No investigations yet. Start your first search!'}
            </p>
            {!searchResults && (
              <Link to="/" className="cyber-button inline-flex mt-4">
                Start Searching
              </Link>
            )}
          </div>
        ) : (
          <>
            {/* Results List */}
            <div className="cyber-card overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left p-4 text-sm font-medium text-gray-400">
                      Username
                    </th>
                    <th className="text-left p-4 text-sm font-medium text-gray-400">
                      Date
                    </th>
                    <th className="text-left p-4 text-sm font-medium text-gray-400">
                      Platforms
                    </th>
                    <th className="text-left p-4 text-sm font-medium text-gray-400">
                      Score
                    </th>
                    <th className="text-left p-4 text-sm font-medium text-gray-400">
                      Risk
                    </th>
                    <th className="p-4"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700/50">
                  {items.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-cyber-primary/10 transition-colors"
                    >
                      <td className="p-4">
                        <span className="font-medium text-white">{item.username}</span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2 text-sm text-gray-400">
                          <Clock className="w-4 h-4" />
                          {format(new Date(item.search_timestamp), 'MMM d, yyyy HH:mm')}
                        </div>
                      </td>
                      <td className="p-4">
                        <span className="text-sm text-gray-300">
                          {item.platforms_found.length} platforms
                        </span>
                      </td>
                      <td className="p-4">
                        <span className="font-medium text-white">
                          {item.intelligence_score}
                        </span>
                      </td>
                      <td className="p-4">
                        <RiskBadge level={item.risk_level} size="sm" />
                      </td>
                      <td className="p-4">
                        <Link
                          to={`/report/${item.id}`}
                          className="text-cyber-secondary hover:text-white transition-colors"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {!searchResults && data && (
              <div className="flex items-center justify-between mt-6">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="cyber-button-outline disabled:opacity-50"
                >
                  Previous
                </button>
                <span className="text-gray-400 text-sm">
                  Page {data.page} of {Math.ceil(data.total / data.page_size)}
                </span>
                <button
                  onClick={() => setPage((p) => (data.has_next ? p + 1 : p))}
                  disabled={!data.has_next}
                  className="cyber-button-outline disabled:opacity-50"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
