# API Reference

## Base URL

```
Development: http://localhost:8000/api
```

## Authentication

Currently, the API uses Supabase's Row Level Security for data access control. All endpoints are accessible to authenticated users.

## Endpoints

### Search

#### POST /api/search

Search for a username across social media platforms.

**Request Body:**

```json
{
  "username": "string",
  "platforms": ["github", "reddit"],  // Optional; searches all if omitted
  "include_risk_analysis": true        // Optional; default true
}
```

**Response:**

```json
{
  "investigation_id": "uuid",
  "username": "string",
  "status": "completed",
  "message": "Investigation completed successfully",
  "platforms_searching": ["github", "twitter_x", "reddit", "..."]
}
```

#### GET /api/search/progress/{investigation_id}

Get the progress of an ongoing investigation.

**Response:**

```json
{
  "investigation_id": "uuid",
  "total_platforms": 7,
  "completed_platforms": 5,
  "current_platform": "reddit",
  "platform_statuses": [
    {
      "platform": "github",
      "status": "completed",
      "found": true,
      "profile_url": "https://github.com/username"
    }
  ],
  "progress_percentage": 71.4
}
```

---

### Reports

#### GET /api/report/{investigation_id}

Get complete investigation report with all profiles and risk indicators.

**Response:**

```json
{
  "id": "uuid",
  "username": "string",
  "search_timestamp": "2024-01-15T10:30:00Z",
  "status": "completed",
  "platforms_searched": ["github", "reddit", "..."],
  "platforms_found": ["github", "reddit"],
  "total_profiles": 2,
  "intelligence_score": 45,
  "risk_level": "medium",
  "notes": null,
  "profiles": [
    {
      "id": "uuid",
      "platform": "github",
      "platform_url": "https://github.com/username",
      "username": "username",
      "display_name": "User Name",
      "bio": "Software developer",
      "profile_picture_url": "https://...",
      "account_created_date": "2020-01-15",
      "followers_count": 150,
      "following_count": 50,
      "posts_count": 25,
      "is_verified": false,
      "is_public": true,
      "external_links": ["https://example.com"]
    }
  ],
  "risk_indicators": [
    {
      "id": "uuid",
      "indicator_type": "new_account",
      "severity": "medium",
      "description": "Account on platform X is less than 30 days old",
      "evidence": { "is_new": true, "days_old": 15 }
    }
  ]
}
```

#### GET /api/report/{investigation_id}/summary

Get a summary of the investigation without full details.

**Response:**

```json
{
  "investigation_id": "uuid",
  "username": "string",
  "status": "completed",
  "intelligence_score": 45,
  "risk_level": "medium",
  "platforms_count": 2,
  "platforms": ["github", "reddit"],
  "risk_indicators_count": 3,
  "high_risk_count": 1,
  "search_timestamp": "2024-01-15T10:30:00Z"
}
```

---

### Export

#### GET /api/export/pdf/{investigation_id}

Download investigation as PDF report.

**Response:** Binary PDF file with `Content-Disposition` header for download.

#### GET /api/export/json/{investigation_id}

Export investigation as JSON with structured metadata.

**Response:**

```json
{
  "export_metadata": {
    "exported_at": "2024-01-15T10:35:00Z",
    "format_version": "1.0",
    "tool": "Profile Intelligence Tool v1.0.0"
  },
  "investigation": { /* ... */ },
  "profiles": [ /* ... */ ],
  "risk_indicators": [ /* ... */ ],
  "summary": {
    "platforms_count": 2,
    "risk_indicators_count": 3,
    "has_high_risk": true
  }
}
```

---

### History

#### GET /api/history

Get paginated investigation history.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| limit | int | 50 | Items per page (max 100) |
| page | int | 1 | Page number |

**Response:**

```json
{
  "items": [
    {
      "id": "uuid",
      "username": "example_user",
      "search_timestamp": "2024-01-15T10:30:00Z",
      "platforms_found": ["github", "reddit"],
      "risk_level": "medium",
      "intelligence_score": 45
    }
  ],
  "total": 25,
  "page": 1,
  "page_size": 50,
  "has_next": false
}
```

#### GET /api/history/search

Search investigation history by username.

**Query Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| username | string | Yes | Username to search for |

**Response:** Array of investigation objects.

#### GET /api/history/stats

Get dashboard statistics.

**Response:**

```json
{
  "total_investigations": 100,
  "platform_distribution": {
    "github": 80,
    "reddit": 60,
    "twitter_x": 45
  },
  "risk_level_distribution": {
    "low": 50,
    "medium": 35,
    "high": 10,
    "critical": 5
  },
  "average_intelligence_score": 42.5,
  "most_searched_platforms": [
    ["github", 80],
    ["reddit", 60],
    ["twitter_x", 45]
  ]
}
```

---

### System

#### GET /

API root endpoint with basic information.

#### GET /health

Health check endpoint.

**Response:**

```json
{
  "status": "healthy",
  "timestamp": 1705320000,
  "version": "1.0.0"
}
```

#### GET /platforms

List supported platforms.

**Response:**

```json
{
  "platforms": ["github", "twitter_x", "reddit", "instagram", "tiktok", "youtube", "medium"],
  "total": 7,
  "note": "Platform availability may vary based on rate limits and API access"
}
```

---

## Error Responses

All errors follow a consistent format:

```json
{
  "error": "Error Type",
  "detail": "Detailed error message"
}
```

### Common HTTP Status Codes

| Code | Description |
|------|-------------|
| 400 | Bad Request - Invalid input |
| 404 | Not Found - Resource not found |
| 422 | Unprocessable Entity - Validation error |
| 500 | Internal Server Error |
| 503 | Service Unavailable - Platform rate limit |

---

## Rate Limiting

The API implements rate limiting to ensure fair usage:

- **Search endpoint**: 100 requests per minute
- **Other endpoints**: Standard limits apply

Rate limit headers are included in responses:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1705320000
```
