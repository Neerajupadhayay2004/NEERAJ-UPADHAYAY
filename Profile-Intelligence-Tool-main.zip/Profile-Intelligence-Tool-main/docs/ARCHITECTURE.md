# Profile Intelligence Tool - Architecture Documentation

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              CLIENT LAYER                                    │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                         React Application                                │ │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │ │
│  │  │  Search  │  │Dashboard │  │  Report  │  │ History  │  │  Export  │  │ │
│  │  │   Page   │  │   Page   │  │   Page   │  │   Page   │  │  Action  │  │ │
│  │  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  │ │
│  │       │             │             │             │              │        │ │
│  │       └─────────────┴─────────────┴─────────────┴──────────────┘        │ │
│  │                                   │                                      │ │
│  │                          ┌───────▼───────┐                               │ │
│  │                          │   Axios API  │                               │ │
│  │                          │    Client    │                               │ │
│  │                          └──────────────┘                               │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        │ HTTP/REST
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              API LAYER                                       │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                       FastAPI Application                                │ │
│  │                                                                          │ │
│  │  ┌────────────────────────────────────────────────────────────────────┐  │ │
│  │  │                        Middleware Layer                            │  │ │
│  │  │  • CORS Middleware                                                  │  │ │
│  │  │  • Request Logging                                                  │  │ │
│  │  │  • Exception Handlers                                               │  │ │
│  │  │  • Validation Error Handler                                        │  │ │
│  │  └────────────────────────────────────────────────────────────────────┘  │ │
│  │                                    │                                     │ │
│  │                                    ▼                                     │ │
│  │  ┌────────────────────────────────────────────────────────────────────┐  │ │
│  │  │                     Router Layer                                   │  │ │
│  │  │                                                                     │  │ │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐                  │  │ │
│  │  │  │ Search  │ │ Report  │ │ Export  │ │ History │                  │  │ │
│  │  │  │ Router  │ │ Router  │ │ Router  │ │ Router  │                  │  │ │
│  │  │  └────┬────┘ └────┬────┘ └────┬────┘ └────┬────┘                  │  │ │
│  │  │       │           │           │           │                       │  │ │
│  │  └───────┼───────────┼───────────┼───────────┼───────────────────────┘  │ │
│  │          │           │           │           │                          │ │
│  │          └───────────┴─────┬─────┴───────────┘                          │ │
│  │                            │                                            │ │
│  │                            ▼                                            │ │
│  │  ┌────────────────────────────────────────────────────────────────────┐ │ │
│  │  │                    Service Layer                                   │ │ │
│  │  │                                                                     │ │ │
│  │  │  ┌────────────────────────────────────────────────────────────────┐ │ │ │
│  │  │  │              Investigation Service (Orchestrator)              │ │ │ │
│  │  │  │  • Manages investigation lifecycle                              │ │ │ │
│  │  │  │  • Coordinates platform searches                                │ │ │ │
│  │  │  │  • Aggregates results                                          │ │ │ │
│  │  │  └────────────────────────────────────────────────────────────────┘ │ │ │
│  │  │                            │                                        │ │ │
│  │  │          ┌─────────────────┼─────────────────┐                     │ │ │
│  │  │          │                 │                 │                     │ │ │
│  │  │          ▼                 ▼                 ▼                     │ │ │
│  │  │  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐              │ │ │
│  │  │  │  Platform   │   │    Risk     │   │     PDF     │              │ │ │
│  │  │  │  Detector   │   │  Analyzer   │   │  Generator  │              │ │ │
│  │  │  │             │   │             │   │             │              │ │ │
│  │  │  │ • GitHub    │   │ • Username  │   │ • ReportLab │              │ │ │
│  │  │  │ • Twitter/X │   │ • New Acct   │   │ • Charts    │              │ │ │
│  │  │  │ • Reddit    │   │ • Links      │   │ • Tables    │              │ │ │
│  │  │  │ • Instagram │   │ • Activity   │   │ • Styling   │              │ │ │
│  │  │  │ • TikTok    │   │ • Scoring    │   │             │              │ │ │
│  │  │  │ • YouTube   │   │             │   │             │              │ │ │
│  │  │  │ • Medium    │   │             │   │             │              │ │ │
│  │  │  └─────────────┘   └─────────────┘   └─────────────┘              │ │ │
│  │  └────────────────────────────────────────────────────────────────────┘ │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        │ Supabase SDK
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DATA LAYER                                         │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                        Supabase (PostgreSQL)                            │ │
│  │                                                                          │ │
│  │  ┌────────────────────────────────────────────────────────────────────┐  │ │
│  │  │                      Tables                                        │  │ │
│  │  │                                                                     │  │ │
│  │  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐ │  │ │
│  │  │  │veatigations  │  │  profiles    │  │    risk_indicators       │ │  │ │
│  │  │  │─────────────│  │─────────────│  │────────────────────────│ │  │ │
│  │  │  │ id (PK)     │  │ id (PK)      │  │ id (PK)                  │ │  │ │
│  │  │  │ username    │──│ investigation│──│ investigation_id (FK)    │ │  │ │
│  │  │  │ status      │  │ platform     │  │ profile_id (FK)          │ │  │ │
│  │  │  │ score       │  │ username     │  │ indicator_type           │ │  │ │
│  │  │  │ risk_level  │  │ bio          │  │ severity                 │ │  │ │
│  │  │  │ platforms[] │  │ followers    │  │ description              │ │  │ │
│  │  │  └──────────────┘  │ ...          │  │ evidence (JSONB)         │ │  │ │
│  │  │                   └──────────────┘  └──────────────────────────┘ │  │ │
│  │  │                                                                     │  │ │
│  │  └────────────────────────────────────────────────────────────────────┘  │ │
│  │                                                                          │ │
│  │  ┌────────────────────────────────────────────────────────────────────┐  │ │
│  │  │                   Security Features                                 │  │ │
│  │  │  • Row Level Security (RLS)                                        │  │ │
│  │  │  • UUID Primary Keys                                                │  │ │
│  │  │  • Timestamps & Auditing                                           │  │ │
│  │  │  • Indexes for Performance                                         │  │ │
│  │  └────────────────────────────────────────────────────────────────────┘  │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
1. User enters username in Search Page
   │
   ▼
2. Frontend sends POST /api/search request
   │
   ▼
3. Search Router receives request
   │
   ├──► Validate input
   │
   ├──► Create investigation record in DB
   │
   ▼
4. Investigation Service orchestrates search
   │
   ├──► Spawn concurrent platform detectors
   │    │
   │    ├──► GitHub Detector     ──► GitHub API
   │    ├──► Reddit Detector      ──► Reddit API
   │    ├──► Twitter Detector     ──► Web Scraping
   │    ├──► Instagram Detector   ──► Web Scraping
   │    ├──► TikTok Detector      ──► Web Scraping
   │    ├──► YouTube Detector     ──► Web Scraping
   │    └──► Medium Detector      ──► Web Scraping
   │
   ├──► Aggregate results
   │
   ▼
5. Risk Analyzer processes profiles
   │
   ├──► Analyze username patterns
   ├──► Check account age
   ├──► Evaluate activity levels
   ├──→ Detect suspicious indicators
   │
   ├──► Calculate intelligence score
   │
   ▼
6. Save results to database
   │
   ├──► Update investigation status
   ├──► Save profile records
   ├──► Save risk indicators
   │
   ▼
7. Return results to frontend
   │
   ▼
8. Frontend displays Report Page
   │
   ├──► Profile cards
   ├──► Risk indicators
   ├──► Intelligence summary
   │
   ▼
9. User can export as PDF/JSON
```

## Component Responsibilities

### Frontend (React)

| Component | Purpose |
|-----------|---------|
| SearchPage | Username input and search initiation |
| DashboardPage | Statistics and recent investigations |
| ReportPage | Display investigation results |
| HistoryPage | Browse past investigations |
| ApiService | Communicate with backend |

### Backend (FastAPI)

| Module | Purpose |
|--------|---------|
| search router | Handle username search requests |
| report router | Retrieve investigation data |
| export router | Generate PDF/JSON exports |
| history router | Query investigation history |
| platform_detector | Detect profiles on platforms |
| risk_analyzer | Analyze risk indicators |
| report_generator | Create PDF reports |

### Database (Supabase)

| Table | Purpose |
|-------|---------|
| investigations | Store search sessions |
| profiles | Store discovered profiles |
| risk_indicators | Store risk analysis results |
| metadata_history | Track data changes |

## Security Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Security Layers                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 1. Input Validation                                 │   │
│  │    • Username sanitization                          │   │
│  │    • Platform whitelist check                       │   │
│  │    • Request rate limiting                          │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 2. API Security                                      │   │
│  │    • CORS configuration                             │   │
│  │    • Request validation                             │   │
│  │    • Structured error responses                     │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 3. Database Security                                 │   │
│  │    • Row Level Security (RLS)                       │   │
│  │    • Prepared statements (SQL injection prevention) │   │
│  │    • Service role key separation                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 4. OSINT Ethics                                      │   │
│  │    • Public data only                               │   │
│  │    • No authentication bypass                       │   │
│  │    • Platform rate limit respect                    │   │
│  │    • No password/private data collection            │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
